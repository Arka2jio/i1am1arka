(function(exports,undefined)
{
	"use strict";
	function CGame(_midlet, _display)
	{		
		CGame.__superclass__.call(this, _midlet,_display);
		CGame.m_chtFont = new BitmapFont("/chtFont");
		GGTracking.getInstance().init();
	}
	LowAPI.extendClass(CGame, GLLib);

	// -----------------------------------------------------------------------------------------------------------------------------------------
// RMS

// RMS enumerator
var RMS = {};
{
	RMS.LANGUAGE   = 0;
	RMS.SOUND_ENABLED 	 	= RMS.LANGUAGE + 1;
	RMS.SOUND_LEVEL	 	 	= RMS.SOUND_ENABLED + 1;
	RMS.GAME_PROGRESS          = RMS.SOUND_LEVEL + 1;
	RMS.LEVEL_INDEX            = RMS.GAME_PROGRESS + 1;
	RMS.LEVEL_INFO_STRAT       = RMS.LEVEL_INDEX + 1;
	RMS.LEVEL_INFO_NUM         = 28;
	RMS.LEVEL_FINAL_INFO1      = RMS.LEVEL_INFO_STRAT + RMS.LEVEL_INFO_NUM;
	RMS.LEVEL_FINAL_INFO2      = RMS.LEVEL_FINAL_INFO1 + 1;
	RMS.PLAYER_INFO_STRAT      = RMS.LEVEL_FINAL_INFO2 + 1;
//@#if not Use_Motion_Sensor
	RMS.PLAYER_INFO_NUM        = 5;
//@#else
//@		RMS.PLAYER_INFO_NUM        = 7;
//@#endif
	RMS.LEVEL_STAR_INFO_START  = RMS.PLAYER_INFO_STRAT + RMS.PLAYER_INFO_NUM;
	RMS.LEVEL_STAR_INFO_NUM    = DAI.LEVELS_NUM_MAX * DAI.STAR_INFO_SIZE;
	RMS.LEVEL_TOTAL_SCORE_START= RMS.LEVEL_STAR_INFO_START + RMS.LEVEL_STAR_INFO_NUM * 2;
	RMS.LEVEL_TOTAL_SCORE_NUM  = DAI.LEVELS_NUM_MAX;
	RMS.SIZE       			= RMS.LEVEL_TOTAL_SCORE_START + RMS.LEVEL_TOTAL_SCORE_NUM * 4;
};

// -----------------------------------------------------------------------------------------------------------------------------------------
// STATES

// State enumerator
window.STATE = {};
{
	STATE.QUIT 						= -1;
	STATE.INIT 						= STATE.QUIT + 1;//0
	STATE.SELECT_LANGUAGE_INIT		= STATE.INIT + 1;
	STATE.SELECT_LANGUAGE			= STATE.SELECT_LANGUAGE_INIT + 1;
	STATE.GAMELOFT_LOGO				= STATE.SELECT_LANGUAGE + 1;
	STATE.COPYRIGHT					= STATE.GAMELOFT_LOGO + 1;
	STATE.ASK_SOUND					= STATE.COPYRIGHT + 1;//5
	STATE.SPLASH					= STATE.ASK_SOUND + 1;
	STATE.MENU_MAIN					= STATE.SPLASH + 1;
	STATE.MENU_NEW_GAME				= STATE.MENU_MAIN + 1;
	STATE.CONTINUE_GAME             = STATE.MENU_NEW_GAME + 1;
	STATE.MENU_MAP					= STATE.CONTINUE_GAME + 1;//10
	STATE.MENU_SELECT_WORLD			= STATE.MENU_MAP + 1;
	STATE.MENU_SELECT_LEVEL			= STATE.MENU_SELECT_WORLD + 1;
	STATE.LOAD_UNLOAD				= STATE.MENU_SELECT_LEVEL + 1;
	STATE.GAMEPLAY_UPDATE			= STATE.LOAD_UNLOAD + 1;
	STATE.GAMEOVER					= STATE.GAMEPLAY_UPDATE + 1;//15
	STATE.GAMEEND					= STATE.GAMEOVER + 1;
	STATE.GAME_STATISTIC			= STATE.GAMEEND + 1;
	STATE.MENU_OPTIONS				= STATE.GAME_STATISTIC + 1;
	STATE.MENU_GET_MORE_GAMES_INIT	= STATE.MENU_OPTIONS + 1;
	STATE.MENU_GET_MORE_GAMES		= STATE.MENU_GET_MORE_GAMES_INIT + 1;//20
	STATE.MENU_HELP					= STATE.MENU_GET_MORE_GAMES + 1;
	STATE.MENU_ABOUT				= STATE.MENU_HELP + 1;
	STATE.MENU_EXIT					= STATE.MENU_ABOUT + 1;
	STATE.RESET_GAME				= STATE.MENU_EXIT + 1;
	STATE.RESUME_GAME				= STATE.RESET_GAME + 1;//25
	STATE.BACK_TO_MINIMAP           = STATE.RESUME_GAME + 1;
	STATE.RESTART_LEVEL				= STATE.BACK_TO_MINIMAP + 1;
	STATE.MENU_INIT					= STATE.RESTART_LEVEL + 1;
	STATE.NO						= STATE.MENU_INIT + 1;
	STATE.YES						= STATE.NO + 1;//30
	STATE.MENU_INGAME				= STATE.YES + 1;
	STATE.MENU_INGAME_OPTIONS		= STATE.MENU_INGAME + 1;
	STATE.MENU_INGAME_MAIN_MENU		= STATE.MENU_INGAME_OPTIONS + 1;
	STATE.ASK_SOUND_LEVEL			= STATE.MENU_INGAME_MAIN_MENU + 1;
	STATE.SOUND_OFF					= STATE.ASK_SOUND_LEVEL + 1;//35
	STATE.SOUND_LOW					= STATE.SOUND_OFF + 1;
	STATE.SOUND_MEDIUM				= STATE.SOUND_LOW + 1;
	STATE.SOUND_HIGH				= STATE.SOUND_MEDIUM + 1;
	STATE.IGP						= STATE.SOUND_HIGH + 1;

	STATE.K_MRC_INIT				= STATE.IGP + 1;//40
	STATE.K_MRC_VALIDATING			= STATE.K_MRC_INIT + 1;
	STATE.K_MRC_EXPIRED				= STATE.K_MRC_VALIDATING + 1;
	STATE.K_MRC_NETWORK_FAILED		= STATE.K_MRC_EXPIRED + 1;
	// ...
	STATE.END_GAME_IGP				= STATE.K_MRC_NETWORK_FAILED + 1;
	STATE.NEW_STATE2				= STATE.END_GAME_IGP + 1;//45

	STATE.NEW_STATE3				= STATE.NEW_STATE2 + 1;
	STATE.NEW_STATE4				= STATE.NEW_STATE3 + 1;
	STATE.NEW_STATE5				= STATE.NEW_STATE4 + 1;

	//====================================
	//============ TnB State =============
	//====================================
	//A.W Add TnB State

	//TnB State MENU
	STATE.MENU_TNB_MAIN						= STATE.NEW_STATE5 + 1;
	STATE.MENU_TNB_MAIN_W_PURCHASE			= STATE.MENU_TNB_MAIN + 1;//50
	
	//Tnb State POPUP
	STATE.POPUP_TNB_DEMO					= STATE.MENU_TNB_MAIN_W_PURCHASE + 1;
	STATE.POPUP_TNB_PROBLEM					= STATE.POPUP_TNB_DEMO + 1;
	STATE.POPUP_TNB_LOADING					= STATE.POPUP_TNB_PROBLEM + 1;
	STATE.POPUP_TNB_CONFIRM					= STATE.POPUP_TNB_LOADING + 1;
	STATE.POPUP_TNB_DOUBLE_CONFIRM			= STATE.POPUP_TNB_CONFIRM + 1;//55
	STATE.POPUP_TNB_UNLOCK_SUCCESS			= STATE.POPUP_TNB_DOUBLE_CONFIRM + 1;
	STATE.POPUP_TNB_UNLOCK_FAILED			= STATE.POPUP_TNB_UNLOCK_SUCCESS + 1;
	STATE.POPUP_TNB_PURCHASE_CODE			= STATE.POPUP_TNB_UNLOCK_FAILED + 1;
	STATE.POPUP_TNB_UNLOCK_CODE_SUCCESS		= STATE.POPUP_TNB_PURCHASE_CODE + 1;
	STATE.POPUP_TNB_UNLOCK_CODE_FAILED		= STATE.POPUP_TNB_UNLOCK_CODE_SUCCESS + 1;//60

	//Tnb State Button
	STATE.BTN_TNB_OK						= STATE.MENU_TNB_P_UNLOCK_CODE_FAILED + 1;
	STATE.BTN_TNB_CANCEL					= STATE.BTN_TNB_OK + 1;
	STATE.BTN_TNB_BUYGAME					= STATE.BTN_TNB_CANCEL + 1;
	STATE.BTN_TNB_PLAY_THE_GAME				= STATE.BTN_TNB_BUYGAME + 1;
	STATE.BTN_TNB_DEMO						= STATE.BTN_TNB_PLAY_THE_GAME + 1;//65
	STATE.BTN_TNB_PURCHASECODE				= STATE.BTN_TNB_DEMO + 1;
	STATE.BTN_TNB_GETNOW					= STATE.BTN_TNB_PURCHASECODE + 1;
	STATE.BTN_TNB_MM						= STATE.BTN_TNB_GETNOW + 1;
	STATE.BTN_TNB_TC						= STATE.BTN_TNB_MM + 1;
	STATE.BTN_TNB_TRY						= STATE.BTN_TNB_TC + 1;//70
	
//@#if SupportLandspaceMode
//@		var LANDSPACE				= NEW_STATE5 + 1; 
//@#endif		
};


	var s_game_state = STATE.INIT;

	//Vikas
	   var buf;
	   var buf2;
	   var REAL_SCREEN_W = 480;
	   var REAL_SCREEN_H = 640;
	   var GAME_SIZE_X = 240;
	   var GAME_SIZE_Y = 320;
	   var g_StretchX = LowAPI.Gen_Array([REAL_SCREEN_W], 0);//new var[REAL_SCREEN_W];
	   var g_StretchY = LowAPI.Gen_Array([REAL_SCREEN_H], 0);//new var[REAL_SCREEN_H];
	//Vikas
	var bufferImg = null;
	/// Next game state.
	CGame.s_next_game_state_after_unload = -1;
	CGame._mapTileCountWidth = 0;
	CGame._mapTileCountHeight = 0;

	CGame._entityCount = 0;
	CGame._phyData;
	CGame._topLayerData = null;
	CGame._topLayerFlip = null;
	CGame._entityMap = new Hashtable(10000);
	CGame._entitiesRowTable = new Hashtable(10000);
	CGame._entitiesRowData = null;
	CGame._entityRowDataCount = 0;
	CGame._entityMaxId = 0;
	var DYNAMIC_TILE_ID = 0x2000;
	var DYNAMIC_SEGMENT_ID = 0x4000;
	var DYNAMIC_ENTITY_ID = 0x6000;

//@#if not SimplePhysics
	CGame._segmentCount = 0;
	CGame._segments = null;
	CGame._segmentParams = null;
	CGame._segmentAngles = null;
//@#endif
	var GAME_PROGRESS_FIRST_PLAY = 0;
	var GAME_PROGRESS_FIRST_MINI_MAP_EVENT = 1;
	
	CGame._gameProgress = GAME_PROGRESS_FIRST_PLAY;
	CGame._levelId = -1;
	CGame._worldId = 0;
	CGame._tempLevelId= 0;
	CGame._levelFinalInfo1= 0;
	CGame._levelFinalInfo2 = 0;
	CGame._finalLevelIndex = 20;
	CGame._levelUnlocked = -1;
	CGame._isIntroLevel = false;
	CGame._levelInfo = LowAPI.Gen_Array([RMS.LEVEL_INFO_NUM], 0);//new byte[RMS.LEVEL_INFO_NUM];
	CGame._playerInfo = LowAPI.Gen_Array([RMS.PLAYER_INFO_NUM], 0);//new byte[RMS.PLAYER_INFO_NUM];
	CGame._levelTotalScore = LowAPI.Gen_Array([DAI.LEVELS_NUM_MAX], 0);//new var[DAI.LEVELS_NUM_MAX];
	CGame._levelStarInfo = LowAPI.Gen_Array([DAI.LEVELS_NUM_MAX * DAI.STAR_INFO_SIZE], 0);//new short [DAI.LEVELS_NUM_MAX * DAI.STAR_INFO_SIZE];


	var _pauseType = 0;
	var _pauseParam = 0;
	var _pauseTick = 0;

	var _fade_effect_alpha = 0;
	var _fade_effect_rgb = 0;
	var _fade_circle_centerX = 0;
	var _fade_circle_centerY = 0;
	CGame._inCinematicBlackScreen = false;

	CGame._class2sprites = null;
	CGame._level2tiled = null;

	var _splash = null;
	var _map = null;
	CGame._interface = null;
//@#if TOUCH_SCREEN
	var _touchInterface = null;
//@#endif
	var _effect = null;
	var _menuIngame = null;
//@#if not RemoveFireworks
	var _fireworkSprite = null;
//@#endif
	//A.W: Tnb Popup BG
	var _tnbPopupSprite = null;
//@#if not RemoveStory
	var _storySprite = null;
//@#endif
//@#if not SimplePhysics
	CGame._balanceImageData = null;
	CGame._balanceImageSize = null;
	var _balanceImageWidth = null;
	var _balanceImageHeight = null;
//@#endif
	var _animationDT = 0;
	CGame._velocityRate = 0;
	CGame._frameDT = 0;
	CGame._frameDT_Real = 0;
	var _timeMillisForUpdate = 0;

	var s_game_keyLastPressed = 0;
	var s_game_keyLastPressedTime = 0;
	// var s_game_keyJustPressed;
	// var s_game_keyPressedTime;
	
	//level star num.

		// Switches
	var			LOADING_BEFORE_SOUND_PROMPT = false;
	var			SOUND_STATE_AS_LEVELS		= false;

	// Sound Levels (0 - 100)
	var				SOUND_LEVEL_LOW							= 33;
	var				SOUND_LEVEL_MEDIUM						= 66;
	var				SOUND_LEVEL_HIGH						= 100;
	// igp
	var _is_igp_actived = false;
	var _returnFromPause = false;
	var _isSoundPause = false;
	
	// CGame.prototype.Init = function()
	// {
	// 	Dbg("Init ========================== s_game_state : " + s_game_state);
	// }
	
	
	// CGame.prototype.Quit = function()
	// {
	// 	Dbg("Quit ========================== s_game_state : " + s_game_state);
	// }
	// CGame.prototype.Resume = function()
	// {
		
	// }


//---------------------------------------------------------------------

CGame.prototype.Pause = function ()
{
	if(DEF.dbgEnable) Dbg("Pause ========================== s_game_state : " + s_game_state);
	//super.Pause();
	// CGame.__superproto__.Pause_GLLib.call(this);

	s_game_interruptNotify = true;
	
	if (DSound_Channel.SFX != DSound_Channel.BGM) {
		CGame.StopSound(DSound_Channel.SFX);
	}
	if (GLLibConfig.sound_enableThread) {
		GLLibPlayer.Snd_ForceExecOnThreadOnGamePause();
	} else {
		GLLibPlayer.Snd_Update();
	}
	if (s_game_state == STATE.GAMEPLAY_UPDATE || s_game_state == STATE.MENU_MAP) {
		CGame.initIngameMenu(STATE.MENU_INGAME);
	} else {
		CGame.PauseSoundBGM();
	}
	if (GLLibConfig.sound_enableThread) {
		GLLibPlayer.Snd_ForceExecOnThreadOnGamePause();
	} else {
		GLLibPlayer.Snd_Update();
	}
}


//--------------------------------------------------------------------------------------------------------------------
/// Resume the game engine. Can be called by the Midlet or /*GLLib.*/showNotify. 
/// If the game was not in pause state, nothing happens.
/// \sa /*GLLib.*/showNotify
//--------------------------------------------------------------------------------------------------------------------
CGame.prototype.Resume  = function()
{
	if(DEF.dbgEnable) Dbg("Resume ========================== s_game_state : " + s_game_state);
	// super.Resume();
	// CGame.__superproto__.Resume_GLLib.call(this);
	s_game_interruptNotify = false;	

	if (s_game_state != STATE.MENU_INGAME && s_game_state > 0) {
		this.ResumeSoundBGM();
	}
}

/**
 * Override
 * Capture the showNotify event and notify the state machine
 */
CGame.prototype.showNotify = function()
{
		//TraceBegin("cGame.showNotify");
		
		CGame.__superproto__.showNotify.call(this);
		
		this.Resume();
}

/**
 * Override
 * Capture the hideNotify event and notify the state machine
 */
CGame.prototype.hideNotify  = function()
{
		CGame.__superproto__.hideNotify.call(this);
	 
		this.Pause();
	
}
// -----------------------------------------------------------------------------------------------------------------------------------------
// SOUND
CGame.PauseSoundBGM = function() {
	var isPlaying = false;
	try {
		isPlaying = GLLibPlayer.Snd_IsPlaying(DSound_Channel.BGM);
	} catch (ex) {
		if(DEF.dbgEnable) Dbg("-------------------- error : " + ex.message);
	}
	if (isPlaying) {
//@#if varerrupt_ReplaySound
//@			GLLibPlayer.Snd_Stop(DSound_Channel.BGM);
//@			_isSoundPause = true;
//@#else
		GLLibPlayer.Snd_Pause(DSound_Channel.BGM);
		_isSoundPause = true;
//@#endif
	} else {
		GLLibPlayer.Snd_Stop(DSound_Channel.BGM);
	}
}

CGame.prototype.ResumeSoundBGM = function() {
	if (!CGame.bIsPaused) {
		if (_isSoundPause) {
//@#if varerrupt_ReplaySound
//@				PlaySoundBGM();
//@#else
			GLLibPlayer.Snd_Resume(DSound_Channel.BGM);

		} else {
			CGame.PlaySoundBGM();
//@#endif
		}
		_isSoundPause = false;
	}
}

/// Used to trigger sounds on/off
CGame.isSoundEnabled = false; // game state
//@#if LoadSoundOnce
//@    var hasLoadSound;
//@#endif

CGame.prototype.startSound = function()// throws Exception
{
	if (!CGame.isSoundEnabled) {
		CGame.isSoundEnabled = true;
//@#if LoadSoundOnce
//@            if( !hasLoadSound ){
//@			    CGame.LoadUnload(DLoadState.LOAD_SOUND);
//@			    hasLoadSound = true;
//@			}
//@#else
		//CGame.LoadUnload(DLoadState.LOAD_SOUND); **Need many time for loadsound
//@#endif
	}
	if (CGame.bIsPaused) {
		CGame.PlaySound(DSound_Channel.SFX, DATA.SOUND_MENU_CONFIRM);
	} else {
		CGame.PlaySound(DSound_Channel.BGM, DATA.SOUND_BGM_MAIN_MENU);
	}
}

CGame.prototype.StopSound = function()// throws Exception
{
	if (CGame.isSoundEnabled)
	{
		GLLibPlayer.Snd_StopAllSounds();
		CGame.isSoundEnabled = false;
		_isSoundPause = false;
	}
}

CGame.StopSound = function (channel) {
	GLLibPlayer.Snd_Stop(channel);
}
var playsoud_cutscene_story = false;
CGame.PlaySoundBGM = function() {
	//before play any sound, close current sound first. 
	CGame.StopSound(DSound_Channel.BGM);
	//
	if (s_game_state == STATE.MENU_MAP) {
		CGame.PlaySound(DSound_Channel.BGM, DATA.SOUND_BGM_STAGE_CHOOSE);

	} else if (s_game_state == STATE.GAMEPLAY_UPDATE) {
		var bgmIndex = DATA.SOUND_BGM_LABYRINTH_LEVEL;

//@#if not NO_BGM_CAKE_AND_SPACE
//@			bgmIndex += CGame._worldId;
//@#else
		// bgmIndex += CGame._worldId % 2;
//@#endif	
		// bgmIndex = Math.min(bgmIndex, DATA.SOUND_BGM_BOSS_FIGHT - 1);
		// if(CGame._tempLevelId / DAI.LEVELS_NUM_PRE_WORLD == DAI.WORLD_ID_CASTLE) {
				// bgmIndex = DATA.SOUND_BGM_LABYRINTH_LEVEL +  CGame._tempLevelId % DAI.LEVELS_NUM_PRE_WORLD - 1;
			// if(CGame._tempLevelId % DAI.LEVELS_NUM_PRE_WORLD >= 5 || CGame._tempLevelId % DAI.LEVELS_NUM_PRE_WORLD <= 0) {
				// bgmIndex = DATA.SOUND_BGM_BOSS_FIGHT;
			// }
		// } else 
		if(CGame._worldId % 2 != 0)
		{
			bgmIndex = DATA.SOUND_BGM_01;
		} else{
			bgmIndex = DATA.SOUND_BGM_02;
		}
		var curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
		if(curLevelId %4 <= 0 && !playsoud_cutscene_story && CGame._tempLevelId != DAI.LEVEL_ID_CASTLE_FINAL_BOSS)
		{
			playsoud_cutscene_story = true;
			bgmIndex = DATA.SOUND_BGM_CUTSCENE_STORY;
		}
		if (CGame._tempLevelId % DAI.LEVELS_NUM_PRE_WORLD == DAI.LEVLE_ID_BOSS_FIGHT) { // boss level
			if(!playsoud_cutscene_story)
			{
				playsoud_cutscene_story = true;
				bgmIndex = DATA.SOUND_BGM_CUTSCENE_STORY;
			}
			else
				bgmIndex = DATA.SOUND_BGM_BOSS_FIGHT;
		}
		
			if (CGame._tempLevelId == DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
				if(!playsoud_cutscene_story)
				{
					playsoud_cutscene_story = true;
					bgmIndex = DATA.SOUND_BGM_CUTSCENE_STORY;
				}
				else
					bgmIndex = DATA.SOUND_BGM_BOSS_FIGHT;
		}
		
			if (CGame._tempLevelId > DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
//@#if not NO_BGM_CUTSCENE_STORY				
			bgmIndex = DATA.SOUND_BGM_CUTSCENE_STORY;
//@#else 
			//	bgmIndex = DATA.SOUND_BGM_BOSS_FIGHT;
//@#endif				
		}
		CGame.PlaySound(DSound_Channel.BGM, bgmIndex);
	} else if (s_game_state != STATE.LOAD_UNLOAD && !CGame.bIsPaused) {
		CGame.PlaySound(DSound_Channel.BGM, DATA.SOUND_BGM_MAIN_MENU);
	}
}
CGame.PlaySound = function( channel, id) {
	if (s_game_isPaused) {
		return;
	}
	if (CGame.isSoundEnabled) {
		var volume = DGUI.SOUND_VOLUME;
		var loop = 1;
//@#if not BGMPlayOnce
//@#if not NO_BGM_STAGE_CHOOSE
//@			var maxLoopSoundId = DATA.SOUND_BGM_STAGE_CHOOSE;
//@#else
//@			var maxLoopSoundId = DATA.SOUND_BGM_LABYRvarH_LEVEL;
//@#endif			
//@			if (channel == DSound_Channel.BGM && id >= maxLoopSoundId) {
//@				loop = 0;
//@			}
//@#else
//@#if not NO_BGM_STAGE_CHOOSE			
//@			if (channel == DSound_Channel.BGM && id == DATA.SOUND_BGM_STAGE_CHOOSE) {
//@				loop = 0;
//@			}
//@#endif	
/*		
		var isPlaying;
		try
		{
			isPlaying = GLLibPlayer.Snd_IsPlaying(DSound_Channel.BGM);
		}
		catch(e)
		{
			if (true)
			{
				Dbg("Snd_update.error on channel ("+channel+")."+e.message);
			}
			isPlaying = false;
		}
		if (!(isPlaying && id < 
//@#if not NO_BGM_STAGE_CHOOSE	
//@					DATA.SOUND_BGM_STAGE_CHOOSE
//@#else					
				DATA.SOUND_BGM_LOSE
//@#endif					
				))
		{
//@#if StopSoundBeforePlay
//@            GLLibPlayer.Snd_Stop(channel);
//@#endif


//@#endif//BGMPlayOnce
//@#if NO_SFX_STONE_BREAK
//@            if( id == DATA.SOUND_STONE_BREAK )
//@				return;
//@#endif
		GLLibPlayer.Snd_Play(channel, id, loop, volume, 0);
//@#if BGMPlayOnce            
		}
//@#endif   
	*/
	if ( channel == DSound_Channel.BGM)
		loop = 100;
	if(id == DATA.SOUND_BGM_LOSE
		|| id == DATA.SOUND_BGM_LEVEL_CLEAR
	)
		loop = 1;
	GLLibPlayer.Snd_Play(channel, id, loop, volume, 0);         
	}
}
	// Softkeys
var 				SOFTKEY_NONE = -1;
var 				SOFTKEY_ARROW = -2;
var 				SOFTKEY_ARROW_COLOR = 0xFFFFFF;
var 				SOFTKEY_ARROW_SIZE = 10;

// Softkey var indexes
var 									LSKIndex;
var 									RSKIndex;

// -----------------------------------------------------------------------------------------------------------------------------------------
// SOFTKEYS

// Draw softkeys or arrows to the screen
//@#if UseCommandBar		
//@	void this.drawSoftKeys()
//@	{
//@		displayCommandBar((LSKIndex > SOFTKEY_NONE?Text_GetString(LSKIndex):""), (RSKIndex > SOFTKEY_NONE?Text_GetString(RSKIndex):""));
//@#else	
CGame.prototype.drawSoftKeys = function()//throws Exception
{
	CGame.txtSetFont(fontSprBig);
	fontSpr.SetCurrentPalette(0);
	// Draw softkey strings if they are set
	if (LSKIndex > SOFTKEY_NONE)
	{
		if(LSKIndex != TEXT.MENU_SK_SELECT ) //bugID 9736143
			CGame.txtDraw(MENU_SOFT_BOTTON_PAL, Text_GetString(LSKIndex), 0, GLLibConfig.screenHeight, BOTTOM | LEFT);
	}
	if (RSKIndex > SOFTKEY_NONE)
		CGame.txtDraw(MENU_SOFT_BOTTON_PAL, Text_GetString(RSKIndex), GLLibConfig.screenWidth, GLLibConfig.screenHeight, BOTTOM | RIGHT);

	// Draw Arrows if they are set
	if (LSKIndex == SOFTKEY_ARROW)
	{
		SetColor(SOFTKEY_ARROW_COLOR);
	}
	if (RSKIndex == SOFTKEY_ARROW)
	{
		SetColor(SOFTKEY_ARROW_COLOR);
	}
//@#endif		
}

// Set softkeys to either a var index, SOFTKEY_NONE or SOFTKEY_ARROW
CGame.prototype.setSoftKeys = function(ok, back)
{
	if(GLLibConfig.softkeyOKOnLeft)
	{
		LSKIndex = ok;
		RSKIndex = back;
	}
	else
	{
		LSKIndex = back;
		RSKIndex = ok;
	}
}

// Clears the current softkey assignment
CGame.prototype.clearSoftKeys = function()
{
	LSKIndex = RSKIndex = SOFTKEY_NONE;
}


	// Menus
var 				MENU_PAUSE_BACKGROUND_COLOR = 0xdfc9a3;
var 				MENU_BACKGROUND_COLOR = 0x000000;
var 				MENU_SELECTION_BAR_COLOR = 0x88222222;
var 				MENU_MAIN_X = DGUI.MENU_MAIN_X;
var 				MENU_MAIN_Y = DGUI.MENU_MAIN_Y;//xxh//90;
var 				MENU_IGM_X = DGUI.MENU_IGM_X;//50;
var 				MENU_IGM_Y = DGUI.MENU_IGM_Y;
var 				MENU_OPTIONS_Y_OFFSET = DGUI.MENU_OPTIONS_Y_OFFSET;//-50;
var 				MENU_OPTIONS_SPACING = DGUI.MENU_OPTIONS_SPACING;//32;
var 						PARENT_TITLE_OFFSET_POS_Y = 80;
var 						OPTIONS_OFFSET_POS_Y = 50;
// menu igp
var                MENU_IGP_X_OFF = DGUI.MENU_IGP_X_OFF;
var                MENU_IGP_Y_OFF = DGUI.MENU_IGP_Y_OFF;
// menu item font palette
var 				MENU_TITLE_PAL = 0;
var 				MENU_SOFT_BOTTON_PAL = 0;
var 				MENU_ITEM_COMMON_NOT_SELECT_PAL = 0;
var				MENU_ITEM_COMMON_SELECT_PAL = 1;
var				MENU_ITEM_IGP_NOT_SELECT_PAL = 3;

var s_IGPNewImg = null;

// Menu state variables
var 									currentMenuDepth = 0;
var 									currentMenu;
var									menuSelection;


// -----------------------------------------------------------------------------------------------------------------------------------------
// MENUS

// Menu flow property enumerator
var MENU = {};
{
	MENU.STATE 						= 0;
	MENU.TITLE_AS_CHILD 	= MENU.STATE + 1;
	MENU.TITLE_AS_PARENT 	= MENU.TITLE_AS_CHILD + 1;
	MENU.LSK_TEXT 				= MENU.TITLE_AS_PARENT + 1;
	MENU.RSK_TEXT 				= MENU.LSK_TEXT + 1;
	MENU.CHILD_INDEXES 		= MENU.RSK_TEXT + 1;

	// The maximum depth of the menu stack
	MENU.MAX_DEPTH 				= 10;
};

// Special sound selection menus based on the state of SOUND_STATE_AS_LEVELS
var ASK_SOUND_NOLEVEL =
					[ STATE.ASK_SOUND_LEVEL,				TEXT.MENU_SOUND,			TEXT.MENU_SOUND, 				TEXT.MENU_SK_SELECT, TEXT.MENU_SK_BACK, 11, 12 ];

var ASK_SOUND_LEVEL =
					[ STATE.ASK_SOUND_LEVEL,				TEXT.MENU_SOUND,			TEXT.MENU_SOUND, 				TEXT.MENU_SK_SELECT, TEXT.MENU_SK_BACK, 17, 18, 19, 20 ];

// Menu flow array, see varerface MENU above for property enumeration
// STATE: The current state for the menu
// TITLE_AS_CHILD: The var index to be displayed when the menu is listed as a child on a parent menu
// TITLE_AS_PARENT: The var index to be displayed at the top of the menu when it is the parent
// LSK_TEXT: The var index to be displayed on the left softkey, can also use SOFTKEY_NONE or SOFTKEY_ARROW
// RSK_TEXT: The var index to be displayed on the right softkey, can also use SOFTKEY_NONE or SOFTKEY_ARROW
// CHILD_INDEXES: The indexes of the child menus when this is a parent menu
var s_menuFlow =
[
	/* #    { <STATE>, 								<TITLE_AS_CHILD>, 				<TITLE_AS_PARENT>, 				<LSK_TEXT>, 			<RSK_TEXT>, 			<CHILD_INDEXES> } */
	/* 0 */ [ STATE.MENU_MAIN, 						TEXT.MENU_MAIN_MENU, 			-1, 							TEXT.MENU_SK_SELECT, 	SOFTKEY_NONE,			39, 35, 6, 2, 4, 5 ], // Remove exit mennu
	/* 1 */ [ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27 ],
	/* 2 */ [ STATE.MENU_OPTIONS, 					TEXT.MENU_OPTIONS, 				TEXT.MENU_OPTIONS, 				TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		16, 9, 10 ],
	/* 3 */	[],
	/* 4 */ [ STATE.MENU_HELP, 						TEXT.MENU_HELP, 				TEXT.MENU_HELP, 				TEXT.MENU_SK_NEXT,  	TEXT.MENU_SK_BACK, ],
	/* 5 */ [ STATE.MENU_ABOUT, 					TEXT.MENU_ABOUT, 				TEXT.MENU_ABOUT, 				SOFTKEY_NONE,  			TEXT.MENU_SK_BACK, ],
	/* 6 */ [ STATE.MENU_GET_MORE_GAMES, 			TEXT.MENU_GET_MORE_GAMES ],
	/* 7 */ [ STATE.MENU_EXIT, 						TEXT.MENU_EXIT, 				TEXT.MENU_ARE_YOU_SURE, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 8 */ [ STATE.ASK_SOUND, 						TEXT.MENU_SOUND, 				TEXT.MENU_ENABLE_SOUND_QUESTION,TEXT.MENU_SK_SELECT, 	SOFTKEY_NONE,			11, 12 ],
	/* 9 */ [ STATE.SELECT_LANGUAGE, 				TEXT.MENU_LANGUAGE, 			TEXT.MENU_LANGUAGE, 			TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK,],
	/* 10 */[ STATE.RESET_GAME, 					TEXT.MENU_RESET_GAME, 			TEXT.MENU_THE_GAME_DATA, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 11 */[ STATE.NO, 							TEXT.MENU_SK_NO ],
	/* 12 */[ STATE.YES, 							TEXT.MENU_SK_YES ],
	/* 13 */[ STATE.MENU_INGAME, 					TEXT.MENU_INGAME,				TEXT.MENU_INGAME,				TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK,		36, 37, 41, 14, 4, 15, 6 ], // Remove exit mennu
	/* 14 */[ STATE.MENU_INGAME_OPTIONS, 			TEXT.MENU_OPTIONS, 				TEXT.MENU_OPTIONS, 				TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		16, ],
	/* 15 */[ STATE.MENU_INGAME_MAIN_MENU,			TEXT.MENU_MAIN_MENU,			TEXT.MENU_ARE_YOU_SURE, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 16 */ ASK_SOUND_NOLEVEL,
	/* 17 */[ STATE.SOUND_OFF, 						TEXT.MENU_OFF ],
	/* 18 */[ STATE.SOUND_LOW, 						TEXT.MENU_SND_LOW ],
	/* 19 */[ STATE.SOUND_MEDIUM, 					TEXT.MENU_SND_MEDIUM ],
	/* 20 */[ STATE.SOUND_HIGH, 					TEXT.MENU_SND_LOUD ],
	/* 21 */[ STATE.GAMEPLAY_UPDATE, 				TEXT.MENU_SELECT_LEVEL, ],
	/* 22 */[ STATE.GAMEOVER, 						TEXT.MENU_GAME_OVER, ],
	/* 23 */[ STATE.LOAD_UNLOAD, 					TEXT.MENU_LEVEL1, ],
	/* 24 */[ STATE.LOAD_UNLOAD, 					TEXT.MENU_LEVEL2, ],
	/* 25 */[ STATE.LOAD_UNLOAD, 					TEXT.MENU_LEVEL3, ],
	/* 26 */[ STATE.LOAD_UNLOAD, 					TEXT.MENU_LEVEL4, ],
	/* 27 */[ STATE.LOAD_UNLOAD, 					TEXT.MENU_LEVEL5, ],
	/* 28 */[ STATE.MENU_SELECT_WORLD,				TEXT.MENU_SELECT_WORLD, 		TEXT.MENU_SELECT_WORLD, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		54, 29, 30, 31, 32, 33, 34 ],
	/* 29 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_LABYRINTH_WORLD,		TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27 ],
	/* 30 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_PIRATE_SHIP, 			TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27  ],
	/* 31 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_CAKE_WORLD, 			TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27 ],
	/* 32 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_ICE_WORLD, 			TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27  ],
	/* 33 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_SPACE_WORLD, 			TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27  ],
	/* 34 */[ STATE.MENU_SELECT_LEVEL, 				TEXT.MENU_GHOST_TOWN, 			TEXT.MENU_SELECT_LEVEL, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		23, 24, 25, 26, 27  ],
	/* 35 */[ STATE.MENU_NEW_GAME, 					TEXT.MENU_NEW_GAME, 			TEXT.MENU_THE_GAME_DATA, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 36 */[ STATE.RESUME_GAME, 					TEXT.MENU_RESUME, ],	
	/* 37 */[ STATE.RESTART_LEVEL, 					TEXT.MENU_RESTART_LEVEL, 		TEXT.MENU_ARE_YOU_SURE, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 38 */[ STATE.GAME_STATISTIC, 				TEXT.MENU_GAME_OVER, ],
	/* 39 */[ STATE.CONTINUE_GAME,          		TEXT.MENU_CONTINUE, 			-1, 							SOFTKEY_NONE, 			SOFTKEY_NONE, 			40, -1],
	/* 40 */[ STATE.MENU_MAP,               		TEXT.MENU_CONTINUE, 			-1, 							SOFTKEY_NONE, 			SOFTKEY_NONE, 			-1, -1],
	/* 41 */[ STATE.BACK_TO_MINIMAP,        		TEXT.MENU_BACK_TO_CASTLE, 		TEXT.MENU_ARE_YOU_SURE, 		TEXT.MENU_SK_SELECT, 	TEXT.MENU_SK_BACK, 		11, 12 ],
	/* 42 */[ STATE.GAMEEND, 						TEXT.MENU_THE_END, ],
	//A.W Add Tnb Menu Flow
	/* 43 */[ STATE.BTN_TNB_OK,						TEXT.MENU_TNB_OK, ],
	/* 44 */[ STATE.BTN_TNB_CANCEL,					TEXT.MENU_TNB_CANCEL, ],
	/* 45 */[ STATE.POPUP_TNB_CONFIRM,				TEXT.MENU_TNB_BUYGAME, 			-1,								SOFTKEY_NONE,			TEXT.MENU_SK_BACK,		54, 49],
	/* 46 */[ STATE.BTN_TNB_DEMO,					TEXT.MENU_TNB_DEMO, ],
	/* 47 */[ STATE.BTN_TNB_PURCHASECODE,			TEXT.MENU_TNB_PURCHASECODE, ],
	/* 48 */[ STATE.BTN_TNB_GETNOW,					TEXT.MENU_TNB_GETNOW, ],
	/* 49 */[ STATE.BTN_TNB_TC,						TEXT.MENU_TNB_TC, 				-1,								SOFTKEY_NONE,			TEXT.MENU_SK_BACK,		43],
	/* 50 */[ STATE.BTN_TNB_TRY,					TEXT.MENU_TNB_TRY, ],
	/* 51 */[ STATE.POPUP_TNB_PLAY_DEMO,			TEXT.MENU_TNB_DEMO,				-1,								SOFTKEY_NONE,			TEXT.MENU_SK_BACK,		45, 46 ],
	/* 52 */[ STATE.POPUP_TNB_PROBLEM,				-1, 							TEXT.MENU_TNB_PROBLEM,			SOFTKEY_NONET,			SOFTKEY_NONE,			43 ],
	/* 53 */[ STATE.MENU_TNB_MAIN,					TEXT.MENU_MAIN_MENU,			-1,								SOFTKEY_NONE,			SOFTKEY_NONE,			45, 51, 47 ],
	/* 54 */[ STATE.POPUP_TNB_DOUBLE_CONFIRM,		TEXT.MENU_TNB_BUYGAME,			],
];

var MENU_INGAME_INDEX = 13;
var MENU_ABOUT_INDEX = 5;
var ASK_SOUND_INDEX = 8;
var MENU_SELECT_WORLD_INDEX = 28;
var MENU_THE_END_INDEX = 42;

CGame.isFullGame = function() {
	return GLLibConfiguration.tnb_enable && true;
}

CGame.initMenus = function()
{
//@		#if INIT_CLASS_EARLY
//@		CEntity.RemoveAll();
//@		#endif
	menuSelection = LowAPI.Gen_Array([MENU.MAX_DEPTH], 0);//new var[MENU.MAX_DEPTH];
	//A.W Cheat init default state
	if ( this.isFullGame() )
		var defaultInitMenuId = 0;  //STATE.MENU_MAIN
	else
		var defaultInitMenuId = 53;	//STATE.MENU_TNB_MAIN
	
	currentMenu = LowAPI.Gen_Array([MENU.MAX_DEPTH], defaultInitMenuId);//new var[MENU.MAX_DEPTH];
	currentMenuDepth = 0;
	if (_splash == null) {
		Pack_Open(DATA.PACK_SPLASH);
		if (DEF.dbgEnable) Dbg("---------------------- splash.. load");
		// _splash = new ASprite();
		// _splash.Load(Pack_ReadData(DATA.SPLASH_SPLASH), 0);
		_splash = CGame.LoadSprite(DATA.SPLASH_SPLASH, -1, true, false);
//@#if CacheSpalshForOptimize
//@            for( var i = 0 ; i < _splash._palettes ; i ++ )
//@                _splash.BuildCacheImages(i, 0, -1, -1);
//@#endif
			Pack_Close();
		}
		if (CGame._interface == null) {
			Pack_Open(DATA.PACK_SPRITE);
			// CGame._interface = new ASprite();
			// CGame._interface.Load(Pack_ReadData(DATA.SPRITE_INTERFACE), 0);
			CGame._interface = CGame.LoadSprite(DATA.SPRITE_INTERFACE, -1, true, false);
			Pack_Close();
		}
//@#if TOUCH_SCREEN
		if (_touchInterface == null) {
			Pack_Open(DATA.PACK_SPRITE);
			// _touchInterface = new ASprite();
			// _touchInterface.Load(Pack_ReadData(DATA.SPRITE_TOUCHINTERFACE), 0);
			_touchInterface = CGame.LoadSprite(DATA.SPRITE_TOUCHINTERFACE, -1, true, false);
			Pack_Close();
		}
//@#endif
	if (_menuIngame == null) {
		Pack_Open(DATA.PACK_SPRITE);
		// _menuIngame = new ASprite();
		// _menuIngame.Load(Pack_ReadData(DATA.SPRITE_MENUINGAME), 0);
		_menuIngame = CGame.LoadSprite(DATA.SPRITE_MENUINGAME, -1, true, false);
		Pack_Close();
	}
//@	#if not RemoveFireworks
	if (_fireworkSprite == null) {
		Pack_Open(DATA.PACK_SPRITE);
		// _fireworkSprite = new ASprite();
		// _fireworkSprite.Load(Pack_ReadData(DATA.SPRITE_FIREWORK), 0);
		_fireworkSprite = CGame.LoadSprite(DATA.SPRITE_FIREWORK, -1, true, false);
		Pack_Close();
	}

	//A.W: Init TnB Popup BG Sprite 
	if (!this.isFullGame() && _tnbPopupSprite == null) {
		Dbg("*** [AW] Load tnb popup sprite");
		Pack_Open(DATA.PACK_SPRITE);
		_tnbPopupSprite = CGame.LoadSprite(DATA.SPRITE_MENUINGAME, -1, true, false);
		Pack_Close();
	}
//@	#endif

}

//@#if not SupportNokiaAPI
var m_menuPanelGreyBar;
//@#if BREW_Alpha
//@//	var m_menuPanelGreyBar_brewAlphaData;
//@	var s_brewAlphaData;
//@#endif // BREW_Alpha

var _screenImageBuffer = null;
var _graphicsScreenBuffer;
var g_bak;
//@#endif //SupportNokiaAPI
var currentEachOptionIndex = [1,2,3,4,5,6,5]; // Remove menu exit
var currentHeadIndex = 0;
var _currentOptionHead = currentEachOptionIndex[currentHeadIndex];
var _currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
CGame._menuShiftPos = 0;
var _shiftToUp = false;
var _shiftToDown = false;
var _menuStartOffsetPos_Y = 0;
//static var OnOrOff[] = {Text_GetString(TEXT.MENU_ON), Text_GetString(TEXT.MENU_OFF)};
var _currentSoundOption = 0;
var _enterintoTheHelpFromIGM = false;
//@#if BREW_IGP_NEW
//@	var k_blink_text_show_time = 5 ;
//@	var k_blink_text_hide_time = 3 ;
//@	var k_blink_text_whole_time = k_blink_text_show_time + k_blink_text_hide_time ;
//@#endif // BREW_IGP_NEW
CGame.prototype.updateMenu = function() //throws Exception
{
	// Skip over invalid menu entries
	while ((Language.count == 1 && s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.SELECT_LANGUAGE) ||
				(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.CONTINUE_GAME && CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY) ||
				(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.RESTART_LEVEL && CGame.bIsMiniMap) ||
				(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.BACK_TO_MINIMAP && CGame.bIsMiniMap) ||
					(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.RESTART_LEVEL && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
					(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.BACK_TO_MINIMAP && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
					 (!( Build.useIGP && _is_igp_actived )&& s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.MENU_GET_MORE_GAMES))
		{
			menuSelection[currentMenuDepth]++;

		if (menuSelection[currentMenuDepth] > s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES - 1)
			menuSelection[currentMenuDepth] = 0;

		CGame.redrawAll = true;
	}
//@#if removeTextWaveEffect
//@        if(!CGame.bIsPaused)
//@#endif
		CGame.redrawAll = true;
	var spacingOffset = 0;
	var currentSelect = 0;
	var currentSelectID = 0;
	var currentSelectIndex = 0;
	var soundSelected = false;
		_enterintoTheHelpFromIGM = false;
	if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {			
		for (var i = 0; i < currentEachOptionIndex.length; i++) {
			if (menuSelection[currentMenuDepth] == currentEachOptionIndex[i]) {
				currentSelectIndex = i;
				break;
			}
		}		
		currentSelect = currentEachOptionIndex[currentSelectIndex]; // currentSelect = menuSelection[currentMenuDepth]
	}
	
	
	// Draw the menu
		if (CGame.redrawAll || s_game_interruptNotify)
	{
		var halfWidth = GLLibConfig.screenWidth / 2;
		var halfHeight = GLLibConfig.screenHeight / 2;

		// Refresh action phase background if in the IGM
		if (CGame.bIsPaused) {
			if (CGame.bIsMiniMap) {
				this.DrawMiniMap();
			} else {
				this.gameDraw();					
			}
		}
		// Fill background
		var backgroundHeight = 0;
		var backgroundTopPosY = 0;
		var optionsStartPosY = 0;
		if (CGame.bIsPaused) {
			var rc_menu = LowAPI.Gen_Array([4], 0);//new var[4];
			var mw,mh;
			_menuIngame.GetAFrameRect(rc_menu, DAnimID.MENU_INGAME_INGAMEMENU, 0, 0, 0, 0);
			mw = rc_menu[DEF.BOX_RIGHT] - rc_menu[DEF.BOX_LEFT];
			mh = rc_menu[DEF.BOX_BOTTOM] - rc_menu[DEF.BOX_TOP];
			var startx = halfWidth - (mw>>1);
//@	#if HEIGHT220
//@				var starty = halfHeight - (mh>>1) - 5;
//@	#else
			var starty = halfHeight - (mh>>1);
//@	#endif
			backgroundHeight = mh - DGUI.INGAMEMENU_BACKGROUND_WH;
			backgroundTopPosY = starty + DGUI.INGAMEMENU_BACKGROUND_XY;
//@	#if WIDTH_320
//@				CGame.FillArgbRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W - 144, mh - DGUI.BACKGROUND_OFFSET_H, 0xc8000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@	#else
				CGame.FillArgbRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W, mh - DGUI.BACKGROUND_OFFSET_H, 0xc8000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@	#endif
				_menuIngame.PaintAFrame(g, DAnimID.MENU_INGAME_INGAMEMENU, 0, startx - rc_menu[DEF.BOX_LEFT], starty - rc_menu[DEF.BOX_TOP], 0);
			} else if (CGame.bIsTnBPopup) {
				_splash.PaintAFrame(g, currentSplash, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
				var rc_menu = LowAPI.Gen_Array([4], 0);
				var mw,mh;
				_tnbPopupSprite.GetAFrameRect(rc_menu, DAnimID.MENU_INGAME_INGAMEMENU, 0, 0, 0, 0);
				mw = rc_menu[DEF.BOX_RIGHT] - rc_menu[DEF.BOX_LEFT];
				mh = rc_menu[DEF.BOX_BOTTOM] - rc_menu[DEF.BOX_TOP];
				var startx = halfWidth - (mw>>1);
				var starty = halfHeight - (mh>>1);
				backgroundHeight = mh - DGUI.INGAMEMENU_BACKGROUND_WH;
				backgroundTopPosY = starty + DGUI.INGAMEMENU_BACKGROUND_XY;
				CGame.FillArgbRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W, mh - DGUI.BACKGROUND_OFFSET_H, 0xc8000000 | MENU_PAUSE_BACKGROUND_COLOR);
				_tnbPopupSprite.PaintAFrame(g, DAnimID.MENU_INGAME_INGAMEMENU, 0, startx - rc_menu[DEF.BOX_LEFT], starty - rc_menu[DEF.BOX_TOP], 0);
				
			} else {
				_splash.PaintAFrame(g, currentSplash, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);			
			}

		var parentTitle = s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_PARENT];
		// Draw parent title
		var titleH = 0;
		var maxLengthPerLine = DEF.VIEW_W - 0;
		var startLine = 0;
		var lineCount = 10;
		var align = 1;
		var lineInterval = 5;
		if (parentTitle > 0 && !CGame.bIsPaused) {
				CGame.DrawMultiLineText ( g, Text_GetString(parentTitle), halfWidth, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y), align, 2, maxLengthPerLine, startLine, lineCount, lineInterval); 
			titleH += OPTIONS_OFFSET_POS_Y; //50;
		} else if (CGame.bIsPaused) {
			if (parentTitle == TEXT.MENU_ARE_YOU_SURE) {
				CGame.txtDraw(MENU_TITLE_PAL, Text_GetString(parentTitle), halfWidth, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y), TOP | HCENTER);
			}
			var optionsNum = s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES;
			for (var i = 0 ,j = 0; i < s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES; i++)
			{
				var childMenu = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + i]];

				if ((Language.count == 1 && childMenu[MENU.STATE] == STATE.SELECT_LANGUAGE) ||
						(childMenu[MENU.STATE] == STATE.CONTINUE_GAME && CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY) ||
						(childMenu[MENU.STATE] == STATE.RESTART_LEVEL && CGame.bIsMiniMap) ||
						(childMenu[MENU.STATE] == STATE.BACK_TO_MINIMAP && CGame.bIsMiniMap) ||
							(childMenu[MENU.STATE] == STATE.RESTART_LEVEL && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
							(childMenu[MENU.STATE] == STATE.BACK_TO_MINIMAP && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
						(!( Build.useIGP && _is_igp_actived ) && childMenu[MENU.STATE] == STATE.MENU_GET_MORE_GAMES))
				{
					--optionsNum;
					continue;
				}
			}
			var allOptionsHeight = (MENU_OPTIONS_SPACING +6) * (optionsNum)- ASprite.GetCurrentStringHeight(); // + (ASprite.GetCurrentStringHeight()>>1) * optionsNum;
			var startPosY = backgroundTopPosY + (backgroundHeight - allOptionsHeight)/2;
			//titleH -= 80;
			optionsStartPosY = startPosY;
		}
		// Set and draw softkeys
//			if (!_enterintoTheHelpFromIGM) {
//				this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
//				this.drawSoftKeys();
//			}
		var shiftDistance = -1*MENU_OPTIONS_SPACING; //ASprite.GetCurrentStringHeight();
		var topClipLinePos_Y = (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) - 5 * DScreen.RATIO;
		var bottomClipLinePos_Y = topClipLinePos_Y + MENU_OPTIONS_SPACING * 5;

		if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {					
			//currentSelectPos_Y = (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) - currentSelect*MENU_OPTIONS_Y_OFFSET;
			if (currentSelect > _currentOptionTail) {
				currentHeadIndex = currentSelectIndex - 4;
				_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
				_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
				_menuStartOffsetPos_Y = (currentSelectIndex-4)*(shiftDistance);
				CGame._menuShiftPos = (-1)*(shiftDistance);
				_shiftToUp = true;			
			}
		
			if (currentSelect < _currentOptionHead) {
				currentHeadIndex = currentSelectIndex;
				_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
				_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
				_menuStartOffsetPos_Y = _menuStartOffsetPos_Y - (shiftDistance);
				CGame._menuShiftPos = (shiftDistance);
				_shiftToDown = true;						
			}
			
			//g.drawLine(49, topClipLinePos_Y, 200, topClipLinePos_Y);
			//g.drawLine(49, bottomClipLinePos_Y, 200, bottomClipLinePos_Y);
			//g.setClip(49, (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH)-5, 140, MENU_OPTIONS_SPACING*5);
		}
		// Draw child options and selection bar
		if (CGame.bIsTnBPopup){
			var str = "";
			var contentId = 0;
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.POPUP_TNB_PLAY_DEMO) {
				contentId = TEXT.MENU_TNB_DEMO_CONTENT;
				titleH = 50;
			}

			var strContent = Text_GetString(contentId);
			for (var i=0; i<strContent.length; i++) {
				if (strContent.charAt(i) == '^') {
					str = str + "\n";
				} else {
					str = str + strContent.charAt(i);
				}
			}
			strContent = str;

			var align = 1;
			var lineWidth = DEF.VIEW_W;
			var posX = halfWidth;
			var posY = DGUI.HELP_POSY - 25;
			var startLine = 0;
			var lineCount = 20;
			var lineInterval = 5;

			CGame.txtSetFont(fontSprSmall);

			CGame.DrawMultiLineText(g, strContent, posX, posY, align, 2, lineWidth, startLine, lineCount, lineInterval);

			CGame.txtSetFont(fontSprBig);

			//titleH = 55;
		}
		for (var i = 0 ,j = 0; i < s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES; i++)
		{
			var childMenu = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + i]];

			if ((Language.count == 1 && childMenu[MENU.STATE] == STATE.SELECT_LANGUAGE) ||
					(childMenu[MENU.STATE] == STATE.CONTINUE_GAME && CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY) ||
					(childMenu[MENU.STATE] == STATE.RESTART_LEVEL && CGame.bIsMiniMap) ||
					(childMenu[MENU.STATE] == STATE.BACK_TO_MINIMAP && CGame.bIsMiniMap) ||
						(childMenu[MENU.STATE] == STATE.RESTART_LEVEL && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
						(childMenu[MENU.STATE] == STATE.BACK_TO_MINIMAP && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END)) ||
					(!( Build.useIGP && _is_igp_actived ) && childMenu[MENU.STATE] == STATE.MENU_GET_MORE_GAMES))
			{
				continue;
			}
				if (_enterintoTheHelpFromIGM) {
				continue;
			}
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {
					currentEachOptionIndex[j++] = i;
					_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
					_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
		
			}
			//currentEachOptionIndex[i] = i; 
			//Draw menu bar.
			if (!CGame.bIsPaused) {
				var oh = ASprite.GetCurrentStringHeight()>>1;
//					
//					// draw igp arrow
				
				/*if( ( Build.useIGP && _is_igp_actived ) && (childMenu[MENU.STATE] == STATE.MENU_GET_MORE_GAMES) )
				{
					g.setClip(DGUI.IGP_NEW_CLIPX, (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) -5, DEF.VIEW_W + DGUI.IGP_NEW_CLIP_WIDTH, MENU_OPTIONS_SPACING*5);
					try
					{
//@#if BREW_IGP_NEW
//@							if (updateIGP_IsNew() && ((s_game_currentFrameNB % k_blink_text_whole_time) > k_blink_text_hide_time))
//@							{
//@								if (CGame.spriteArray[DSpriteID.IGP_NEW] == null)
//@								{
//@									Pack_Open(DATA.PACK_SPRITE);
//@									CGame.spriteLoad(DSpriteID.IGP_NEW, DATA.SPRITE_IGP_NEW, true, false);
//@									Pack_Close();
//@								}
//@								CGame.spriteArray[DSpriteID.IGP_NEW].PaintFrame(
//@									g, 
//@									0, 
//@									MENU_IGM_X + MENU_IGP_X_OFF, 
//@									(halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) + spacingOffset - oh + MENU_IGP_Y_OFF + _menuStartOffsetPos_Y, 
//@									0);
//@							}
//@#else // BREW_IGP_NEW
						if (s_IGPNewImg == null)
								s_IGPNewImg = Image.createImage("/n.png");
						IGP.drawNewArrow(g, s_IGPNewImg, MENU_IGM_X + MENU_IGP_X_OFF, (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) + spacingOffset - oh + MENU_IGP_Y_OFF + _menuStartOffsetPos_Y - 3, Graphics.RIGHT | Graphics.TOP );
//@#endif // BREW_IGP_NEW
					}
					catch(e)
					{
							if (DEF.dbgEnable) Dbg(" ---------------------------------- error igp : " + e.message);
					}
				}*/
				
			}

//#if SupportNokiaAPI
//				dg.setARGBColor(MENU_SELECTION_BAR_COLOR);
//				if (menuSelection[currentMenuDepth] == i)
//				{
//					if (CGame.bIsPaused) {
//						FillRect(MENU_IGM_X, (halfHeight + MENU_OPTIONS_Y_OFFSET) + spacingOffset - 1, GetScreenWidth() - (MENU_IGM_X << 1), 13);
//					}
//					else {
//						FillRect(MENU_MAIN_X, (halfHeight + MENU_OPTIONS_Y_OFFSET) + spacingOffset - 1, GetScreenWidth() - (MENU_MAIN_X << 1), 13);
//					}
//				} 
//#else //SupportNokiaAPI
//				if (m_menuPanelGreyBar == null)
//				{
//					if (CGame.bIsPaused)
//						;
//					else
//						m_menuPanelGreyBar = CreateTransparentImage(
//								GetScreenWidth() - (MENU_MAIN_X << 1), 13,
//								0, 100
//						);
//				}
//				if (menuSelection[currentMenuDepth] == i)
//				{
//					if (CGame.bIsPaused)
//						;
//					else
//						g.drawImage(m_menuPanelGreyBar, MENU_MAIN_X, (halfHeight + MENU_OPTIONS_Y_OFFSET) + spacingOffset - 1, 0);
//				}
//#endif //SupportNokiaAPI

			//var y = (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) + spacingOffset;
			var textId = childMenu[MENU.TITLE_AS_CHILD];
			if (s_game_state == STATE.MENU_SELECT_LEVEL) {
				textId = this.GetLevelTextByLevelId(CGame._worldId * DAI.LEVELS_NUM_PRE_WORLD) + i;
			}
			var y;
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {	
				g.setClip(DGUI.MENU_MAIN_CLIPX, (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) - DGUI.MENU_MAIN_CLIPOFFSETH, DGUI.MENU_MAIN_CLIPW, MENU_OPTIONS_SPACING*5);
				y = (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) + spacingOffset + _menuStartOffsetPos_Y;
			} else {
				y = (halfHeight + MENU_OPTIONS_Y_OFFSET + titleH) + spacingOffset;
			} 
			if (CGame.bIsPaused) {
				y = optionsStartPosY + spacingOffset;
			}
			
			var  textPos = null;
			var options = Text_GetString(textId);
			// !!! Fake get text for each language.
			if(Language.count > 1 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.SELECT_LANGUAGE) {
				var id = childMenu[MENU.TITLE_AS_CHILD] - TEXT.MENU_LANGUAGE_NAME;
				options = languageArrayTextId[id]
			}
			var on = Text_GetString(TEXT.MENU_ON);
			var off = Text_GetString(TEXT.MENU_OFF);
			var OnOrOff = [" "+on, " "+off];
			if(CGame.isSoundEnabled)
				_currentSoundOption = 0;
			else
				_currentSoundOption = 1;
			if(s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] != STATE.MENU_MAIN) {
				if ((options == (Text_GetString(TEXT.MENU_SOUND))|| options == (Text_GetString(TEXT.MENU_OPTIONS)) )){
					options = Text_GetString(TEXT.MENU_SOUND) + OnOrOff[_currentSoundOption];
					if (menuSelection[currentMenuDepth] == i) {
						soundSelected = true;
					}
				}
			}
			
				if (s_game_interruptNotify) {
				menuSelection[currentMenuDepth] = 0;
				currentHeadIndex = 0;
				_menuStartOffsetPos_Y = 0;
				_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
				_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
			}
			if(menuSelection[currentMenuDepth] == i) {
				currentSelectID = childMenu[MENU.TITLE_AS_CHILD];
				if (s_game_state == STATE.MENU_SELECT_LEVEL) {
					currentSelectID = this.GetLevelTextByLevelId(CGame._worldId * DAI.LEVELS_NUM_PRE_WORLD) + i;
				}
				textPos = this.txtDrawSpecialEffectWave(menuSelection[currentMenuDepth] == i ? MENU_ITEM_COMMON_SELECT_PAL : MENU_ITEM_COMMON_NOT_SELECT_PAL,options, halfWidth, y+CGame._menuShiftPos, LEFT);
			} else {
				var fontPalette = (menuSelection[currentMenuDepth] == i ? MENU_ITEM_COMMON_SELECT_PAL : MENU_ITEM_COMMON_NOT_SELECT_PAL);
				if( childMenu[MENU.STATE] == STATE.MENU_GET_MORE_GAMES )
					fontPalette = MENU_ITEM_IGP_NOT_SELECT_PAL;
				CGame.txtDraw(fontPalette,options, halfWidth, y+CGame._menuShiftPos, TOP | HCENTER);
			}
			g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
			if (menuSelection[currentMenuDepth] == i) {
				var x1, x2;
				if(CGame.bIsPaused) {
					x1 = textPos[0] - 15 * DScreen.RATIO;
					x2 = textPos[1] + 15 * DScreen.RATIO;
					y += ASprite.GetCurrentStringHeight()>>1;
				} else {
					var rc2 = LowAPI.Gen_Array([4], 0);
						CGame._interface.GetAFrameRect(rc2, DAnimID.INTERFACE_MENU_CURSOR, 0, 0, 0, 0);						
//						x1 = MENU_IGM_X - 5;
//						x2 = MENU_IGM_X + DGUI.MENU_BAR_WIDTH + 5;
					x1 = textPos[0] - DGUI.MENU_ICON_OFFX;
					x2 = textPos[1] + DGUI.MENU_ICON_OFFX;
					y += ASprite.GetCurrentStringHeight()>>1;
				}
//@#if WIDTH176
//@					CGame._interface.PaintAFrame(g, DAnimID.varERFACE_MENU_CURSOR, s_game_currentFrameNB % CGame._interface.GetAFrames(DAnimID.varERFACE_MENU_CURSOR), x1-3, y, 0);
//@#else			
					CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_CURSOR, s_game_currentFrameNB % CGame._interface.GetAFrames(DAnimID.INTERFACE_MENU_CURSOR), x1, y, 0);
//@#endif
					CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_CURSOR, s_game_currentFrameNB % CGame._interface.GetAFrames(DAnimID.INTERFACE_MENU_CURSOR), x2, y, 0);
					}
//@#if TOUCH_SCREEN
			else if (!CGame.bIsPaused)
			{
				y += ASprite.GetCurrentStringHeight()>>1;
			}
			//always add half of line space when IG-MENU
			if (CGame.bIsPaused)
			{
				y += (ASprite.GetCurrentStringHeight()>>1) + TOUCH_IGMENU_OFFSET_Y;
				
			}
			var isArrowDownVisiable = false;
			var isArrowUpVisiable = false;
			var isArrowIgnoreListener = false;
			var itemFirst = 0;
			var itemEnd = (CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY ? 6 : 5); //Remove menu exit
			if (( _currentOptionTail > currentEachOptionIndex[3] && _currentOptionTail < currentEachOptionIndex[6]))
				isArrowDownVisiable = true;
			if ((_currentOptionHead > currentEachOptionIndex[0] && _currentOptionHead <= currentEachOptionIndex[4]))
				isArrowUpVisiable = true;
			
			/* if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN 
				&& (
					(isArrowDownVisiable // show arrow down
					&& !isArrowUpVisiable // # show arrow up
					&& i == itemEnd) // item end.
					|| (!isArrowDownVisiable // # show arrow down
					&& isArrowUpVisiable // show arrow up
					&& i == itemFirst)) // item first.
					
			) {
				if (DEF.dbgEnable) Dbg("------------------------------------------- DON'T PAINT TOUCH IN THIS CASE.");				
			} 
			else  */
			{				
				if (CGame.isPointInRect(MENU_IGM_X, y - (TOUCH_MENU_ITEM_HEIGHT>>1), 
						GetScreenWidth() - (MENU_IGM_X << 1), TOUCH_MENU_ITEM_HEIGHT))
				{			
					if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN 
					// && ((isArrowDownVisiable && ((i == (itemEnd -1)  && !isArrowUpVisiable) || (i == itemEnd && isArrowUpVisiable)))
						// || (isArrowUpVisiable && ((i == itemFirst && isArrowDownVisiable) || (i == (itemFirst + 1) && !isArrowDownVisiable))))
					// Remove menu exit
					&& ((isArrowDownVisiable && i == itemEnd && !isArrowUpVisiable)
						|| (isArrowUpVisiable && i == itemFirst && !isArrowDownVisiable))
					) {
						// if (DEF.dbgEnable) Dbg("------------------------------------------- i " + i + " isArrowUpVisiable : " + isArrowUpVisiable + " isArrowDownVisiable : " + isArrowDownVisiable + " itemEnd : " + itemEnd);
						isArrowIgnoreListener = true;
					}
					
					/* if (menuSelection[currentMenuDepth] == i) 
					{
						this.keyPressed(GLLibConfig.keycodeFire);
						// this.keyReleased(GLLibConfig.keycodeFire);
						CGame.UpdateKeyState();
						if (DEF.dbgEnable) Dbg("------------------------------------------- enter ");	
					}
					else */
					{
						if (DEF.dbgEnable) Dbg("******************************************* isArrowIgnoreListener " + isArrowIgnoreListener);
						if (!isArrowIgnoreListener)
						{
							if (( !soundSelected &&
									((s_game_state == STATE.MENU_OPTIONS && i == 0) // in MM Option
									||(s_game_state == STATE.MENU_INGAME && i == 3)) // IGM Option
								)
							)
							{
								if (DEF.dbgEnable) Dbg("******************************************* SOUND OFF -> ON");
								soundSelected = true;
							} 
							
							{
								this.keyPressed(GLLibConfig.keycodeFire);
								this.keyReleased(GLLibConfig.keycodeFire);
								CGame.UpdateKeyState();
							}
						}
						menuSelection[currentMenuDepth] = i;
						if (DEF.dbgEnable) Dbg("------------------------------------------- click , soundSelected : " + soundSelected  + " i : " + i);	
					}
					
					
				}
			}
//@#endif				
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ){
				spacingOffset += MENU_OPTIONS_SPACING;
			} else {					
				spacingOffset += MENU_OPTIONS_SPACING + 6;
			}
		}
		if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ){
			if ( _currentOptionTail > currentEachOptionIndex[3] && _currentOptionTail < currentEachOptionIndex[6]) {
					CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_ARROW_DOWN, 0, DEF.SCR_W_D2, bottomClipLinePos_Y + 9 * DScreen.RATIO, 0);
			}
			
			if (_currentOptionHead > currentEachOptionIndex[0] && _currentOptionHead <= currentEachOptionIndex[4]) {
					CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_ARROW_UP, 0, DEF.SCR_W_D2, topClipLinePos_Y - 7 * DScreen.RATIO, 0);
			}
		}
//			// Refresh action phase background if in the IGM
//			if (s_game_varerruptNotify && CGame.bIsPaused)
//				gameDraw();

		CGame.redrawAll = false;
	}

	
	_keycode = WasAnyKeyReleased();
	if (_keycode >= 0)
	{
		if (DEF.dbgEnable) Dbg("******************************************* _keycode : " + _keycode + " s_game_state : " + s_game_state);
		// On select..
		if (	((_keycode == GLKey.k_menuOK) || (_keycode == GLKey.k_fire))
			&&	currentMenuDepth < MENU.MAX_DEPTH
			)
		{
			var chose_game_state = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE];
			if (CGame.bIsPaused) {	
				var currentOption = Text_GetString(currentSelectID);
				if (currentOption == (Text_GetString(TEXT.MENU_HELP)) || chose_game_state == STATE.MENU_HELP) { // fix bug crash IGM Help.
						_enterintoTheHelpFromIGM = true;
				}
			}
			if (soundSelected && (chose_game_state == STATE.ASK_SOUND_LEVEL || chose_game_state == STATE.MENU_INGAME_OPTIONS)) {
				if (_currentSoundOption == 0) { //close the sound
					if (CGame.isSoundEnabled)
					{
						this.StopSound();
						CGame.isSoundEnabled = false;
					}
					CGame.RMS_Save();
				} else { //open the sound
					this.startSound();
					CGame.RMS_Save();
				}
				_currentSoundOption = ++_currentSoundOption % 2;
			}else {
				// Move to new menu and state
//					s_game_state = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE];
////@#if LG_KU970
////@					if(s_game_state == STATE.MENU_ABOUT){
////@						gameRepaint = true;
////@					}
////@#endif
//					int newMenu = s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]];
//					currentMenuDepth++;
//					currentMenu[currentMenuDepth] = newMenu;
//					menuSelection[currentMenuDepth] = 0;
//					PlaySound(DSound_Channel.SFX, DATA.SOUND_MENU_CONFIRM);
			}
		}
		// On back..
		else if (_keycode == GLKey.k_menuBack)
		{			
			// Pop off the stack..
			if (currentMenuDepth > 0 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT] != -1)
			{
				currentMenuDepth--;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			}
			// .. Unless we're in the root IGM menu, in which case go back to the game.
			else if (CGame.bIsPaused && s_game_state == STATE.MENU_INGAME)
			{
				if (CGame.bIsMiniMap) {
					s_game_state = STATE.MENU_MAP;
				} else {
					s_game_state = STATE.GAMEPLAY_UPDATE;
				}
				CGame.bIsPaused = false;
				this.ResumeSoundBGM();
			}
			CGame.PlaySound(DSound_Channel.SFX, DATA.SOUND_MENU_CONFIRM);
		}
		// On Up..
		if (_keycode == GLKey.k_up)
		{
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {
				if (_currentOptionHead > currentEachOptionIndex[0] || currentSelect != _currentOptionHead) {
					menuSelection[currentMenuDepth]--;
				}
			} else {
				menuSelection[currentMenuDepth]--;
			}

			if (menuSelection[currentMenuDepth] < 0)
				menuSelection[currentMenuDepth] = s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES - 1;

				// Skip over invalid menu entries
				while (	(Language.count == 1 && s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.SELECT_LANGUAGE)
					||	(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.CONTINUE_GAME && CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY)
					||	(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.RESTART_LEVEL && CGame.bIsMiniMap)
					||	(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.BACK_TO_MINIMAP && CGame.bIsMiniMap)
					||	(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.RESTART_LEVEL && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END))
					||	(s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.BACK_TO_MINIMAP && (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME || CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END))		
					||	(!( Build.useIGP && _is_igp_actived ) && s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE] == STATE.MENU_GET_MORE_GAMES)
					)
				{
					menuSelection[currentMenuDepth]--;

				if (menuSelection[currentMenuDepth] < 0)
					menuSelection[currentMenuDepth] = s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES - 1;
			}
		}
		// On Down..
		else if (_keycode == GLKey.k_down)
		{
			if (s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN ) {
				if (_currentOptionTail < currentEachOptionIndex[6] || currentSelect != _currentOptionTail) {
					menuSelection[currentMenuDepth]++;
				}
			} else {
				menuSelection[currentMenuDepth]++;
			}

			if (menuSelection[currentMenuDepth] > s_menuFlow[currentMenu[currentMenuDepth]].length - MENU.CHILD_INDEXES - 1)
				menuSelection[currentMenuDepth] = 0;
		}

		// Refresh the menu on any keypress
		CGame.redrawAll = true;
		ResetKey();
	}
	
	if (_shiftToUp) {
		CGame._menuShiftPos -= 4 * DScreen.RATIO;
		if (CGame._menuShiftPos <= 0) {
			_shiftToUp = false;
			CGame._menuShiftPos = 0;
		}
	}
	
	if (_shiftToDown) {
		CGame._menuShiftPos += 4  * DScreen.RATIO;
		if (CGame._menuShiftPos >= 0) {
			_shiftToDown = false;
			CGame._menuShiftPos = 0;
		}					
	}
	
	if (!_enterintoTheHelpFromIGM) {
		if (Language.count > 1 && s_game_state == STATE.SELECT_LANGUAGE) 
			this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], CGame.bSetLanguage ? SOFTKEY_NONE : s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
		else
			this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
		this.drawSoftKeys();
	}
	var chose_game_state  = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE];
	if ((((_keycode == GLKey.k_menuOK)&& s_game_state != STATE.MENU_INGAME) || (_keycode == GLKey.k_fire)) &&	currentMenuDepth < MENU.MAX_DEPTH && chose_game_state != STATE.ASK_SOUND_LEVEL && chose_game_state != STATE.MENU_INGAME_OPTIONS/* && !soundSelected */) { // fix bug IGM flash when press IGM icon in Menu Map.
		// Move to new menu and state
		var old_state = s_game_state;
		s_game_state = s_menuFlow[s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]]][MENU.STATE];
//@#if LG_KU970
//@					if(s_game_state == STATE.MENU_ABOUT){
//@						gameRepavar = true;
//@					}
//@#endif
		
		var newMenu = s_menuFlow[currentMenu[currentMenuDepth]][MENU.CHILD_INDEXES + menuSelection[currentMenuDepth]];
		currentMenuDepth++;
		currentMenu[currentMenuDepth] = newMenu;
		menuSelection[currentMenuDepth] = 0;
		// !!! Store cursor in menu SELECT_LANGUAGE
		if (Language.count > 1 && old_state != STATE.SELECT_LANGUAGE && s_game_state == STATE.SELECT_LANGUAGE) {
			menuSelection[currentMenuDepth] = CGame.curLanguage;
		}
		CGame.PlaySound(DSound_Channel.SFX, DATA.SOUND_MENU_CONFIRM);
	}
	// Return the new game state for handling special menus
	return s_game_state;
}
//CGame._pointerPosX = 0;
//CGame._pointerPosY = 0;
CGame._isInputEvent = false;
CGame._eventCallback = null;
CGame.prototype._FakegetMousePos = function (evt)
{
	//Dbg("Pause ========================== s_game_state : " + s_game_state);
	//super.Pause();
	return CGame.__superproto__._FakegetMousePos.call(this,evt);
}
CGame.prototype.requireUserInputEvent = function()
{

	gllib_runtime.requireUserInputEvent(function( evt) {
		
		CGame._eventCallback = evt; 
		CGame._isInputEvent = true;
		Player.processUserInputEvent();
											
	});
}

	// How long in ms to wait on the gameloft logo
CGame.GAMELOFT_LOGO_WAIT_TIME = 2000;

// Action phase paused state, if true, will bring up the IGM
CGame.bIsPaused  = false;
CGame.bIsMiniMap = false;
CGame.bIsMainMain = false;

CGame.bIsTnBPopup = false;

// redraw state for varerrupts and refreshing the screen
CGame.redrawAll = false;

// Loading variables
CGame.loadingPhase = 0;
CGame.s_next_state = 0;

// game area
CGame.gameAreaX = 0;
CGame.gameAreaY = 0;
CGame.gameAreaWidth = 0;
CGame.gameAreaHeight = 0;

CGame.playerCar = null;

// Current language
CGame.curLanguage = 0;
var 									tmpCurLanguage = 0;

// booleans to determine if language or sound need to be set for the first time
CGame.bSetLanguage = false;
CGame.bSetSound = false;

// application timer
var									timer;

//	 -----------------------------------------------------------------------------------------------------------------------------------------
//	 IGP
CGame.keyToIGPMap = null;

//	 -----------------------------------------------------------------------------------------------------------------------------------------
//	 CGMRC
CGame.s_License = null;

// // -----------------------------------------------------------------------------------------------------------------------------------------
// // STATES

// // State enumerator
// STATE = {};
// {
// 	STATE.QUIT 						= -1;
// 	STATE.INIT 						= STATE.QUIT + 1;
// 	STATE.SELECT_LANGUAGE_INIT		= STATE.INIT + 1;
// 	STATE.SELECT_LANGUAGE			= STATE.SELECT_LANGUAGE_INIT + 1;
// 	STATE.GAMELOFT_LOGO				= STATE.SELECT_LANGUAGE + 1;
// 	STATE.COPYRIGHT					= STATE.GAMELOFT_LOGO + 1;
// 	STATE.ASK_SOUND					= STATE.COPYRIGHT + 1;
// 	STATE.SPLASH						= STATE.ASK_SOUND + 1;
// 	STATE.MENU_MAIN					= STATE.SPLASH + 1;
// 	STATE.MENU_NEW_GAME				= STATE.MENU_MAIN + 1;
// 	STATE.CONTINUE_GAME              = STATE.MENU_NEW_GAME + 1;
// 	STATE.MENU_MAP					= STATE.CONTINUE_GAME + 1;
// 	STATE.MENU_SELECT_WORLD			= STATE.MENU_MAP + 1;
// 	STATE.MENU_SELECT_LEVEL			= STATE.MENU_SELECT_WORLD + 1;
// 	STATE.LOAD_UNLOAD				= STATE.MENU_SELECT_LEVEL + 1;
// 	STATE.GAMEPLAY_UPDATE			= STATE.LOAD_UNLOAD + 1;
// 	STATE.GAMEOVER					= STATE.GAMEPLAY_UPDATE + 1;
// 	STATE.GAMEEND					= STATE.GAMEOVER + 1;
// 	STATE.GAME_STATISTIC					= STATE.GAMEEND + 1;
// 	STATE.MENU_OPTIONS				= STATE.GAME_STATISTIC + 1;
// 	STATE.MENU_GET_MORE_GAMES_INIT	= STATE.MENU_OPTIONS + 1;
// 	STATE.MENU_GET_MORE_GAMES		= STATE.MENU_GET_MORE_GAMES_INIT + 1;
// 	STATE.MENU_HELP					= STATE.MENU_GET_MORE_GAMES + 1;
// 	STATE.MENU_ABOUT					= STATE.MENU_HELP + 1;
// 	STATE.MENU_EXIT					= STATE.MENU_ABOUT + 1;
// 	STATE.RESET_GAME					= STATE.MENU_EXIT + 1;
// 	STATE.RESUME_GAME				= STATE.RESET_GAME + 1;
// 	STATE.BACK_TO_MINIMAP            = STATE.RESUME_GAME + 1;
// 	STATE.RESTART_LEVEL				= STATE.BACK_TO_MINIMAP + 1;
// 	STATE.MENU_INIT					= STATE.RESTART_LEVEL + 1;
// 	STATE.NO							= STATE.MENU_INIT + 1;
// 	STATE.YES						= STATE.NO + 1;
// 	STATE.MENU_INGAME				= STATE.YES + 1;
// 	STATE.MENU_INGAME_OPTIONS		= STATE.MENU_INGAME + 1;
// 	STATE.MENU_INGAME_MAIN_MENU		= STATE.MENU_INGAME_OPTIONS + 1;
// 	STATE.ASK_SOUND_LEVEL			= STATE.MENU_INGAME_MAIN_MENU + 1;
// 	STATE.SOUND_OFF					= STATE.ASK_SOUND_LEVEL + 1;
// 	STATE.SOUND_LOW					= STATE.SOUND_OFF + 1;
// 	STATE.SOUND_MEDIUM				= STATE.SOUND_LOW + 1;
// 	STATE.SOUND_HIGH					= STATE.SOUND_MEDIUM + 1;
// 	STATE.IGP						= STATE.SOUND_HIGH + 1;

// 	STATE.K_MRC_INIT					= STATE.IGP + 1;
// 	STATE.K_MRC_VALIDATING			= STATE.K_MRC_INIT + 1;
// 	STATE.K_MRC_EXPIRED				= STATE.K_MRC_VALIDATING + 1;
// 	STATE.K_MRC_NETWORK_FAILED		= STATE.K_MRC_EXPIRED + 1;
// 	// ...
// 	STATE.END_GAME_IGP				= STATE.K_MRC_NETWORK_FAILED + 1;
// 	STATE.NEW_STATE2					= STATE.END_GAME_IGP + 1;

// 	STATE.NEW_STATE3					= STATE.NEW_STATE2 + 1;
// 	STATE.NEW_STATE4					= STATE.NEW_STATE3 + 1;
// 	STATE.NEW_STATE5					= STATE.NEW_STATE4 + 1;
// //@#if SupportLandspaceMode
// //@		var LANDSPACE					= NEW_STATE5 + 1; 
// //@#endif		
// };

// -----------------------------------------------------------------------------------------------------------------------------------------
// MAIN STATE MACHINE

// For some reason, the preprocessor does not seem to
// support multi-line macros


CGame.prototype.preUpdate = function () {
//		var aTick = Math.min(s_game_frameDT, DEF.FRAME_TICK_MAX_DELAY);
//		CGame._frameDT = aTick;
	_timeMillisForUpdate += CGame._frameDT;
	var update = _timeMillisForUpdate + (DEF.ANIMATION_FRAME_TICK / 4);
	_animationDT = update / DEF.ANIMATION_FRAME_TICK;
	_timeMillisForUpdate = _timeMillisForUpdate - (_animationDT * DEF.ANIMATION_FRAME_TICK);
	CGame._velocityRate = Math_IntToFixedPoint(DEF.VELOCITY_FRAME_TICK) / 1000; //DEF.VELOCITY_FRAME_TICK;


	if (s_game_keyLastPressed == s_game_keyJustPressed) {
		if (s_game_keyPressedTime - s_game_keyLastPressedTime > DEF.DOUBLE_PRESSED_INTERVAL) {
			s_game_keyLastPressedTime = s_game_keyPressedTime;
		}
	} else if (s_game_keyJustPressed != -1){
		s_game_keyLastPressed = s_game_keyJustPressed;
		s_game_keyLastPressedTime = s_game_keyPressedTime;
	}
}
//@#if BREW_CLR
//@	boolean GameCheckClrKey()
//@	{
//@		if (s_keyState == null)
//@		{
//@			return true;
//@		}
//@		boolean bCLRExit = false;
//@		if (WasKeyPressed(GLKey.k_clr))
//@		{
//@			switch(s_game_state)
//@			{
//@			case STATE.INIT:
//@			case STATE.SELECT_LANGUAGE_INIT:
//@			case STATE.SELECT_LANGUAGE:
//@			case STATE.GAMELOFT_LOGO:
//@			case STATE.COPYRIGHT:
//@			case STATE.ASK_SOUND:
//@			case STATE.SPLASH:
//@			case STATE.MENU_MAIN:
//@				bCLRExit = true;
//@				s_game_state = STATE.QUIT;
//@				break;
//@			case STATE.MENU_NEW_GAME:
//@				_storyPart=0;
//@				_currentBackColor = 0xff;
//@				CGame.txtSetFont(fontSprBig);
//@				_storyHasvarroduced = false;
//@				this.GotoMainMenu();
//@				break;
//@			case STATE.GAMEPLAY_UPDATE:
//@			case STATE.MENU_MAP:
//@				//this.keyPressed(GLKey.k_menuOK);
//@				this.keyPressed(GLLibConfig.keycodeLeftSoftkey);
//@				this.keyReleased(GLLibConfig.keycodeLeftSoftkey);
//@				break;
//@			case STATE.MENU_OPTIONS:
//@			case STATE.ASK_SOUND_LEVEL:
//@			case STATE.RESET_GAME:
//@			case STATE.MENU_HELP:
//@			case STATE.MENU_ABOUT:
//@			case STATE.MENU_EXIT :
//@			case STATE.MENU_INGAME_OPTIONS:
//@			case STATE.MENU_INGAME_MAIN_MENU :
//@			case STATE.RESTART_LEVEL:
//@				//this.keyPressed(GLKey.k_menuBack);
//@				this.keyPressed(GLLibConfig.keycodeRightSoftkey);
//@				this.keyReleased(GLLibConfig.keycodeRightSoftkey);
//@				break;
//@			case STATE.MENU_INGAME:
//@			case STATE.LOAD_UNLOAD:
//@				if (CGame.loadingPhase >= 0)//for safe, nothing
//@				{
//@					this.GotoMainMenu();
//@				}
//@				break;
//@			case STATE.GAME_STATISTIC :
//@				CGame._moveSpeed = 0;
//@				CGame._stopMove = false;
//@				_levelCompleteEffectStep = 0;
//@				_StatisticCompleted = false;
//@				GotoNextLevel();
//@				//  reset for the draw of title
//@				_firstEntervaroThisFunction = true;
//@				CGame._actionSpeed = 0;
//@			
//@				CGame._moveSpeed+=15;
//@				
//@				this.GotoMainMenu();
//@				break;
//@			case STATE.GAMEOVER :
//@				try {
//@					CGame.RMS_Load();
//@				} catch (Exception ex) {
//@					Dbg("CGame.RMS_Load() error");
//@					//ex.printStackTrace();
//@				}
//@				this.GotoMainMenu();
//@				break;
//@			default:
//@				break;
//@			}
//@		}
//@		return bCLRExit;
//@	}
//@#endif // BREW_CLR
//@#if BREW_WithoutBuffer
//@	static Image s_brewScreenImage = null;
//@#endif // BREW_WithoutBuffer
var currentSplash = 2;
var pre_game_State = 0;
CGame.prototype.Game_update = function()// throws Exception
{
	// fix bug don't reset key when switch state.
	// if(pre_game_State != s_game_state)
	// {
		// pre_game_State = s_game_state;
		// ResetKey();
	// }
	// Dbg("Game_update ========================== s_game_state : " + s_game_state);
	
//@#if not SupportNokiaAPI
//@	#if not BREW_WithoutBuffer
	// if (_screenImageBuffer == null)
	// {
		// _screenImageBuffer = Image.createImage(240, 320);
		// _graphicsScreenBuffer = _screenImageBuffer.getGraphics();
	// }
//@		#if UseForLGKE850
//@			g.setColor(DEF.Bottom_Color);
//@			g.fillRect(0, DEF.SCR_H, DEF.True_SCR_W, DEF.True_SCR_H-DEF.SCR_H);
//@		#endif
	// g_bak = g;
	// g = _graphicsScreenBuffer; // DON'T USE BUFFER IN JS
//@	#endif // BREW_WithoutBuffer
//@#endif //SupportNokiaAPI
	//try {
	CGame._frameDT_Real = s_game_frameDT;
	s_game_frameDT = 1000 / GLLibConfig.FPSLimiter;
	CGame._frameDT = 1000 / GLLibConfig.FPSLimiter;
	PARENT_TITLE_OFFSET_POS_Y = 0;
	OPTIONS_OFFSET_POS_Y = 30;
	this.preUpdate();
//		if(Build.useIGP)
//		{
//			if(IGP.URLPlatformRequest != null)
//			{
//				if(GLLibConfig.platformRequestOnExit)
//				{
//					Dbg("Quitting from app to launch browser for IGP...");
//					Quit();
//				}
//				else
//				{
//					Dbg("Launching browser for IGP...");
//					PlatformRequest(IGP.URLPlatformRequest);
//					IGP.URLPlatformRequest = null;
//				}
//			}
//		}
//@#if TOUCH_SCREEN
	    this.UpdatePointerEvents(false);
//@#endif	
	switch(s_game_state)
	{
		case STATE.QUIT:
		{
			// GLLibPlayer.Snd_Quit();
			s_game_state = -1;			
			var param = "";
			if(window.location.toString().split("?").length > 1)
				param = window.location.toString().split("?")[1];
			window.open("/?" + param, "_self");
		}
		break;

		case STATE.INIT :	{ this.UpdateGameState_INIT (); } break ;
		case STATE.GAMELOFT_LOGO :	{ this.UpdateGameState_GAMELOFT_LOGO (); } break ;
		case STATE.SPLASH :	{ this.UpdateGameState_SPLASH (); } break ;
		case STATE.SELECT_LANGUAGE_INIT :	{ this.UpdateGameState_SELECT_LANGUAGE_INIT (); } break ;
		case STATE.SELECT_LANGUAGE :	{ this.UpdateGameState_SELECT_LANGUAGE (); } break ;
		case STATE.LOAD_UNLOAD :	{ this.UpdateGameState_LOAD_UNLOAD (); } break ;
		case STATE.MENU_INIT :	{ this.UpdateGameState_MENU_INIT (); } break ;
		case STATE.ASK_SOUND :	{ this.UpdateGameState_ASK_SOUND (); } break ;
		case STATE.ASK_SOUND_LEVEL :	{ this.UpdateGameState_ASK_SOUND_LEVEL (); } break ;
		case STATE.MENU_EXIT :	{ this.UpdateGameState_MENU_EXIT (); } break ;
		case STATE.IGP :	{ this.UpdateGameState_IGP (); } break ;
		case STATE.MENU_GET_MORE_GAMES_INIT :	{ this.UpdateGameState_MENU_GET_MORE_GAMES_INIT (); } break ;
		case STATE.MENU_MAIN :	{ this.UpdateGameState_MENU_MAIN (); } break ;
		case STATE.MENU_INGAME_MAIN_MENU :	{ this.UpdateGameState_MENU_INGAME_MAIN_MENU (); } break ;
		case STATE.BACK_TO_MINIMAP: {this.UpdateGameState_BACK_TO_MINIMAP (); } break;
		case STATE.GAMEPLAY_UPDATE :	{ this.UpdateGameState_GAMEPLAY_UPDATE (); } break ;
		case STATE.K_MRC_INIT :	{ this.UpdateGameState_K_MRC_INIT (); } break ;
		case STATE.K_MRC_VALIDATING :	{ this.UpdateGameState_K_MRC_VALIDATING (); } break ;
		case STATE.K_MRC_EXPIRED :	{ this.UpdateGameState_K_MRC_EXPIRED (); } break ;
		case STATE.K_MRC_NETWORK_FAILED :	{ this.UpdateGameState_K_MRC_NETWORK_FAILED (); } break ;
		case STATE.GAMEOVER :	{ this.UpdateGameState_GAMEOVER (); } break ;
		case STATE.GAMEEND :	{ this.UpdateGameState_GAMEEND (); } break ;
		case STATE.GAME_STATISTIC :	{ this.UpdateGameState_GAME_STATISTIC (); } break ;
		case STATE.END_GAME_IGP :   { this.UpdateGameState_END_GAME_IGP(); }   break ;

		// empty switch cases
		case STATE.MENU_SELECT_LEVEL:
		{
			var maxLevel = CGame._level2tiled.length >> 2;
			switch(this.updateMenu()) {
			case STATE.LOAD_UNLOAD:
				CGame._levelId += s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_CHILD] - TEXT.MENU_LEVEL1;
				CGame._tempLevelId = CGame._levelId;
				break;
			}
		}
		break;
		case STATE.MENU_SELECT_WORLD:
		{
			switch(this.updateMenu()) {
			case STATE.MENU_SELECT_LEVEL:
					CGame._worldId = (s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_CHILD] - TEXT.MENU_LABYRINTH_WORLD);
				CGame._levelId = CGame._worldId * DAI.LEVELS_NUM_PRE_WORLD;
				break;
			}
		}
		break;

		case STATE.MENU_HELP:
		{
			CGame._needSpecialProcess = true;
			if (currentMenuDepth > 0 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT] != -1)
			{
				this.UpdateGameState_MENU_HELP();
			}
			CGame._needSpecialProcess = false;
		}
		break;

		case STATE.MENU_ABOUT:
		{
			currentSplash = 1;
			PARENT_TITLE_OFFSET_POS_Y = 80 * DScreen.RATIO;
			CGame._needSpecialProcess = true;
			if (currentMenuDepth > 0 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT] != -1)
			{
				this.UpdateGameState_MENU_ABOUT();
			}
			CGame._needSpecialProcess = false;
		}
		break;
		case STATE.RESET_GAME:
		{
			currentSplash = 1;
			
			OPTIONS_OFFSET_POS_Y = 0;
			PARENT_TITLE_OFFSET_POS_Y = 70 * DScreen.RATIO;	

			switch(this.updateMenu())
			{
				case STATE.YES:
					CGame.RMS_Init();
					currentMenuDepth -= 2;
					s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
					if ((s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE] == STATE.MENU_MAIN)) {
						s_game_state = STATE.MENU_NEW_GAME;
					}
					break;

				case STATE.NO:
					currentMenuDepth -= 2;
					s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
					break;
			}
		}
		break;
		
		case STATE.MENU_OPTIONS:
		{
			currentSplash = 1;
			OPTIONS_OFFSET_POS_Y = -20;
			PARENT_TITLE_OFFSET_POS_Y = 80;
			switch(this.updateMenu())
			{
			}
		}
		break;
		
		case STATE.RESUME_GAME:
		{
			if (CGame.bIsMiniMap) {
				s_game_state = STATE.MENU_MAP;
			} else {
				s_game_state = STATE.GAMEPLAY_UPDATE;
			}
			CGame.bIsPaused = false;
			this.ResumeSoundBGM();
		}
		break;
		case STATE.RESTART_LEVEL:
		{
			switch(this.updateMenu())
			{
			case STATE.YES:
					CGame._checkPointData = null;
				CGame.GotoRestart(false);
				break;
			case STATE.NO:
				currentMenuDepth -= 2;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
				break;
			}
		}
		break;
		case STATE.MENU_INGAME:
		{
			if(DEF.dbgEnableCheat) {
				if((this.useCheatCode() == s_game_state) || DEF.dbgEnableGodMode || DEF.dbgUnlockLevel) {
						if (DEF.dbgEnable) Dbg("_________ s_game_state: " + s_game_state);
					CGame.godModeUnlock = true;
				}
			}

			switch(this.updateMenu())
			{
				case STATE.MENU_GET_MORE_GAMES:
				{
					s_game_state = STATE.MENU_GET_MORE_GAMES_INIT;
				}
				break;
			}
		}
		break;

		case STATE.MENU_INGAME_OPTIONS:
		{
			switch(this.updateMenu())
			{
			}
		}
		break;

		case STATE.MENU_NEW_GAME:
		{
			if (CGame._gameProgress == GAME_PROGRESS_FIRST_PLAY) {
//@#if not RemoveStory
					CGame._tempLevelId = DAI.LEVEL_ID_INTRO_NEW_GAME;
					s_game_state = STATE.LOAD_UNLOAD;
					CGame._gameProgress++;
					CGame.RMS_Save();
//					if (!_storyHasIntroduced)
//						ShowTheStory();
//					else {
//						_firstPlay = false;
//						_storyHasIntroduced = false;
//						CGame.RMS_Save();
//						s_game_state = STATE.CONTINUE_GAME;
//						CGame._levelUnlocked = 0;
//					}
//@#endif
			} else {
				s_game_state = STATE.RESET_GAME;
			}
		}
		break;

		case STATE.CONTINUE_GAME:
		{
			CGame.GotoMiniMap();
		}
		break;

		case STATE.MENU_MAP:
		{
//@#if not RemoveMinimap
			this.UpdateMiniMap();
			this.DrawMiniMap();								
				if (WasKeyReleased(GLKey.k_menuOK)) {
					CGame.initIngameMenu(STATE.MENU_INGAME);
				}
//@#else
//@				s_game_state = STATE.MENU_SELECT_WORLD;
//@#endif
		}
		break;
		//A.W: Add update Tnb State
		case STATE.MENU_TNB_MAIN: {
			switch( this.updateMenu() ) {

			}
		}
		break;
		case STATE.POPUP_TNB_PLAY_DEMO: {
			if (!CGame.bIsTnBPopup)
				CGame.bIsTnBPopup = true;
			switch( this.updateMenu() ) {

			}
		}
		break;
//@#if SupportLandspaceMode
//@			case STATE.LANDSPACE:
//@				SetColor(0);
//@				SetClip(0 , 0, GetScreenWidth(), GetScreenHeight());
//@				FillRect(0, 0, GetScreenWidth(), GetScreenHeight());
//@				SetColor(0xffffff);
//@				
//@				if (Language.count == 1) {
//@					textPack = DATA.PACK_TEXT;
//@				} else {
//@					textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
//@				}
//@				if( s_last_game_state < STATE.MENU_MAIN )
//@					Text_LoadTextFromPack_INI(textPack, DATA.TEXT_INIT);
//@				else
//@				    Text_LoadTextFromPack_INI(textPack, DATA.TEXT_MENU);
//@				if( fontSpr == null )
//@				{
//@					fontLoad();
//@					CGame.txtSetFont(fontSprBig);
//@				}
//@				CGame.DrawMultiLineText ( g, Text_GetString(s_last_game_state < STATE.MENU_MAIN? TEXT.INIT_LANDSCAPE : TEXT.MENU_LANDSCAPE), (GetScreenWidth() >> 1), (GetScreenHeight() >> 1), VCENTER | HCENTER, 0,  GLLibConfig.screenWidth, 0, 10, 15);
//@				//DrawString(Text_GetString(TEXT.MENU_LANDSCAPE), (GetScreenWidth() >> 1), (GetScreenHeight() >> 1), VCENTER | HCENTER);
//@
//@			break;
//@#endif					
	}
	//Dbg("*** currentMenuDepth: " + currentMenuDepth);
	//Dbg("*** currentMenu: " + currentMenu);
	//Dbg("*** menuFlow: " + s_menuFlow[currentMenu[currentMenuDepth]]);

	GLLibPlayer.Snd_Update();
	
	// } catch ( ex) {
		// Dbg("Game_update()");
		// Dbg("Game_update ========================== ex : " + ex.message);		
	// }
//@#if TOUCH_SCREEN
	this.UpdatePointerEvents(true);
	this.RenderPointerEvent();
	this.ClearPointer();
	// ResetKey();
//@#endif	
	// g = g_bak;// DON'T USE BUFFER IN JS
	// buf = LowAPI.Gen_Array([GAME_SIZE_X*GAME_SIZE_Y],0);//new var[GAME_SIZE_X*GAME_SIZE_Y];
	
	// buf2 = LowAPI.Gen_Array([GAME_SIZE_X*GAME_SIZE_Y],0);//new var[GAME_SIZE_X*GAME_SIZE_Y];
	// CGame.NewAlgo(g,_screenImageBuffer);
//@#if addGc
//@		if( s_game_currentFrameNB % 10 == 0 )
//@        	System.gc();
//@#endif
}
CGame.NewAlgo = function( g, src)
{
	var scanline = 240;
	var i=0;
	src.getRGB(buf, 0, scanline, 0, 0, 240, 320);
	CGame.DrawZoom(g, 0, 0);//q1 (120 X 160 ----->   240 X 320 )
	CGame.DrawZoom(g, 120, 0);//q2
	CGame.DrawZoom(g, 0, 80);//q3
	CGame.DrawZoom(g, 120, 80);//q4
	CGame.DrawZoom(g, 0, 160);//q3
	CGame.DrawZoom(g, 120, 160);	
	CGame.DrawZoom(g, 0, 240);//q3
	CGame.DrawZoom(g, 120, 240);

}

CGame.DrawZoom = function( g, LTx, LTy)
{
	var ii=0;
	var val;
	for(var y=LTy;y<(LTy + 80);++y)
	{
		for(var x=LTx;x<(LTx + 120);++x)
		{
			val =  buf[(y) * 240 + (x)];
			buf2[ii++] = val;
			buf2[ii++] = val;
		}
		for(var x=LTx;x<(LTx + 120);++x)
		{
			val =  buf[(y) * 240 + (x)];
			buf2[ii++] = val;
			buf2[ii++] = val;
		}
	}
	// g.drawRGB(buf2,0,240,LTx<<1,LTy<<1,240,320,false);	
	// var image = Image.createImage(buf2,240,320);
	// DrawImage(image, LTx<<1,LTy<<1, LEFT|TOP);
}
var _storyHasIntroduced = false;
var _topLineOfStoryText = 0;
var _storyPart = 0;
var _storyTextPosition_Y = DEF.VIEW_H; 
var _keepTheTextStop = false;
var _currentBackColor = 0xff;
var NOT_TRANSPARENT = 0xff;
CGame.ShowTheStory = function()
{
	g.setColor(0);
	g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
	g.fillRect(0, 0, DEF.VIEW_W, DEF.VIEW_H);
	//*
	_topLineOfStoryText = DGUI.TOPLINEOFSTORYTEXT_OFFSET_Y;

	CGame.txtSetFont(fontSprSmall);
	CGame.txtDraw(2, Text_GetString(TEXT.MENU_SK_SKIP), GLLibConfig.screenWidth, GLLibConfig.screenHeight, BOTTOM | RIGHT);
	if(_keepTheTextStop) {
		_storyTextPosition_Y = _topLineOfStoryText + 10;
	} 
	
	if(_storyPart < 3) {
		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H - 25);
			var lineInterval = 0;
			CGame.DrawMultiLineText(g, Text_GetString(TEXT.MENU_STORY_B1+_storyPart), 10, _topLineOfStoryText + 10, 0, 2, DEF.VIEW_W-10, 0, 10, lineInterval);
		if (!_keepTheTextStop) {
			_currentBackColor -= 6;
			if (_currentBackColor <= 0) {
				_currentBackColor = 0;
			}
		} else {
			_currentBackColor += 12;
			if (_currentBackColor >= NOT_TRANSPARENT) {
				_currentBackColor = NOT_TRANSPARENT;
			}
		}
		var backColor = _currentBackColor<<24;

		CGame.FillArgbRect(0, 0, DEF.VIEW_W, DEF.VIEW_H-20, backColor | MENU_BACKGROUND_COLOR);
	}
	
	if(_storyTextPosition_Y-- < _topLineOfStoryText + 10 && !_keepTheTextStop) {
		_keepTheTextStop = true;
		CGame._lastFrameNB = /*GLLib.*/s_game_currentFrameNB;
	}
	
	if(/*GLLib.*/s_game_currentFrameNB - CGame._lastFrameNB == 15) {
		_storyTextPosition_Y = DEF.VIEW_H;
		_storyPart++;
		_keepTheTextStop = false;
		_currentBackColor = 0xff;
	}
	
	if(_storyPart == 3) {
		_storyPart=0;
		CGame.txtSetFont(fontSprBig);
			_storyHasIntroduced = true;
	}
	if (IsKeyDown(GLKey.k_menuBack)) {
		_storyPart=0;
		CGame.txtSetFont(fontSprBig);
			_storyHasIntroduced = true;
	}
	
}


//Cheat Code
CGame.godModeUnlock = false;

var CHEAT_CODE =	
[
	[1, GLKey.k_num1, GLKey.k_num9, GLKey.k_num7, GLKey.k_num3, STATE.MENU_MAIN],
	[1, GLKey.k_num3, GLKey.k_num7, GLKey.k_num9, GLKey.k_num1, STATE.MENU_INGAME],
];
//@#if TOUCH_CHEAT
var current_Cheat_Time = 0;
var cheat_Time_Delay = 1000;
var count_Cheat_Time = false;
var cheat_Touch_Count = 2;
var cheatMode = 0;
//@#endif
CGame.prototype.useCheatCode = function() 
{
	var index, cheatState = -1;
	for (var i = 0; i < CHEAT_CODE.length; i++)
	{
		index = CHEAT_CODE[i][0];
		if (WasAnyKeyPressed() != GLKey.k_invalid) 
		{
			if (WasKeyPressed(CHEAT_CODE[i][index])) 
			{
				index++;
				if (index == CHEAT_CODE[i].length-1) 
				{
					cheatState = CHEAT_CODE[i][index];
					CHEAT_CODE[i][0] = 1;
					break;
				}
			} 
			else 
			{
				CHEAT_CODE[i][0] = 1;
				continue;
			}
		}
		CHEAT_CODE[i][0] = index;
	}
//@	#if TOUCH_CHEAT
	cheatMode = 1;
	if (s_game_state == STATE.MENU_MAIN)
	{
		cheatMode = 0;
	}
	
	if (count_Cheat_Time)
	{
		current_Cheat_Time = System.currentTimeMillis();
		count_Cheat_Time = false;
	}
	
		if (CGame.isPointInRect(0, 0, 50 * DScreen.RATIO, 50  * DScreen.RATIO))
	{
		if (System.currentTimeMillis() - current_Cheat_Time < cheat_Time_Delay) 
		{
			cheat_Touch_Count ++;
		} 
		else 
		{
			cheat_Touch_Count = 2;
		}
		count_Cheat_Time = true;
	}
		if (CGame.isPointInRect(GLLibConfig.screenWidth - 50  * DScreen.RATIO, 0, 50  * DScreen.RATIO, 50  * DScreen.RATIO))
	{
		if (cheat_Touch_Count == CHEAT_CODE[cheatMode].length - 1) 
		{
			cheatState = CHEAT_CODE[cheatMode][cheat_Touch_Count];
		}
	}
//@	#endif
	
	if (cheatState == STATE.MENU_INGAME)
			if (DEF.dbgEnable) Dbg("____________ ingame, cheat");
	
	if (cheatState == STATE.MENU_MAIN)
			if (DEF.dbgEnable) Dbg("____________ main menu, cheat");
	return cheatState;
}

// -----------------------------------------------------------------------------------------------------------------------------------------
// SPECIFIC STATE UPDATES
//@#if PACK_STATEFLOW	
//@	var[] s_StateFlow;
//@	void LoadStateFlow()
//@	{
//@		var STATEFLOW = "/900";
//@		s_StateFlow = (var[][]) Mem_ReadArray(STATEFLOW.getClass().
//@                getResourceAsStream(STATEFLOW));	
//@	}
//@#endif	


/**
* dynamic add menu language to  s_menuFlow.
*/

CGame.InitSelectMenuLanguage = function () {
	
	for (var i = 0; i < Language.count; i++)
	{
		Text_LoadTextFromPack_INI("/"+Text_GetLanguageAsString(languageArray[i]), DATA.TEXT_INIT);
		languageArrayTextId[i] = Text_GetString(TEXT.INIT_LANGUAGE_NAME);
	}
			
    var menuFlowLength = s_menuFlow.length;
    var IDX_LANG_MENU = 9; // index in array s_menuFlow.
    for (var i = 0; i < languageArray.length; i ++) {
		// !!! Fake text for each language.
        var LANG_ITEM = [STATE.YES, TEXT.MENU_LANGUAGE_NAME + i];
        // add temp menu.
        s_menuFlow.push(LANG_ITEM);
        // add child menu to SELECT_LANGUAGE
        s_menuFlow[IDX_LANG_MENU].push(menuFlowLength + i);
    }  
}

CGame.prototype.UpdateGameState_INIT = function() //throws Exception
{

	// load math table
	Math_Init(DATA.PACK_MISC, DATA.MISC_COS, DATA.MISC_SQRT);

	// Must use Pack_LoadMIME after to init all variable ( issue : error when Pack_LoadMIME )
	if (DEF.dbgEnable) Dbg("loading mime type");
	// load mime type
	Pack_LoadMIME(DATA.PACK_MIME_TYPE);


	// set text encoding
	Text_SetEncoding(Build.encoding);
	
	// load StateFlow
//@#if PACK_STATEFLOW
//@		LoadStateFlow();
//@#endif		

	this.LoadMisc();

	// create language array and check if we must use standard text instead of font
	languageArray = LowAPI.Gen_Array([Language.count], 0);//new byte[Language.count];
	languageArrayTextId = LowAPI.Gen_Array([Language.count], 0);
	var curLang = 0;
	if (Language.EN)
		languageArray[curLang++] = GLLang.EN;
	if (Language.DE)
		languageArray[curLang++] = GLLang.DE;
	if (Language.FR)
		languageArray[curLang++] = GLLang.FR;
	if (Language.IT)
		languageArray[curLang++] = GLLang.IT;
	if (Language.ES)
		languageArray[curLang++] = GLLang.ES;
	if (Language.BR)
		languageArray[curLang++] = GLLang.BR;
	if (Language.PT)
		languageArray[curLang++] = GLLang.PT;
	if (Language.RU)
		languageArray[curLang++] = GLLang.RU;

	if (Language.JP)
	{
		languageArray[curLang++] = GLLang.JP;
	}
	if (Language.CN)
	{
		languageArray[curLang++] = GLLang.CN;		
	}
	if (Language.KR)
	{
		languageArray[curLang++] = GLLang.KR;
	}
	
	CGame.InitSelectMenuLanguage();
	
	ASprite.InitCachePool(2);
	ASprite.InitPoolSize(0, 100);
	ASprite.InitPoolSize(1, 100);

	if (DEF.dbgEnable) Dbg("loading RMS");
	CGame.RMS_Load();
	
	if (DEF.dbgEnable) Dbg("loading fonts");
	// load font
	this.fontLoad();
	
	GLLibPlayer.Snd_Init(DATA.SOUND_MAX);
	CGame.LoadUnload(DLoadState.LOAD_SOUND);

	// If SOUND_STATE_AS_LEVELS is enabled, look through the menu flow and replace ASK_SOUND_NOLEVEL with ASK_SOUND_LEVEL
	if (SOUND_STATE_AS_LEVELS)
	{
		for (var i = 0; i < s_menuFlow.length; i++)
		{
			if (s_menuFlow[i] == ASK_SOUND_NOLEVEL)
			{
				s_menuFlow[i] = ASK_SOUND_LEVEL;
			}
		}
	}
	
	s_game_state = STATE.GAMELOFT_LOGO;
	// if (!CGame.bSetSound)
	// {
		// CGame.bSetSound = CGame.isSoundEnabled;
		// CGame.isSoundEnabled = false;
	// }
	if(Build.useIGP)
	{
		if (DEF.dbgEnable) Dbg("initializing IGPs");
//@	#if not BREW_IGP
		// IGP .initialize(/*GLLib.*/s_application,this,GLLibConfig.screenWidth , GLLibConfig.screenHeight );
//@	#endif // BREW_IGP
		
		//                          					   k_dummy    k_up       k_down     k_left    k_right
		//                           					    k_fire        k_num0  k_num1     k_num2    k_num3
		//                        						    k_num4      k_num5  k_num6    k_num7    k_num8
		//                         						    k_num9      k_star    k_pound   k_menuOK  k_menuBack
		//
		// keyToIGPMap = [
									 // IGP.ACTION_NONE,   IGP.ACTION_UP,    IGP.ACTION_DOWN, IGP.ACTION_LEFT,  IGP.ACTION_RIGHT,
									 // IGP.ACTION_SELECT, IGP.ACTION_NONE,  IGP.ACTION_NONE, IGP.ACTION_UP,    IGP.ACTION_NONE,
									 // IGP.ACTION_LEFT,   IGP.ACTION_SELECT,IGP.ACTION_RIGHT,IGP.ACTION_NONE,  IGP.ACTION_DOWN,
									 // IGP.ACTION_DOWN,   IGP.ACTION_DOWN,  IGP.ACTION_DOWN, IGP.ACTION_SELECT,IGP.ACTION_BACK
		// ];
//@	#if not BREW_IGP
		_is_igp_actived       = true;//IGP.IsAvailable();
//@	#endif // BREW_IGP
//			// load IGPs
//			IGP.initialize(s_application);
//			keyToIGPMap = new var[GLKey.k_nbKey];
//			keyToIGPMap[GLKey.k_dummy] 		= IGP.ACTION_NONE;
//			keyToIGPMap[GLKey.k_up] 		= IGP.ACTION_UP;
//			keyToIGPMap[GLKey.k_down] 		= IGP.ACTION_DOWN;
//			keyToIGPMap[GLKey.k_left] 		= IGP.ACTION_LEFT;
//			keyToIGPMap[GLKey.k_right] 		= IGP.ACTION_RIGHT;
//			keyToIGPMap[GLKey.k_fire] 		= IGP.ACTION_SELECT;
//			keyToIGPMap[GLKey.k_num0] 		= IGP.ACTION_KEY_0;
//			keyToIGPMap[GLKey.k_num1] 		= IGP.ACTION_KEY_1;
//			keyToIGPMap[GLKey.k_num2] 		= IGP.ACTION_KEY_2;
//			keyToIGPMap[GLKey.k_num3] 		= IGP.ACTION_KEY_3;
//			keyToIGPMap[GLKey.k_num4] 		= IGP.ACTION_KEY_4;
//			keyToIGPMap[GLKey.k_num5] 		= IGP.ACTION_KEY_5;
//			keyToIGPMap[GLKey.k_num6] 		= IGP.ACTION_KEY_6;
//			keyToIGPMap[GLKey.k_num7] 		= IGP.ACTION_KEY_7;
//			keyToIGPMap[GLKey.k_num8] 		= IGP.ACTION_KEY_8;
//			keyToIGPMap[GLKey.k_num9] 		= IGP.ACTION_KEY_9;
//			keyToIGPMap[GLKey.k_star] 		= IGP.ACTION_NONE;
//			keyToIGPMap[GLKey.k_pound] 		= IGP.ACTION_KEY_POUND;
//			keyToIGPMap[GLKey.k_menuOK] 	= IGP.ACTION_SELECT;
//			keyToIGPMap[GLKey.k_menuBack] 	= IGP.ACTION_BACK;
	}
	
	
//@#if Use_Motion_Sensor
//@		InitializeSensor();
//@		StartMotionSensor();
//@#endif
}
var s_game_interruptNotify = false;
CGame.prototype.LoadMisc = function() {
	Pack_Open(DATA.PACK_MISC);
	CGame._class2sprites = Pack_ReadData(DATA.MISC_CLASS2SPRIT);
	CGame._level2tiled = Pack_ReadData(DATA.MISC_LEVEL2TILED);
	Pack_Close();
}

CGame.prototype.UpdateGameState_GAMELOFT_LOGO = function()// throws Exception
{
	if (CGame.spriteArray[DSpriteID.GAMELOFT_LOGO] == null)
	{
		if (DEF.dbgEnable) Dbg("loading gameloft logo");
		Pack_Open(DATA.PACK_SPRITE);
		CGame.spriteLoad(DSpriteID.GAMELOFT_LOGO, DATA.SPRITE_GAMELOFT_LOGO, true, false);
		Pack_Close();

		CGame.redrawAll = true;
		timer = /*GetFrameTime()*/ System.currentTimeMillis() + CGame.GAMELOFT_LOGO_WAIT_TIME;
	}
		else if (CGame.redrawAll /*|| s_game_interruptNotify*/)
	{
		SetColor(0xFFFFFFFF);
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);


			CGame.spriteArray[DSpriteID.GAMELOFT_LOGO].PaintFrame(g,
				DAnimID.LOGO_FRAME_MAIN,
				(GLLibConfig.screenWidth / 2) - (CGame.spriteArray[DSpriteID.GAMELOFT_LOGO].GetFrameWidth(DAnimID.LOGO_FRAME_MAIN) / 2),
				(GLLibConfig.screenHeight / 2) - (CGame.spriteArray[DSpriteID.GAMELOFT_LOGO].GetFrameHeight(DAnimID.LOGO_FRAME_MAIN) / 2),
				0);
			CGame.redrawAll = false;
		}

	timer = Math.min(timer, /*GetFrameTime()*/ System.currentTimeMillis() + CGame.GAMELOFT_LOGO_WAIT_TIME);
	if (/*GetFrameTime()*/ System.currentTimeMillis() > timer)
	{
		// Dbg("------------------------------------------ UNLOAD LOGGO");
		CGame.spriteUnLoad(DSpriteID.GAMELOFT_LOGO);

		if (LOADING_BEFORE_SOUND_PROMPT)
		{
			textPack = DATA.PACK_TEXT;
			s_game_state = STATE.MENU_INIT;
			CGame.loadingPhase = 0;
		}
		else
		{
			s_game_state = STATE.SELECT_LANGUAGE_INIT;
		}
		CGame.redrawAll = true;
		 this.requireUserInputEvent();
	}
}

CGame.prototype.UpdateGameState_SPLASH = function()// throws Exception
{

		if (CGame.redrawAll || s_game_interruptNotify)
	{
//@#if BREW_AdjustSplashY
//@			_splash.PaintAFrame(g, 0, 0, DEF.SCR_W_D2, DEF.SCR_H_D2 + DEF.SPLASH_H_OFFSET, 0);
//@			if ((s_game_currentFrameNB % 10) > 5)
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_ANY_KEY), GetScreenWidth() / 2, GetScreenHeight() + DEF.MENU_PRESS_ANY_KEY_OFFSET, BOTTOM | HCENTER);
//@#else // BREW_AdjustSplashY
			_splash.PaintAFrame(g, 0, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
		var palette = 3;
		if ((s_game_currentFrameNB % 10) > 5)
//@#if not TOUCH_SCREEN				
//@				CGame.txtDraw(palette, Text_GetString(TEXT.INIT_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - 30, BOTTOM | HCENTER);
//@#else
		CGame.DrawMultiLineText ( g, Text_GetString(TEXT.INIT_PRESS_ANY_KEY_TOUCH), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - 30 * DScreen.RATIO, BOTTOM | HCENTER, palette,  GLLibConfig.screenWidth, 0, 10, 15);

//@#endif			

//@#endif // BREW_AdjustSplashY

		CGame.redrawAll = false;
	}

	// Always draw splash due to blinking text
	CGame.redrawAll = true;

	if (WasKeyReleased(GLKey.k_fire))
	{
		s_game_state = STATE.MENU_INIT;
	}
//		CGame.DrawMultiLineText(g, Text_GetString(TEXT.INIT_HELP_MRC), 0, 0, GRPH.LEFT_TOP, 0, DEF.SCR_W, 0, 10);
}

CGame.prototype.UpdateGameState_SELECT_LANGUAGE_INIT = function()// throws Exception
{
	CGame.loadingPhase = 0;
	if (Language.count == 1) {
		textPack = DATA.PACK_TEXT;
	} else {
		textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
	}
	if (CGame.bSetLanguage)
	{
		// get language from phone default, or first one otherwise
		CGame.curLanguage = 0;
		var phoneLanguage = (navigator.language || navigator.userLanguage).substring(0,2).toUpperCase();//"en";//Text_GetPhoneDefaultLangage(); // Default use EN.
		if (DEF.dbgEnable) Dbg("------------------------- " + phoneLanguage);
		for (var i=0; i<Language.count; i++)
		{		
			if (phoneLanguage == Text_GetLanguageAsString(languageArray[i]))
			{
				CGame.curLanguage = i;
				break;
			}
		}
		CGame.initMenus();
		textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
		/*Text_LoadTextFromPack_INI(textPack, DATA.TEXT_MENU);
		currentMenu[currentMenuDepth] = 9; // Index menu SELECT_LANGUAGE.
		menuSelection[currentMenuDepth] = CGame.curLanguage;
		s_game_state = STATE.SELECT_LANGUAGE; */
		CGame.bSetLanguage = false;
		
		s_game_state = STATE.SPLASH; // dectect language auto go to splash state .
	}
	else if (CGame.bSetSound)
	{
		CGame.initMenus();
		currentMenu[currentMenuDepth] = ASK_SOUND_INDEX;

		s_game_state = STATE.ASK_SOUND;
	}
	else
	{
		CGame.initMenus();
		s_game_state = STATE.SPLASH;
	}



	if (!LOADING_BEFORE_SOUND_PROMPT)
		Text_LoadTextFromPack_INI(textPack, DATA.TEXT_INIT);

	tmpCurLanguage = CGame.curLanguage;

	CGame.redrawAll = true;
}

var LANG_LATIN = ["x", GLLang.EN, GLLang.DE, GLLang.FR, GLLang.IT, GLLang.ES, GLLang.BR, GLLang.PT]; // use the same font.
var LANG_NON_LATIN = ["x", GLLang.RU]; // use the same font.

CGame.prototype.UpdateGameState_SELECT_LANGUAGE = function() //throws Exception
{
	currentSplash = 1;
	OPTIONS_OFFSET_POS_Y = -70 * DScreen.RATIO;
	PARENT_TITLE_OFFSET_POS_Y = 100 * DScreen.RATIO;
	switch(this.updateMenu())
	{
		case STATE.YES:
			var tmpLang = CGame.curLanguage;
			CGame.curLanguage = s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_CHILD] - TEXT.MENU_LANGUAGE_NAME;
			// save selected language
			CGame.RMS_Save();
			
			if (LANG_LATIN.indexOf(languageArray[tmpLang]) * LANG_NON_LATIN.indexOf(languageArray[CGame.curLanguage]) > 0)
			{
				if (DEF.dbgEnable) Dbg("-------------------------- Reload font ...");
				this.fontLoad();
			}
				
			textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
			Text_LoadTextFromPack_INI(textPack, DATA.TEXT_MENU);

			if (CGame.bSetSound)
			{
				// CGame.initMenus();
				Text_LoadTextFromPack_INI(textPack, DATA.TEXT_INIT);
				currentMenu[currentMenuDepth] = ASK_SOUND_INDEX;
				s_game_state = STATE.ASK_SOUND;
				CGame.bSetLanguage = false;
			}
			else
			{
				 //s_game_state = STATE.MENU_INIT;
				currentMenuDepth -= 1;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			}
			break;
	}
				
	// If we're in multi language mode then draw special menu for language selection
	// We use a special menu in this instance because the language pack must be swapped to display each language title
	/* if (Language.count != 1)
	{
			if (CGame.redrawAll || s_game_interruptNotify)
		{
			var halfWidth = GLLibConfig.screenWidth / 2;
			var halfHeight = GLLibConfig.screenHeight / 2;
			var startMenu = halfHeight - (MENU_OPTIONS_SPACING * (Language.count+2)) / 2;

			SetColor(MENU_BACKGROUND_COLOR);
			FillRect(MENU_MAIN_X, MENU_MAIN_Y, GLLibConfig.screenWidth - (MENU_MAIN_X << 1), GLLibConfig.screenHeight - (MENU_MAIN_Y << 1));

			textPack = "/"+Text_GetLanguageAsString(languageArray[tmpCurLanguage]);
			Text_LoadTextFromPack_INI(textPack, DATA.TEXT_INIT);

			CGame.txtDraw(0, Text_GetString(TEXT.INIT_SELECT_LANGUAGE), halfWidth, startMenu, VCENTER | HCENTER);
			startMenu += MENU_OPTIONS_SPACING;

			this.setSoftKeys(TEXT.INIT_SK_SELECT, CGame.bSetLanguage ? SOFTKEY_NONE : TEXT.INIT_SK_BACK);
			this.drawSoftKeys();

			for (var i = 0; i < Language.count; i++)
			{
				SetColor(MENU_SELECTION_BAR_COLOR);
				if (tmpCurLanguage == i)
					FillRect(0, startMenu + (i * MENU_OPTIONS_SPACING), GLLibConfig.screenWidth, 10);

				Text_LoadTextFromPack_INI("/"+Text_GetLanguageAsString(languageArray[i]), DATA.TEXT_INIT);
				CGame.txtDraw(tmpCurLanguage == i ? 0 : 1, Text_GetString(TEXT.INIT_LANGUAGE_NAME), halfWidth, startMenu + (i * MENU_OPTIONS_SPACING), TOP | HCENTER);
			}

			CGame.redrawAll = false;
		}

		else if ((_keycode = WasAnyKeyReleased()) >= 0)
		{
			// if language is accepted
			if ((_keycode == GLKey.k_menuOK) || (_keycode == GLKey.k_fire))
			{
				CGame.curLanguage = tmpCurLanguage;
				// save selected language
				CGame.RMS_Save();
				
				if (CGame.curLanguage == GLLang.CN || CGame.curLanguage == GLLang.KR || CGame.curLanguage == GLLang.JP) {
					useStandardTextInsteadOfFont = true;
				}

				textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
				CGame.LoadUnload(DLoadState.LOAD_TEXT);

				if (CGame.bSetSound)
				{
					CGame.initMenus();
					currentMenu[currentMenuDepth] = ASK_SOUND_INDEX;
					s_game_state = STATE.ASK_SOUND;
				}
				else
				{
					 //s_game_state = STATE.MENU_INIT;
					currentMenuDepth -= 1;
					s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
				}

				CGame.redrawAll = true;
				CGame.bSetLanguage = false;
			}
			else if ((_keycode == GLKey.k_menuBack) && !CGame.bSetLanguage)
			{
				textPack = "/"+Text_GetLanguageAsString(languageArray[CGame.curLanguage]);
				CGame.LoadUnload(DLoadState.LOAD_TEXT);

				currentMenuDepth -= 1;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			}
			else if (_keycode == GLKey.k_up)
			{
				tmpCurLanguage--;
				if (tmpCurLanguage < 0)
					tmpCurLanguage = Language.count - 1;
			}
			else if (_keycode == GLKey.k_down)
			{
				tmpCurLanguage++;
				if (tmpCurLanguage >= Language.count)
					tmpCurLanguage = 0;
			}

			CGame.redrawAll = true;
			ResetKey();
		}
	} */
}
//@#if not RemoveMinimap
CGame.prototype.GetLevelPaletteIdByWorldId = function ( worldId) {
//@#if RemoveIceLevel
	if(worldId > DAI.WORLD_ID_ICE) {
		worldId ++;
	}
//@#endif
	return worldId + 1;
}

CGame.prototype.GetLevelMapActorBossByWorldId = function( worldId) {
	return DAnimID.MAP_ACTOR_BOSS_1 + worldId;
}

CGame.prototype.GetWorldMapActorIconByWorldId = function (worldId) {
//@#if RemoveIceLevel
	if(worldId > DAI.WORLD_ID_ICE) {
		worldId ++;
	}
//@#endif
		return DAnimID.MAP_ACTOR_ICON_LABYRINTH + worldId;
}

CGame.prototype.GetLevelTextByLevelId = function (levelId) {
//@#if RemoveIceLevel
	if(levelId >= (DAI.WORLD_ID_ICE+1) * DAI.LEVELS_NUM_PRE_WORLD) {
		levelId += DAI.LEVELS_NUM_PRE_WORLD;
	}
//@#endif
	var level = levelId - DAI.LEVELS_NUM_PRE_WORLD;
//@#if RemoveBeeKillerBoss
//@		if(level >= (DAI.WORLD_ID_CAKE + 1) * DAI.LEVELS_NUM_PRE_WORLD - 1) {
//@			levelId ++;
//@		}
//@#endif
//@#if RemoveUfoBoss
//@		if(level >= (DAI.WORLD_ID_SPACE + 1) * DAI.LEVELS_NUM_PRE_WORLD - 1) {
//@			levelId ++;
//@		}
//@#endif
	return TEXT.MENU_LEVEL1 + levelId;
}

CGame.prototype.GetLevelMenuTextByLevelId = function( levelId) {
var level = levelId;
//@#if RemoveBeeKillerBoss
//@	if(level >= (DAI.WORLD_ID_CAKE + 1) * DAI.LEVELS_NUM_PRE_WORLD - 1) {
//@		levelId ++;
//@	}
//@#endif
//@#if RemoveUfoBoss
//@	if(level >= (DAI.WORLD_ID_SPACE + 1) * DAI.LEVELS_NUM_PRE_WORLD - 1) {
//@		levelId ++;
//@	}
//@#endif
return TEXT.MENU_LV1_1 + levelId;
}

CGame.prototype.GetLevelWizardTextByWorldId = function( worldId) {
//@#if RemoveIceLevel
	if(worldId > DAI.WORLD_ID_ICE) {
		worldId ++;
	}
//@#endif
		return TEXT.MENU_WIZARD_LABYRINTH + worldId + 1;
}
/*
 * draw special effect in loading phase	
 */
CGame.prototype.DrawSpecialEffect_Load_Unload = function( worldEntered)
{
	var world = 0;
	var width = 0;
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
	worldEntered = this.GetWorldMapActorIconByWorldId(worldEntered);
	var framID = CGame.spriteArray[DSpriteID.MAP_ACTOR].GetAnimFrame(worldEntered, 0);
	width = CGame.spriteArray[DSpriteID.MAP_ACTOR].GetFrameWidth(framID);
	var modulex = CGame.spriteArray[DSpriteID.MAP_ACTOR].GetFrameModuleX(framID, 0);
	//var moduley = CGame.spriteArray[DSpriteID.MAP_ACTOR].GetFrameModuleY(framID, 0);
	var draw_pos_x = 0 - modulex;
	if (CGame._gameProgress > GAME_PROGRESS_FIRST_MINI_MAP_EVENT && worldEntered <= DAnimID.MAP_ACTOR_ICON_SPACE) {
			CGame.spriteArray[DSpriteID.MAP_ACTOR].PaintAFrame(g, worldEntered, world, 
														draw_pos_x + (GLLibConfig.screenWidth - width)/2, 
															DGUI.INTERFACE_LOAD_UNLOAD_WORLDICON_POS_Y, 0);
	}
	//draw the name of the current world!
		//CGame.txtDraw(0, Text_GetString(TEXT.MENU_LEVEL1 + CGame._tempLevelId), DEF.SCR_W_D2, DGUI.INTERFACE_LOAD_UNLOAD_WORLDICON_POS_Y+35, GRPH.HCENTER_TOP);
	var align = 1;
	var lineWidth = DEF.VIEW_W - 20;
	var startLine = 0;
	var lineCount = 30;
	var posX = DEF.VIEW_W_D2;
	var posY = 80;
	var palette = 0;
	var lineInterval = 5;
		if(CGame._gameProgress > GAME_PROGRESS_FIRST_MINI_MAP_EVENT && CGame._tempLevelId < DAI.LEVEL_ID_INTRO_NEW_GAME) {
			CGame.DrawMultiLineText ( g, Text_GetString(this.GetLevelTextByLevelId(CGame._tempLevelId)), posX, DGUI.INTERFACE_LOAD_UNLOAD_WORLDICON_POS_Y - DGUI.LOAD_UNLOAD_TEXT_OFFSETY, 
					align, palette, lineWidth, startLine, lineCount, lineInterval); 
	}
	//draw the stars
	var stopPosX = DGUI.LOADSTAR_X;
	var stopPosY = DGUI.LOADSTAR_Y;
	this.DrawLevelStars(CGame._tempLevelId, stopPosX, stopPosY);	
	
	if (CGame.loadingPhase != DLoadState.LOAD_OVER) {
		CGame.txtDraw(0, Text_GetString(TEXT.MENU_LOADING)+"...", GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight-10 *DScreen.RATIO, VCENTER | HCENTER);
	}
	else {
		if ((s_game_currentFrameNB % 10) > 5)
//@#if not TOUCH_SCREEN				
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight-10, VCENTER | HCENTER);
//@#else
		CGame.DrawMultiLineText ( g, Text_GetString(TEXT.MENU_PRESS_ANY_KEY_TOUCH), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - 5  * DScreen.RATIO, BOTTOM | HCENTER, 0,  GLLibConfig.screenWidth, 0, 10, 5);

//@#endif
	}
	var reDrawBegin_x = (56 + CGame.loadingPhase*17)* DScreen.RATIO;
	var redrawRegin_h = 37 * DScreen.RATIO;
	g.setClip(reDrawBegin_x, DEF.VIEW_H - redrawRegin_h, DEF.VIEW_W - reDrawBegin_x, redrawRegin_h);
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
	g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
	var loadSprite = CGame._loadingSpriteMap[CGame._worldId << 1];
	var loadSpriteAnimID = CGame._loadingSpriteMap[(CGame._worldId << 1) + 1];
	if( worldEntered == 0 ){
		//TODO
		//CGame.spriteArray[loadSprite].SetCurrentMMapping(_mappingIndexForThief);
	}
		if (CGame._tempLevelId < DAI.LEVEL_ID_INTRO_NEW_GAME && CGame.loadingPhase != DLoadState.LOAD_OVER) {
			if (CGame._gameProgress > GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
				CGame.spriteArray[loadSprite].PaintAFrame(g,	loadSpriteAnimID, 
														s_game_currentFrameNB % CGame.spriteArray[loadSprite].GetAFrames(loadSpriteAnimID),
														reDrawBegin_x, //DGUI.INTERFACE_STAR_POS_X_MINIMAP, 
														DEF.VIEW_H - DGUI.INTERFACE_STAR_BOTTOM_OFFSET_Y_LOADING+72 * DScreen.RATIO, 0);
			}
		}
		
	}
CGame.DrawSpecialEffect_Load_Unload_MiniMap = function( step)
{
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	if (_splash == null) {
		if (DEF.dbgEnable)  Dbg("---------------------- splash..reload");
		Pack_Open(DATA.PACK_SPLASH);
		// _splash = new ASprite();
		// _splash.Load(Pack_ReadData(DATA.SPLASH_SPLASH), 0);
		_splash = CGame.LoadSprite(DATA.SPLASH_SPLASH, -1, true, false);
//@    #if CacheSpalshForOptimize
//@            for( var i = 0 ; i < _splash._palettes ; i ++ )
//@                _splash.BuildCacheImages(i, 0, -1, -1);
//@    #endif
		Pack_Close();
	}
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
		
	if (step != CGame.MINI_MAP_LOADING_STEP) {
		CGame.txtDraw(0, Text_GetString(TEXT.MENU_LOADING)+"...", GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight-10 * DScreen.RATIO, VCENTER | HCENTER);
	}
	else {
		if ((s_game_currentFrameNB % 10) > 5)
//@#if not TOUCH_SCREEN				
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight-10, VCENTER | HCENTER);
//@#else
		CGame.DrawMultiLineText ( g, Text_GetString(TEXT.MENU_PRESS_ANY_KEY_TOUCH), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - 10 * DScreen.RATIO, BOTTOM | HCENTER, 0,  GLLibConfig.screenWidth, 0, 10, 5);

//@#endif			
	}
	var reDrawBegin_x = (56 + step*17)* DScreen.RATIO;
	var redrawRegin_h = 37 * DScreen.RATIO;
	g.setClip(reDrawBegin_x, DEF.VIEW_H - redrawRegin_h, DEF.VIEW_W - reDrawBegin_x, redrawRegin_h);
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
		g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
}
//@#endif


var loading_Interface_load_mask = 0; 
CGame.prototype.UpdateGameState_LOAD_UNLOAD = function() //throws Exception
{
	if (CGame.loadingPhase == 0) {
		CGame._sprites_load_mask = (1 << DSpriteID.BONUS) | (1 << DSpriteID.MAP_ACTOR);
		CGame._sprites_load_mask |= (1 << CGame._loadingSpriteMap[CGame._worldId << 1]);
			loading_Interface_load_mask = CGame._sprites_load_mask; 
		CGame.LoadUnload(DLoadState.LOAD_SPRITE);
	}
	CGame.loadingPhase = CGame.LoadUnload(CGame.loadingPhase);
	if( CGame.loadingPhase > 0 )
	{	
//@#if not RemoveMinimap
	try{//xxh add for w810i
			this.DrawSpecialEffect_Load_Unload(CGame._worldId);
		} catch ( ex){
			if (DEF.dbgEnable) Dbg(" DrawSpecialEffect_Load_Unload  error : " + ex.message);
		}
//@#endif
	}
//		else if (CGame.redrawAll || s_game_varerruptNotify)
//		{
//			//SetColor(MENU_BACKGROUND_COLOR);
//			FillRect(0, 0, GetScreenWidth(), GetScreenHeight());
//			g.drawImage(_menu_bg, 0, 0, GRPH.LEFT_TOP);
//			// draw "LOADING" --> here we can use  MENU_LOADING or INIT_LOADING indiferently since they share the same index in their respective text files
//			CGame.txtDraw(0, Text_GetString(TEXT.MENU_LOADING), GetScreenWidth() / 2, GetScreenHeight() / 2, VCENTER | HCENTER);
//			CGame.redrawAll = false;
//		}

	// end of loading
	if (CGame.loadingPhase == DLoadState.LOAD_OVER)
	{
		if(WasAnyKeyReleased()  == GLKey.k_fire) {
			if (LOADING_BEFORE_SOUND_PROMPT)
			{
				s_game_state = STATE.SELECT_LANGUAGE_INIT;
			}
			else
			{
				CGame.GotoInitLevel(false);
				var curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
				if(curLevelId >= 0)
				{
					var _lv = Text_GetString(this.GetLevelMenuTextByLevelId(curLevelId));
					_lv = _lv.substring(_lv.length - 3, _lv.length);
					GGTracking.getInstance().push(POINTCUTID.LEVELSTART, _lv, CGame._levelTotalScore[CGame._tempLevelId]);
				}
				for (var i = 0; i < 64; i++) {
						if ((loading_Interface_load_mask & (1 << i)) != 0) {
						if ((CGame._sprites_load_mask & (1 << i)) == 0) {
							if (DEF.dbgEnable) Dbg("spriteUnLoad : *******************  DLoadState.LOAD_OVER");
							CGame.spriteUnLoad(i);
						}
					}
				}
					loading_Interface_load_mask = 0;
			}
			if (Build.useCGMRC)
			{
				CGame.s_next_state = s_game_state;
				s_game_state = STATE.K_MRC_INIT;
			}
			CGame.redrawAll = true;
		}
		CGame.loadingPhase --;
	}
	// end of unloading
	else if (CGame.loadingPhase == DLoadState.UNLOAD_OVER)
	{
		if (CGame.s_next_game_state_after_unload != -1) {
			s_game_state = CGame.s_next_game_state_after_unload;
			if (s_game_state == STATE.MENU_MAP) {
				s_game_state = STATE.CONTINUE_GAME;
			}
			CGame.s_next_game_state_after_unload = -1;
		} else {
		// call the gc at the very last step of uloading
			s_game_state = STATE.QUIT;
		}
		// Gc();
	}
}

var _currentClipPosY = 0;
var _currentClipHeight = 0;
var _gameRestart = false;
var _gameOver = false;
CGame.prototype.UpdateGameState_GAMEOVER = function()// throws Exception
{
	// Fix bug background don't draw with WebGl.
	// CGame.redrawAll = true;
	// CGame.bIsPaused = true;
	if (CGame.redrawAll){
		if (CGame.bIsPaused) {
			if (CGame.bIsMiniMap) {
				this.DrawMiniMap();
			} else {
				this.gameDraw();					
			}
		}
	}
	
	var curtailDrawCompleted = false;		
	if (_currentClipHeight >= DEF.VIEW_H_D2) {
		_currentClipHeight = DEF.VIEW_H_D2;
		curtailDrawCompleted = true;			
	}
	if(!curtailDrawCompleted) {			
		_currentClipPosY += Math.floor(DGUI.SCREEN_CLOSED_STEP);
		_currentClipHeight = _currentClipPosY;
		CGame._lastFrameNB = /*GLLib.*/s_game_currentFrameNB;
	}
	// Fix bug fill rect missing when _currentClipPosY >= DEF.VIEW_H_D2
	if (_currentClipPosY >= DEF.VIEW_H_D2)
		_currentClipPosY = DEF.VIEW_H_D2;

	g.setColor(0);
	g.setClip(0, 0, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	g.setClip(0, DEF.VIEW_H - _currentClipPosY, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);

//		else {
//			CGame.txtDraw(0, Text_GetString(TEXT.MENU_RESTART_LEVEL), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight / 2, BOTTOM | HCENTER);
//		}
	
	if (curtailDrawCompleted) {
		if (CEntity._HeroParams[DAI.HPI_LIVES] <= 0) {
			g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
			FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
			
			if (CEntity._HeroParams[DAI.HPI_LIVES] <= 0) {
				CGame.txtDraw(0, Text_GetString(TEXT.MENU_GAME_OVER), GLLibConfig.screenWidth / 2, 30 * DScreen.RATIO, BOTTOM | HCENTER);
			} 
			CGame.DrawAnimation(DSpriteID.HERO, DAnimID.HERO_GAME_OVER, DEF.VIEW_W_D2, 100 * DScreen.RATIO, 4);
			this.DrawgameOverChoice();
		} else {
			var waiteFrame = 10;
			if(/*GLLib.*/s_game_currentFrameNB - CGame._lastFrameNB >= waiteFrame) {
				CGame.GotoRestart(true);
				//DrawgameOverChoice();
				_gameRestart = true;
				_currentClipPosY = DEF.VIEW_H_D2;
				_currentClipHeight = DEF.VIEW_H_D2;
			}
		}
	}
}

CGame.prototype.UpdateGameState_GAMEEND = function() //throws Exception
{
	var curtailDrawCompleted = false;		
	if (_currentClipHeight >= DEF.VIEW_H_D2) {
		_currentClipHeight = DEF.VIEW_H_D2;
		curtailDrawCompleted = true;			
	}
	if(!curtailDrawCompleted) {			
		_currentClipPosY += 14;
		_currentClipHeight = _currentClipPosY;
		CGame._lastFrameNB = /*GLLib.*/s_game_currentFrameNB;
	}
	g.setColor(0);
	g.setClip(0, 0, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	g.setClip(0, DEF.VIEW_H - _currentClipPosY, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	
	if (curtailDrawCompleted) {
		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		CGame.txtDraw(0, Text_GetString(TEXT.MENU_THE_END), DEF.SCR_W_D2, DEF.SCR_H_D2, VCENTER | HCENTER);
		if ((s_game_currentFrameNB % 10) > 5)
//@#if not TOUCH_SCREEN				
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), DEF.SCR_W_D2, DEF.SCR_H - 10, VCENTER | HCENTER);
//@#else	
					CGame.DrawMultiLineText ( g, Text_GetString(TEXT.MENU_PRESS_ANY_KEY_TOUCH), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - DGUI.PRESS_5_OFFSET_POSY, BOTTOM | HCENTER, 0,  GLLibConfig.screenWidth, 0, 10, 5);
//@#endif						

			
		_keycode = WasAnyKeyReleased();
		if (_keycode >= 0)
		{
			if(CGame._multiLineTextCurrentCursor >=0 ) {
				CGame._multiLineTextCurrentCursor = -1;
			}
			// On select..
			if (((_keycode == GLKey.k_menuOK) || (_keycode == GLKey.k_fire)) &&	currentMenuDepth < MENU.MAX_DEPTH)
			{
				// if(_is_igp_actived)
				// {
					// CGame.GotoEndGameIGP();
				// } 
				// else 
				{
					s_game_state = STATE.LOAD_UNLOAD;
					CGame.loadingPhase = -DLoadState.LOAD_OVER;
					CGame.initMenus();
					CGame.s_next_game_state_after_unload = STATE.MENU_ABOUT;
//@#if LG_KU970
//@						gameRepavar = true;
//@#endif
					currentMenu[++currentMenuDepth] = MENU_ABOUT_INDEX;
				}
				_gameOver = true;
				_currentClipPosY = 0;
				_currentClipHeight = 0;
			}			
			// Refresh the menu on any keypress
			CGame.redrawAll = true;
			ResetKey();
		}
	}
}

var currentSelectionInGameOver = 0;
CGame.prototype.DrawgameOverChoice = function() 
{
	//_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2, DEF.SCR_H_D2, 0);
	var fontPalette = 2;
	var halfWidth = GLLibConfig.screenWidth / 2;
//@#if HEIGHT220
//@		var optionsStartPosY[] = {150, 180};
//@#else
	var optionsStartPosY = [200  * DScreen.RATIO, 230  * DScreen.RATIO];
//@#endif
	var textPos = null;
	g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
//@#if HEIGHT220
//@		CGame.txtDraw(fontPalette,Text_GetString(TEXT.MENU_RESTART_REQUIRE), halfWidth, 110, TOP | HCENTER);
//@#else
	CGame.txtDraw(fontPalette,Text_GetString(TEXT.MENU_RESTART_REQUIRE), halfWidth, 160 * DScreen.RATIO, TOP | HCENTER);
//@#endif
	for (var i = 0; i < 2; i++) {
//@#if TOUCH_SCREEN
		if (CGame.isPointInRect(MENU_IGM_X, optionsStartPosY[i] - (TOUCH_MENU_ITEM_HEIGHT>>1) + 5, 
				GetScreenWidth() - (MENU_IGM_X << 1), TOUCH_MENU_ITEM_HEIGHT))
		{
			if (currentSelectionInGameOver == i) 
			{
				this.keyPressed(GLLibConfig.keycodeFire);
				this.keyReleased(GLLibConfig.keycodeFire);
				CGame.UpdateKeyState();
			}
			else
			{
				currentSelectionInGameOver = i;
			}
			
		}
		
//@#endif	
		if (currentSelectionInGameOver == i) {
			// try {
				textPos = this.txtDrawSpecialEffectWave(currentSelectionInGameOver == i ? MENU_ITEM_COMMON_SELECT_PAL : MENU_ITEM_COMMON_NOT_SELECT_PAL,Text_GetString(TEXT.MENU_SK_YES + i), halfWidth, optionsStartPosY[i], LEFT);
			// } catch (e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			// }
		} else {
			CGame.txtDraw(fontPalette,Text_GetString(TEXT.MENU_SK_YES + i), halfWidth, optionsStartPosY[i], TOP | HCENTER);
		}
	
	}
	//CGame.txtDraw(fontPalette,Text_GetString(TEXT.MENU_SK_OK), 0, DEF.VIEW_H, BOTTOM); // bug 9736143
	var x1 = textPos[0] - 15 * DScreen.RATIO;
	var x2 = textPos[1] + 15 * DScreen.RATIO;
	var y = optionsStartPosY[currentSelectionInGameOver]+5; // + ASprite.GetCurrentStringHeight()>>1;
		CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_CURSOR, s_game_currentFrameNB % CGame._interface.GetAFrames(DAnimID.INTERFACE_MENU_CURSOR), x1, y, 0);
		CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_MENU_CURSOR, s_game_currentFrameNB % CGame._interface.GetAFrames(DAnimID.INTERFACE_MENU_CURSOR), x2, y, 0);
	_keycode = WasAnyKeyReleased();
	if (_keycode >= 0)
	{
		// On select..
		if (((_keycode == GLKey.k_menuOK) || (_keycode == GLKey.k_fire)) &&	currentMenuDepth < MENU.MAX_DEPTH)
		{
			try {
				CGame.RMS_Load();
			} catch (e) {
				// TODO Auto-generated catch block
				if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);
			}

			if (currentSelectionInGameOver == 1) { // select no: go to the main menu!
				this.GotoMainMenu();
			} else { //select yes: go to the castile minimap!
				if (CGame._playerInfo[DAI.HPI_LIVES] < 3) {
					CGame._playerInfo[DAI.HPI_LIVES] = 3;
				}
				s_game_state = STATE.LOAD_UNLOAD;
				CGame.loadingPhase = -DLoadState.LOAD_OVER;
				CGame.s_next_game_state_after_unload = STATE.MENU_MAP;
				CGame.bIsPaused = false;
			}
			_gameOver = true;
			_currentClipPosY = 0;
			_currentClipHeight = 0;
		}			
		// On Up..
		if (_keycode == GLKey.k_up)
		{
			currentSelectionInGameOver = (++currentSelectionInGameOver) % 2;
		}
		// On Down..
		else if (_keycode == GLKey.k_down)
		{
			currentSelectionInGameOver = (++currentSelectionInGameOver) % 2;
		}

		// Refresh the menu on any keypress
		CGame.redrawAll = true;
		ResetKey();
	}
}

CGame.drawTheCurtainOpen = function() 
{
	_currentClipPosY-=18;
	//_currentClipHeight-=8;
	_currentClipHeight = _currentClipPosY;
	if (_currentClipHeight <= 0) {
		_currentClipPosY = 0;
		_currentClipHeight = 0;
		_gameRestart = false;
	}
	g.setColor(0);
	g.setClip(0, 0, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	g.setClip(0, DEF.VIEW_H - _currentClipPosY, DEF.VIEW_W, _currentClipHeight);
	FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
}

var _newRecord = false;
var _levelCompleted = false;
var _levelCompleteEffectStep = 0;
var LEVEL_COMPLETE_STEP_DRAW_TITLE = 0;
var LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS = 1;
var LEVEL_COMPLETE_STEP_DRAW_TOTAL_SUMS = 2;
CGame.prototype.UpdateGameState_GAME_STATISTIC = function()// throws Exception
{
	this.gameDraw();
	var width = GLLibConfig.screenWidth;
	var height = GLLibConfig.screenHeight;
	var startx = DGUI.GAME_STATISTIC_STARTX, starty = DGUI.GAME_STATISTIC_STARTY;

//@#if WIDTH_320
//@		CGame.FillArgbRect(0, 0, 160, 112, 0x68000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@		CGame.FillArgbRect(160, 0, 160, 112, 0x68000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@		CGame.FillArgbRect(0, 112, 160, 112, 0x68000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@		CGame.FillArgbRect(160, 112, 160, 112, 0x68000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@#else
	CGame.FillArgbRect(0, 0, width, height, 0x68000000 | MENU_PAUSE_BACKGROUND_COLOR);
//@#endif

	var numResult = LowAPI.Gen_Array([3],0);//new var[3];

	var newPalette = 1;
	var amplitude = 4;
	var period = 1;
	var flowSpeed = 120;
	switch (_levelCompleteEffectStep) {
	case LEVEL_COMPLETE_STEP_DRAW_TITLE:
		fontSpr.SetCurrentPalette(1);
		CGame._stopMove = true;
		_newRecord = false;
		_levelCompleted = false;
		var maxLengthPerLine = DEF.VIEW_W;
			this.txtDarwSpecialEffecFlowIntoTheScreen(Text_GetString(TEXT.MENU_LEVEL_COMPLETE), fontSpr, width>>1, starty, _flowFromLeft, maxLengthPerLine, flowSpeed, LEFT);
		if (CGame._stopAdd) {
			_levelCompleteEffectStep++;
			CGame._stopMove = false;
			CGame._moveSpeed = 0;
				CGame._firstEnterIntoThisFunction = true;
		}
		break;
		
	case LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS:
		this.txtDrawSpecialEffectWave_New(1,Text_GetString(TEXT.MENU_LEVEL_COMPLETE), width>>1, starty, amplitude, period, LEFT);
		var drawItemsOver = this.DrawAllTheItemsResults(startx, starty, width, numResult, newPalette);
		if (drawItemsOver) {
			CGame._moveSpeed = 0;
			CGame._stopMove = false;
			_levelCompleteEffectStep++;
		}
		break;
		
	case LEVEL_COMPLETE_STEP_DRAW_TOTAL_SUMS:
		this.txtDrawSpecialEffectWave_New(1,Text_GetString(TEXT.MENU_LEVEL_COMPLETE), width>>1, starty, amplitude, period, LEFT);
//@#if HEIGHT220
//@			DrawAllTheItemsResults(startx, starty-15, width, numResult, newPalette);
//@			DrawTheTotalSums(startx, starty+130-15, width, numResult, newPalette);			
//@#else
		this.DrawAllTheItemsResults(startx, starty, width, numResult, newPalette);
		this.DrawTheTotalSums(startx, starty+
//@#if HEIGHT_268					
//@					120
//@#else
				130 * DScreen.RATIO
//@#endif					
				, width, numResult, newPalette);
//@#endif//HEIGHT220
		break;
		
	default:
		
	}		
	
	if (_StatisticCompleted) {
		if ((s_game_currentFrameNB % 10) > 5) {
//@#if LG_KU970
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - DGUI.PRESS_5_OFFSET_POSY, BOTTOM | HCENTER);
//@#else
//@	#if HEIGHT220
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - DGUI.PRESS_5_OFFSET_POSY, BOTTOM | HCENTER);
//@	#else
//@#if not TOUCH_SCREEN
//@				CGame.txtDraw(0, Text_GetString(TEXT.MENU_PRESS_5), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - DGUI.PRESS_5_OFFSET_POSY, BOTTOM | HCENTER);
//@#else
			CGame.DrawMultiLineText ( g, Text_GetString(TEXT.MENU_PRESS_ANY_KEY_TOUCH), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight - DGUI.PRESS_5_OFFSET_POSY, BOTTOM | HCENTER, 0,  GLLibConfig.screenWidth, 0, 10, 5);

//@#endif //TOUCH_SCREEN
//@	#endif //HEIGHT220
//@#endif
		}
	}
	
	if (WasKeyReleased(GLKey.k_fire)) {
			if (!_StatisticCompleted) {
				_levelCompleteEffectStep = LEVEL_COMPLETE_STEP_DRAW_TOTAL_SUMS;
				CGame._moveSpeed = 0;
				CGame._stopMove = true;
			} else {
				CGame._moveSpeed = 0;
				CGame._stopMove = false;
				_newRecord = false;
				_levelCompleteEffectStep = 0;
				_StatisticCompleted = false;
				CGame._playerInfo[DAI.HPI_LIVES] = CEntity._HeroParams[DAI.HPI_LIVES];
				CGame._playerInfo[DAI.HPI_HP_MAX] = CEntity._hero._hp;
//@#if Use_Motion_Sensor
//@					CGame._playerInfo[DAI.HPI_SHAKE] =  CEntity._HeroParams[DAI.HPI_SHAKE];
//@					CGame._playerInfo[DAI.HPI_ROCK] =  CEntity._HeroParams[DAI.HPI_ROCK];
//@#endif
				CGame.GotoNextLevel(true);
				//  reset for the draw of title
					CGame._firstEnterIntoThisFunction = true;
				CGame._actionSpeed = 0;
			}
		
		}
	
	if (!CGame._stopMove) {
		CGame._moveSpeed+=15;
	}
}
//@#if WIDTH176
//@	var GAME_STATISTIC_FINAL_X[] = { 10, 43, 53, 100, 110, 160};
//@#else
var GAME_STATISTIC_FINAL_X = [ 30 * DScreen.RATIO, 73 * DScreen.RATIO, 83 * DScreen.RATIO, 138 * DScreen.RATIO, 148 * DScreen.RATIO, 218 * DScreen.RATIO];
//@#endif
CGame.prototype.DrawAllTheItemsResults = function(startx, starty, width, numResult, newPalette)// throws Exception
{
	var x = 0;
	var y = starty;
	var animId = [DAnimID.BONUS_CRYSTAL, DAnimID.BONUS_1UP, DAnimID.BONUS_STAR];
	var number = [CEntity._HeroParams[DAI.HPI_CRYSTAL_COUNT], CEntity._HeroParams[DAI.HPI_LIVES], (DAI.MAX_STAR_NUM - CGame._levelStarInfo[CGame._tempLevelId*DAI.STAR_INFO_SIZE])];
	
	var numMulti = [1,100,200];
	starty += 20 * DScreen.RATIO;
	var iconStartPos_X = [DEF.VIEW_W, DEF.VIEW_W+50, DEF.VIEW_W+50*2,DEF.VIEW_W+50*3, DEF.VIEW_W+50*4, DEF.VIEW_W+50*5];

	var itemFinalPos_X = LowAPI.Gen_Array([GAME_STATISTIC_FINAL_X.length],0);//new var[GAME_STATISTIC_FINAL_X.length];
	for(var i=0; i<GAME_STATISTIC_FINAL_X.length; i++) {
		itemFinalPos_X[i] = GAME_STATISTIC_FINAL_X[i];
	}

	for(var i = 0; i < 3; i++) {
		y = starty + 40*(i+1) * DScreen.RATIO;
		if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
			x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[0]) {
					x = itemFinalPos_X[0];
				if(i == 2) {
					CGame._stopMove = true;
				}
			}
		} else {
				x = itemFinalPos_X[0];
		}
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, animId[i], 
														s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(animId[i]), 
														x, y, 0);
			
			
			if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
				x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[1]) {
					x = itemFinalPos_X[1];
				}
			} else {
				x = itemFinalPos_X[1];
			}
			y -= 15 * DScreen.RATIO;
			CGame.txtDraw(newPalette, String(number[i]), x, y, TOP | RIGHT);
			
			if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
				x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[2]) {
					x = itemFinalPos_X[2];
				}
			} else {
				x = itemFinalPos_X[2];
			}
			CGame.txtDraw(newPalette, "X", x, y, TOP | LEFT);
			
			if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
				x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[3]) {
					x = itemFinalPos_X[3];
				}
			} else {
				x = itemFinalPos_X[3];
			}
			CGame.txtDraw(newPalette, String(numMulti[i]), x, y, TOP | RIGHT);
			
			if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
				x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[4]) {
					x = itemFinalPos_X[4];
				}
			} else {
				x = itemFinalPos_X[4];
			}
			CGame.txtDraw(newPalette, "=", x, y, TOP | LEFT);
			
			if (_levelCompleteEffectStep == LEVEL_COMPLETE_STEP_DRAW_EACH_ITEMS) {
				x = iconStartPos_X[i] - CGame._moveSpeed;
				if (x <= itemFinalPos_X[5]) {
					x = itemFinalPos_X[5];
				}
			} else {
				x = itemFinalPos_X[5];
			}
			numResult[i] = number[i]*numMulti[i];		
			CGame.txtDraw(newPalette, String(numResult[i]), x, y, TOP | RIGHT);
		}
	return CGame._stopMove;
}

var _StatisticCompleted = false;
CGame.prototype.DrawTheTotalSums = function(startx, posY, width, numResult, newPalette) //throws Exception
{
//		draw line.

	var totalSumPos_Y = [DEF.VIEW_H, DEF.VIEW_H+30, DEF.VIEW_H+30+30,DEF.VIEW_H+30+30+30];
	var currentPos_Y;
	var x = startx;
	var y = posY;
//@#if HEIGHT220
//@		y += 15;
//@#else
	y += 30 * DScreen.RATIO;
//@#endif
	g.setColor(0xff8000);
	currentPos_Y = totalSumPos_Y[0] - CGame._moveSpeed;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
	}
	
	g.drawLine(x, currentPos_Y, width - (startx), currentPos_Y);
	y += 2;
	currentPos_Y = totalSumPos_Y[0] - CGame._moveSpeed+10;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
	}
	g.drawLine(x, currentPos_Y, width - (startx), currentPos_Y);
	y += 1;
	currentPos_Y = totalSumPos_Y[0] - CGame._moveSpeed+20;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
	}
	g.drawLine(x, currentPos_Y, width - (startx), currentPos_Y);
	
	
	//draw total.
	//x = DGUI.GAME_STATISTIC_TOTAL_NUM_OFFSETX - 5;
		x = GAME_STATISTIC_FINAL_X[3];
//@#if HEIGHT220
//@		y += 12;
//@#else
	y += 8 * DScreen.RATIO;
//@#endif
	currentPos_Y = totalSumPos_Y[1] - CGame._moveSpeed;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
	}
	CGame.txtDraw(newPalette, Text_GetString(TEXT.MENU_TOTAL), x, currentPos_Y, TOP | RIGHT);
	x = DGUI.GAME_STATISTIC_TOTAL_NUM_OFFSETX;
	currentPos_Y = totalSumPos_Y[2] - CGame._moveSpeed;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
	}
	CGame.txtDraw(newPalette, "=", x, currentPos_Y, TOP | LEFT);
	var total = numResult[0] + numResult[1] + numResult[2];
	if (total > CGame._levelTotalScore[CGame._tempLevelId]) {
		_newRecord = true;
		CGame._levelTotalScore[CGame._tempLevelId] = total;
	}
	if(!_levelCompleted)
	{
		_levelCompleted = true;
		var curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
		var _lv = Text_GetString(this.GetLevelMenuTextByLevelId(curLevelId));
		_lv = _lv.substring(_lv.length - 3, _lv.length);
		GGTracking.getInstance().push(POINTCUTID.LEVELCOMPLETION, _lv, total);
		CGame.RMS_Save();
	}
	currentPos_Y = totalSumPos_Y[3] - CGame._moveSpeed;
	if (currentPos_Y <= y || CGame._stopMove) {
		currentPos_Y = y;
		_StatisticCompleted = true;
	}
//@#if WIDTH_320
//@		x = width - (startx<<1) - 72;
//@#else
	x = width - (startx<<1) + 18 * DScreen.RATIO;
//@#endif
		//x = DGUI.GAME_STATISTIC_FINAL_X[3];
		CGame.txtDraw(newPalette, String(total), x, currentPos_Y, TOP | RIGHT);
		if (_newRecord) {
			newPalette = 3;
			CGame.txtDraw(newPalette, Text_GetString(TEXT.MENU_NEW_RECORD), x, currentPos_Y+24 * DScreen.RATIO, TOP | RIGHT);
		}
	}


CGame.prototype.UpdateGameState_MENU_INIT = function() //throws Exception
{
	CGame.initMenus();
	Text_LoadTextFromPack_INI(textPack, DATA.TEXT_MENU);

	if (CGame.bIsPaused)
	{
		currentMenu[currentMenuDepth] = MENU_INGAME_INDEX;
		s_game_state = STATE.MENU_INGAME;
	}
	else
	{
		s_game_state = STATE.MENU_TNB_MAIN;//STATE.MENU_MAIN;
	}

	CGame.redrawAll = true;
}

CGame.prototype.UpdateGameState_ASK_SOUND = function()// throws Exception
{
//@	#if HEIGHT220
//@		PARENT_TITLE_OFFSET_POS_Y = -25;
//@	#endif
	if(CGame._isInputEvent)
	{
		CGame._isInputEvent = false;
		var posF = this._FakegetMousePos(CGame._eventCallback );
		// CGame._eventCallback = null;
		pointerPosX = posF.x ;
		pointerPosY = posF.y ;
	}
	switch(this.updateMenu())
	{
		case STATE.YES:
			_currentSoundOption = 0; //on
			if (!CGame.isSoundEnabled)
			{
				//CGame.isSoundEnabled = true;
				if (SOUND_STATE_AS_LEVELS)
					GLLibPlayer.Snd_SetMasterVolume(SOUND_LEVEL_HIGH);
				this.startSound();
			}
			if (CGame.bSetSound)
			{
				s_game_state = STATE.SPLASH;
			}
			else
			{
				currentMenuDepth -= 1;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			}

			CGame.bSetSound = false;
			CGame.RMS_Save();
			break;
		case STATE.NO:
			_currentSoundOption = 1; // off
			if (CGame.isSoundEnabled)
			{
				this.StopSound();
				//CGame.isSoundEnabled = false;
			}
			if (CGame.bSetSound)
			{
				s_game_state = STATE.SPLASH;
			}
			else
			{
				currentMenuDepth -= 1;
				s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			}

			CGame.bSetSound = false;
			CGame.RMS_Save();
			break;
	}
}

CGame.prototype.UpdateGameState_ASK_SOUND_LEVEL = function() //throws Exception
{
	PARENT_TITLE_OFFSET_POS_Y = 80;
	OPTIONS_OFFSET_POS_Y = -20;
	switch(this.updateMenu())
	{
		case STATE.YES:
		{
			this.startSound();
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;

		case STATE.NO:
		{
			if (CGame.isSoundEnabled)
			{
				this.StopSound();
				CGame.isSoundEnabled = false;
			}
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;

		case STATE.SOUND_HIGH:
		{
			if (GLLibPlayer.s_snd_masterVolume != SOUND_LEVEL_HIGH || !CGame.isSoundEnabled)
			{
				//CGame.isSoundEnabled = true;
				GLLibPlayer.Snd_SetMasterVolume(SOUND_LEVEL_HIGH);
				this.StopSound();
				this.startSound();
			}
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;

		case STATE.SOUND_MEDIUM:
		{
			if (GLLibPlayer.s_snd_masterVolume != SOUND_LEVEL_MEDIUM || !CGame.isSoundEnabled)
			{
				//CGame.isSoundEnabled = true;
				GLLibPlayer.Snd_SetMasterVolume(SOUND_LEVEL_MEDIUM);
				this.StopSound();
				this.startSound();
			}
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;

		case STATE.SOUND_LOW:
		{
			if (GLLibPlayer.s_snd_masterVolume != SOUND_LEVEL_LOW || !CGame.isSoundEnabled)
			{
				//CGame.isSoundEnabled = true;
				GLLibPlayer.Snd_SetMasterVolume(SOUND_LEVEL_LOW);
				this.StopSound();
				this.startSound();
			}
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;

		case STATE.SOUND_OFF:
		{
			if (CGame.isSoundEnabled)
			{
				this.StopSound();
				CGame.isSoundEnabled = false;
			}
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			CGame.RMS_Save();
		}
		break;
	}
}

CGame.prototype.UpdateGameState_MENU_EXIT = function() //throws Exception
{
	switch(this.updateMenu())
	{
		case STATE.YES:
		{
			s_game_state = STATE.QUIT;
//@#if BREW_GlobalSplash
//@				_splash = null;
//@#endif // BREW_GlobalSplash
		}
		break;

		case STATE.NO:
		{
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
		}
		break;
	}
}


var _currentPage_Help = 0;
var _eachLinePosY = [0,0,0];
var _iconInHelpPosX  = 0;
CGame.prototype.UpdateGameState_MENU_HELP = function()// throws Exception
{
	if (!_enterintoTheHelpFromIGM) {
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
		} else {						
		//g.fillRect(0, 0, DEF.VIEW_W, DEF.VIEW_H);
		var halfWidth = GLLibConfig.screenWidth / 2;
		var halfHeight = GLLibConfig.screenHeight / 2;
		var backgroundHeight = 0;
		var backgroundTopPosY = 0;
		var optionsStartPosY = 0;
		var rc_menu = LowAPI.Gen_Array([4],0);//new var[4];
		var mw,mh;
		_menuIngame.GetAFrameRect(rc_menu, DAnimID.MENU_INGAME_INGAMEMENU, 0, 0, 0, 0);
		mw = rc_menu[DEF.BOX_RIGHT] - rc_menu[DEF.BOX_LEFT];
		mh = rc_menu[DEF.BOX_BOTTOM] - rc_menu[DEF.BOX_TOP];
		var startx = halfWidth - (mw>>1);
		var starty = halfHeight - (mh>>1);
		backgroundHeight = mh - DGUI.INGAMEMENU_BACKGROUND_WH;
		backgroundTopPosY = starty + DGUI.INGAMEMENU_BACKGROUND_XY;
		if (CGame.bIsMiniMap) {
			this.DrawMiniMap();
		} else {
			this.gameDraw();
		}
			g.setColor(0);
//@#if WIDTH_320
//@			g.fillRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W-144, mh - DGUI.BACKGROUND_OFFSET_H);
//@#else
			g.fillRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W, mh - DGUI.BACKGROUND_OFFSET_H);
//@#endif
//			CGame.FillArgbRect(startx, starty + DGUI.INGAMEMENU_BACKGROUND_XY - 13, DEF.VIEW_W, mh - DGUI.BACKGROUND_OFFSET_H, 0x1f000000 | MENU_BACKGROUND_COLOR);
//@#endif // BREW_Alpha
			_menuIngame.PaintAFrame(g, DAnimID.MENU_INGAME_INGAMEMENU, 0, startx - rc_menu[DEF.BOX_LEFT], starty - rc_menu[DEF.BOX_TOP], 0);
	}
	var parentTitle = s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_PARENT];
	// Draw parent title
	var titleH = 0;
	var halfWidth = GLLibConfig.screenWidth / 2;	
	PARENT_TITLE_OFFSET_POS_Y = 80 * DScreen.RATIO;
	CGame.txtSetFont(fontSprBig);
	fontSpr.SetCurrentPalette(0);
		if (parentTitle > 0 || _enterintoTheHelpFromIGM) {
			CGame.txtDraw(0, Text_GetString(parentTitle), halfWidth, (CGame.bIsPaused ? 
//@#if TOUCH_SCREEN
					MENU_IGM_Y - DGUI.HELP_TITLE_OFFSET_Y
//@#else
//@	#if LG_KU970
//@					MENU_IGM_Y - 20
//@	#else
//@					MENU_IGM_Y
//@	#endif
//@#endif					
				: MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y), TOP | HCENTER);
		titleH += 0;
	} else if (CGame.bIsPaused) {
		titleH -= 20 * DScreen.RATIO;
	}
	this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
	this.drawSoftKeys();
	// draw the current help contents
	//CGame.DrawMultiLineText (Graphics g, var str, var x, var y, var align, var palette, var lineWidth, var startLine, var lineCount); 
	var align = 1;
	var lineWidth = DEF.VIEW_W - 130;
	var startLine = 0;
	var lineCount = 20;
	var lineInterval = 5;
	var posX = halfWidth;
	var posY = 100;
	
	var str="";
	var strCurrentItem;
//@#if TOUCH_SCREEN
	if (_currentPage_Help < 2)
		strCurrentItem = Text_GetString(TEXT.MENU_HELP_CONTROL_TOUCH + _currentPage_Help);
	else
		strCurrentItem = Text_GetString(TEXT.MENU_HELP_CONTROL + 1);
	switch (_currentPage_Help) {
		case 0:
		case 1:
			align = 1;
			lineWidth = DEF.VIEW_W - 40;
			posX = halfWidth;
			posY = DGUI.HELP_POSY;
			break;
			
		case 2:
				align = 4;
				lineInterval = 15;
				lineWidth = DEF.VIEW_W - 40;
				posX = halfWidth + 20 * DScreen.RATIO;
			posY = DGUI.HELP_POSY;
			
			break;			
		}
//@#else		
//@		strCurrentItem = Text_GetString(TEXT.MENU_HELP_CONTROL + _currentPage_Help);
//@		switch (_currentPage_Help) {
//@		case 0:
//@			align = 1;
//@			lineWidth = DEF.VIEW_W - 20;
//@			posX = halfWidth;
//@			posY = DGUI.HELP_POSY;
//@			break;
//@			
//@		case 1:
//@			align = 4;
//@			lineInterval = 15;
//@			lineWidth = DEF.VIEW_W - 40;
//@			posX = halfWidth + 20;
//@			posY = DGUI.HELP_POSY;
//@			
//@			break;
//@			
//@		case 2:
//@			align = 1;
//@			lineInterval = 5;
//@#if WIDTH_320
//@			lineWidth = DEF.VIEW_W - DGUI.INTERACE_TEXT_START_OFFSET_X - 140;
//@#else
//@			lineWidth = DEF.VIEW_W - DGUI.INTERACE_TEXT_START_OFFSET_X - 40;
//@#endif
//@			posX = halfWidth;
//@			posY = DGUI.HELP_POSY;
//@			break;
//@		}
//@#endif		

	for ( var i = 0; i < strCurrentItem.length; i++ ) {
		if (strCurrentItem.charAt(i) == '^') {
			str = str + "\n";
		}  else {
			str = str +  strCurrentItem.charAt(i);
		}
		
//			if (i < strCurrentItem.length - 1 && strCurrentItem.charAt(i+1) == ':' && _currentPage_Help == 1) {
//				str = str + "\n";
//			}
	}
		strCurrentItem = str;
		CGame.txtSetFont(fontSprSmall);
		_iconInHelpPosX = DGUI._ICONINHELP_POSX;
		CGame.DrawMultiLineText ( g, strCurrentItem, posX, posY, align, 2, lineWidth, startLine, lineCount, lineInterval); 
		
		
		if (CGame.spriteArray[DSpriteID.BONUS] == null) {
			Pack_Open(DATA.PACK_SPRITE);
			CGame.spriteLoad(DSpriteID.BONUS, DATA.SPRITE_BONUS, true, true);
			Pack_Close();
		}
//		var iconPosX = DGUI.ICONPOSX;
//		var iconPosY = 172;
//@#if TOUCH_SCREEN
	if (_currentPage_Help == 2)
//@#else		
//@		if (_currentPage_Help == 1)
//@#endif			
	{
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_CRYSTAL, 
															s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_CRYSTAL), 
															_iconInHelpPosX, _eachLinePosY[0]+DGUI.ICON_OFFSETY1, 0);
			
//			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_1UP, 
//					s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_1UP), 
//					DGUI.ICONPOSX + 180, iconPosY, 0);
			
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_CRYSTAL_FLOWER, 
					s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_CRYSTAL_FLOWER), 
					_iconInHelpPosX, _eachLinePosY[1]+DGUI.ICON_OFFSETY2, 0);

//			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_CRYSTAL, 
//					s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_CRYSTAL), 
//					DGUI.ICONPOSX + 180, iconPosY+45, 0);
			
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_1UP, 
					s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_1UP), 
					_iconInHelpPosX, _eachLinePosY[2]+DGUI.ICON_OFFSETY2, 8);
			
	
		}
		
	var _keycode = WasAnyKeyReleased();
	if (_keycode >= 0){
		switch (_keycode) {			
			case GLKey.k_menuBack:
				if (currentMenuDepth > 0 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT] != -1)
				{
					currentMenuDepth--;
					s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
					CGame.txtSetFont(fontSprBig);
					_currentPage_Help = 0;

				}
				break;
				
			case GLKey.k_menuOK:
				_currentPage_Help =(++_currentPage_Help) % 3;	
				break;
		}
		if (CGame.isAnyPointPressed()) // fix bug don't release key.
		{
			CGame.UpdateKeyState();
			ResetKey();
		}
	}
}
//@#if LG_KU970
//@	var _aboutPageCurrentPos_Y = DEF.VIEW_H>>2;
//@#else
var _aboutPageCurrentPos_Y =  0;
//@#endif
var _aboutPageCurrentLine = 0;
var _aboutPageString;
//@#if BREW_STATIC_ABOUT_1
//@	static var s_brewAboutStr = null;
//@#endif // BREW_STATIC_ABOUT_1
//@#if LG_KU970
//@		var gameRepavar = true;
//@#endif
CGame.prototype.UpdateGameState_MENU_ABOUT = function()// throws Exception
{
//@#if LG_KU970
//@		var titleH = 0;
//@		var halfWidth = GLLibConfig.screenWidth / 2;
//@		var parentTitle = s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_PARENT];
//@		if (parentTitle > 0 && !CGame.bIsPaused) {
//@			titleH += 30;
//@		} else if (CGame.bIsPaused) {
//@			titleH -= 20;
//@		}
//@		
//@		if(gameRepavar){
//@			g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
//@		}
//@		else{
//@			g.setClip(0, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)+30, DEF.VIEW_W, DEF.VIEW_H-(CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)-55);
//@		}
//@		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2, DEF.SCR_H_D2, 0);
//@		
//@		// Draw parent title
//@
//@		
//@		if (parentTitle > 0 && !CGame.bIsPaused && gameRepavar) {
//@			CGame.txtSetFont(fontSprBig);
//@			fontSpr.SetCurrentPalette(0);
//@			CGame.txtDraw(0, Text_GetString(parentTitle), halfWidth, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y), TOP | HCENTER);
//@		}
//@		if(gameRepavar){
//@			this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
//@			this.drawSoftKeys();
//@		}
//@#else
		_splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
	var parentTitle = s_menuFlow[currentMenu[currentMenuDepth]][MENU.TITLE_AS_PARENT];
	// Draw parent title
	var titleH = 0;
	var halfWidth = GLLibConfig.screenWidth / 2;
	
	if (parentTitle > 0 && !CGame.bIsPaused) {
		CGame.txtSetFont(fontSprBig);
		fontSpr.SetCurrentPalette(0);
		CGame.txtDraw(0, Text_GetString(parentTitle), halfWidth, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y), TOP | HCENTER);
		titleH += 30;
	} else if (CGame.bIsPaused) {
		titleH -= 20;
	}
	this.setSoftKeys(s_menuFlow[currentMenu[currentMenuDepth]][MENU.LSK_TEXT], s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT]);
	this.drawSoftKeys();
//@#endif
	//draw the contents of about
	var lineWidth = DEF.VIEW_W - 0;
	var posX = halfWidth;
//@#if LG_KU970
//@		g.setClip(0, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)+30, DEF.VIEW_W, DEF.VIEW_H-(CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)-55);
//@#else		
	g.setClip(0, (CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)+25 * DScreen.RATIO, DEF.VIEW_W, DEF.VIEW_H-(CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)-45* DScreen.RATIO);
//@#endif
		if (_aboutPageString == null) {
		var str = Text_GetString(TEXT.MENU_ABOUT_1);
		var index;
		if ((index = str.indexOf("X.X.X")) >= 0)
			str = str.substring(0, index)
				+ GloftCAOF._midletInstance.getAppProperty("MIDlet-Version") 
				+ str.substring(index + 5);
		_aboutPageString = str;
	}

	if (_aboutPageString.indexOf('^') > -1) {
		_aboutPageString = _aboutPageString.replace('^', '\n');
	}
	
	CGame.txtSetFont(fontSprSmall);
	var lineInterval = 5;
	var textAreaHeight = (DEF.VIEW_H-(CGame.bIsPaused ? MENU_IGM_Y : MENU_MAIN_Y - PARENT_TITLE_OFFSET_POS_Y)-40);
		textAreaHeight += (lineInterval + fontSprSmall.GetLineHeight()) * 2;
	var linesNumPerPage = textAreaHeight / (lineInterval + fontSprSmall.GetLineHeight());
	var currentPosY = Math_FixedPointToInt(_aboutPageCurrentPos_Y); 
	var over = CGame.DrawMultiLineText ( g, _aboutPageString, posX, DEF.VIEW_H - currentPosY, 
							GRPH.HCENTER, 2, lineWidth, _aboutPageCurrentLine, linesNumPerPage, lineInterval); 
	
		if (over && _aboutPageCurrentPos_Y > Math_IntToFixedPoint(textAreaHeight) * 2) {
//@#if LG_KU970
//@			_aboutPageCurrentPos_Y = DEF.VIEW_H>>2;
//@#else
		_aboutPageCurrentPos_Y = 0;
//@#endif
		_aboutPageCurrentLine = 0;
		currentPosY = 0;			
	}
		_aboutPageCurrentPos_Y += Math_IntToFixedPoint(DGUI.INTERFACE_ROLL_SPEED) * CGame._frameDT_Real / DEF.VELOCITY_FRAME_TICK;

		if (!over) {
			if (_aboutPageCurrentPos_Y > Math_IntToFixedPoint(textAreaHeight)) {
				_aboutPageCurrentLine++;
				_aboutPageCurrentPos_Y -= Math_IntToFixedPoint(lineInterval + fontSprSmall.GetLineHeight());
			}
	}
	var _keycode = WasAnyKeyReleased();
	if (_keycode >= 0){
		switch (_keycode) {			
		case GLKey.k_menuBack:
			if (currentMenuDepth > 0 && s_menuFlow[currentMenu[currentMenuDepth]][MENU.RSK_TEXT] != -1)
				{
					_aboutPageString = null;
					currentMenuDepth--;
					s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
					CGame.txtSetFont(fontSprBig);
//@#if LG_KU970
//@					_aboutPageCurrentPos_Y = DEF.VIEW_H>>2;
//@#else
				_aboutPageCurrentPos_Y = 0;
				_aboutPageCurrentLine = 0;
//@#endif
				CGame.PlaySoundBGM();
			}
			break;
			
		case GLKey.k_menuOK:
			
			break;
		}
	}
	g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
//@#if LG_KU970
//@		gameRepavar = false;
//@#endif
}

//=====================================
//========== Update TnB Menu ==========
//=====================================
//A.W: Add Update Tnb Menu
// CGame.prototype.UpdateGameState_POPUP_TNB_DEMO() {
	// if (!_enterintoTheHelpFromIGM){
		// _splash.PaintAFrame(g, 1, 0, DEF.SCR_W_D2 - DGUI.SPLASH_OFFSET_X, DEF.SCR_H_D2, 0);
	// } else {
		// var halfWidth = GLLibConfig.screenWidth / 2;
		// var halfHeight = GLLibConfig.screenHeight / 2;
	// }
// }


//@#if BREW_IGP
//@	native var updateIGP();
//@	native var updateIGP_IsNew();
//@#endif // BREW_IGP

CGame.prototype.UpdateGameState_IGP = function()// throws Exception
{
	if (DEF.dbgEnable) Dbg("-------------------------- launch IGP ...");
	var param = "";
	if(window.location.toString().split("?").length > 1)
		param = window.location.toString().split("?")[1];
	window.open("/?" + param, "_self");
//@#if BREW_IGP
//@		 if(!updateIGP())
//@		 {
//@			currentHeadIndex = 0;
//@			_menuStartOffsetPos_Y = 0;
//@			_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
//@			_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
//@			s_game_state = STATE.MENU_INIT;
//@		 }
//@#else // BREW_IGP
	/* var igpAction = IGP.ACTION_NONE;
	for (var i = 0 ; i != keyToIGPMap.length ; i++)
	{
		if(IsKeyDown(i))
		{
			igpAction = keyToIGPMap[i];
			if (IsKeyDown(GLKey.k_menuBack))
			{
				currentHeadIndex = 0;
				_menuStartOffsetPos_Y = 0;
				_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
				_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
				s_game_state = STATE.MENU_INIT;
				IGP.update( IGP.ACTION_BACK ); // must update IGP twice to release all resouce
			}

			ResetAKey(i);
		}
	} */
//@#if not TOUCH_SCREEN		
//@		IGP.update( igpAction );
//@#else		
	/* if (IGP.update( igpAction ))
	{
		currentHeadIndex = 0;
		_menuStartOffsetPos_Y = 0;
		_currentOptionHead = currentEachOptionIndex[currentHeadIndex];
		_currentOptionTail = currentEachOptionIndex[currentHeadIndex+4];
		s_game_state = STATE.MENU_INIT;
	} */
//@#endif		
		// IGP.paint(g);
//@#endif // BREW_IGP

//		//TODO: support softkey inversion
//		if (IsKeyDown(GLKey.k_menuOK))
//		{
//			igpAction = IGP.ACTION_SELECT;
//			ResetAKey(GLKey.k_fire);
//			ResetAKey(GLKey.k_menuOK);
//		}
//		else if (IsKeyDown(GLKey.k_menuBack))
//		{
//			igpAction = IGP.ACTION_BACK;
//			ResetAKey(GLKey.k_menuBack);
//		}
//
//		IGP.paintIGP( g );
//		boolean exit = IGP.updateIGP( igpAction );
//		if ( exit )
//		{
//			CGame.initMenus();
//			s_game_state = STATE.MENU_INIT;
//			return;
//		}
}

CGame.prototype.UpdateGameState_END_GAME_IGP = function() //throws Exception
{
	g.setColor(0);
	g.fillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	// CGame.txtDraw(0, Text_GetString(TEXT.LIKEGAME), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight / 2, BOTTOM | HCENTER);
	var lineInterval = 15;
	CGame.DrawMultiLineText(g, Text_GetString(TEXT.MENU_LIKEGAME), GLLibConfig.screenWidth / 2, GLLibConfig.screenHeight / 3, TOP | HCENTER, 1, GLLibConfig.screenWidth , 0, 10, lineInterval);
	this.setSoftKeys(TEXT.MENU_SK_YES, SOFTKEY_NONE);
	this.drawSoftKeys();
	
	var _keycode = WasAnyKeyReleased();
	if (_keycode >= 0){
		switch (_keycode) {							
		case GLKey.k_menuOK:
//@			    #if NO_LOADING_STR_WHEN_GET_INTO_IGP
//@				IGP.enterIGP( "", 0 );
//@				#else
			// IGP.enterIGP( "", 0 );
//@				#endif
			s_game_state = STATE.IGP;
			break;
		}
	}
}

CGame.prototype.UpdateGameState_MENU_GET_MORE_GAMES_INIT = function()// throws Exception
{
	// map language between app and IGP
	/*var igpLanguage = 0;
	switch(CGame.curLanguage)
	{
		case GLLang.EN:
			igpLanguage = 0;
		break;
		case GLLang.DE:
			igpLanguage = 1;
		break;
		case GLLang.FR:
			igpLanguage = 2;
		break;
		case GLLang.IT:
			igpLanguage = 3;
		break;
		case GLLang.ES:
			igpLanguage = 4;
		break;
		case GLLang.BR:
			igpLanguage = 5;
		break;
		case GLLang.PT:
			igpLanguage = 6;
		break;
		case GLLang.JP:
		case GLLang.CN:
		case GLLang.KR:
			// these languages are not supported in multilanguage IGP, so igpLanguage = 0 is ok
		break;
	}*/

	// First parameter: var correponding to your game's selected language loading message
	// Second parameter:
	// - only if you have IGP_MULTILANGUAGE=true in igp_config.bat
	// provide index of desired language:
	// IGP_LANGUAGE_EN, IGP_LANGUAGE_DE, IGP_LANGUAGE_FR, IGP_LANGUAGE_IT, IGP_LANGUAGE_SP, IGP_LANGUAGE_PT
	// from IGP_SETTINGS.h ( you may have to #include IGP_SETTINGS.h at the begining of your java file )
	// - otherwise, the second parameter is ignored, and the module loads the default language
//@#if not BREW_IGP
//@        #if NO_LOADING_STR_WHEN_GET_INTO_IGP
//@		IGP.enterIGP( "", igpLanguage );
//@		#else
	// IGP.enterIGP( "", igpLanguage );
//@		#endif
//@#endif // BREW_IGP
	s_game_state = STATE.IGP;
}

CGame.prototype.UpdateGameState_MENU_MAIN = function() //throws Exception
{
	CGame._miniMapCursorAtPoint = -1;
	currentSplash = 2;
	if(DEF.dbgEnableCheat) {
		if((this.useCheatCode() == s_game_state) || DEF.dbgUnlockLevel || DEF.dbgUnlockLevelButCastle) {
			var len = CGame._levelInfo.length;
			if(DEF.dbgUnlockLevelButCastle) {
				len = DAI.LEVEL_ID_CASTLE;
			}
			for (var i=0; i < len; i++)
			{
				CGame._levelInfo[i] = 1;
			}
		}
	}

	switch(this.updateMenu())
	{
		case STATE.MENU_GET_MORE_GAMES:
		{
			s_game_state = STATE.MENU_GET_MORE_GAMES_INIT;
		}
		break;
	}
}

CGame.prototype.UpdateGameState_MENU_INGAME_MAIN_MENU = function() //throws Exception
{
	switch(this.updateMenu())
	{
		case STATE.YES:
			CGame.RMS_Load();
			this.GotoMainMenu();
			break;
		case STATE.NO:
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			break;
	}
}

CGame.prototype.UpdateGameState_BACK_TO_MINIMAP = function() //throws Exception
{
	switch(this.updateMenu())
	{
		case STATE.YES:
			CGame.RMS_Load();
			CGame.bIsPaused = false;
			s_game_state = STATE.LOAD_UNLOAD;
			CGame.loadingPhase = -DLoadState.LOAD_OVER;
			CGame.s_next_game_state_after_unload = STATE.MENU_MAP;
			break;
		case STATE.NO:
			currentMenuDepth -= 2;
			s_game_state = s_menuFlow[currentMenu[currentMenuDepth]][MENU.STATE];
			break;
	}
}

CGame.GotoRestart = function( heroDie) {
	CGame.bIsPaused = false;
	try {
		CGame.LoadUnload(DLoadState.UNLOAD_SEGMENT);
		CGame.LoadUnload(DLoadState.UNLOAD_ENTITY);
	} catch ( ex) {
		if (DEF.dbgEnable) Dbg("GotoRestart LoadUnload----------------------- error : " + ex.message);
		//ex.printStackTrace();
	}
	CGame.ReleaseLevel(heroDie);
	try {
		CGame.InitLevel();
			Pack_Open("/" + /* Integer.toString */((DATA.PACK_LEVEL01_1.charAt(1) - '0') + CGame._tempLevelId));
		var topLayer = GLLibConfig.tileset_maxLayerCount - 1;
		GLLibPlayer.Tileset_Destroy(topLayer);
		
		var mapsize;
		var mapdata = null;
		var mapflip = null;
		var tiled = CGame.level2Tiled(CGame._tempLevelId, topLayer);
		var dataOffset = DATA.LEVEL01_1_TOP_SIZE;
		mapsize = Pack_ReadData(dataOffset++);
		mapdata = Pack_ReadData(dataOffset++);
		mapflip = Pack_ReadData(dataOffset++);
		GLLibPlayer.Tileset_LoadLayer(topLayer,
				mapsize,
				mapdata,
				mapflip,
				CGame.spriteArray[tiled + DSpriteID.TILESET_BASE],
				false,
				/*GLLib.*/TOP, // set origin on top left
				GLLibPlayer.WRAP_CLAMP, GLLibPlayer.WRAP_CLAMP);
		GLLibPlayer.Tileset_SetCamera(topLayer, 0, 0);
		CGame._topLayerData = mapdata;
		CGame._topLayerFlip = mapflip;
		CGame.LoadUnload(DLoadState.LOAD_ENTITY);
		CGame.LoadUnload(DLoadState.LOAD_SEGMENT);
		Pack_Close();
	} catch ( ex) {
			//ex.printStackTrace();
		if (DEF.dbgEnable) Dbg("GotoRestart ----------------------- error : " + ex.message);
	}
	
	CGame.GotoInitLevel(heroDie);
}
CGame.GotoInitLevel = function ( heroDie) {
		CGame.LoadCheckPoint();
	CEntity.CheckActive();
	CEntity.UpdateAll(-1);
	if (heroDie) {
		CEntity._hero._hp = CEntity._heroHpBeforeDie;//CEntity._hero._heroHpBeforeDie;
	} else {

		CEntity._hero._hp = CGame._playerInfo[DAI.HPI_HP_MAX];
		CEntity._HeroParams[DAI.HPI_LIVES] = CGame._playerInfo[DAI.HPI_LIVES];
//@#if Use_Motion_Sensor
//@			CEntity._HeroParams[DAI.HPI_SHAKE] = CGame._playerInfo[DAI.HPI_SHAKE];
//@			CEntity._HeroParams[DAI.HPI_ROCK] = CGame._playerInfo[DAI.HPI_ROCK];
//@#endif
		// try {
			CGame.RMS_Load();
		// } catch ( e) {
			// TODO Auto-generated catch block
				//e.printStackTrace();
		// }
	}
	CEntity._HeroParams[DAI.HPI_CRYSTAL_COUNT] = CEntity._hero._hp;
	//CEntity.InitAIAll(-1);
	CGame.redrawAll = true;
	s_game_state = STATE.GAMEPLAY_UPDATE;
//@#if not BREW_GlobalSplash
	// _splash = null;
	if (_splash != null)
	{
		if (DEF.dbgEnable) Dbg("spriteUnLoad : ******************* -----_splash");
		_splash.FreeCacheData();
		_splash.FreeCachedFrames();
		_splash.FreeCachedModules();
		_splash = null;
	}
//@#endif // BREW_GlobalSplash
	_map = null;

//@#if not SupportNokiaAPI
	m_menuPanelGreyBar = null;
//@#if BREW_Alpha
//@//		m_menuPanelGreyBar_brewAlphaData = null;
//@#endif // BREW_Alpha
//@#endif //SupportNokiaAPI
	CGame.PlaySoundBGM();
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@		initCurrentBubbleTextPos(false);
//@#endif
}

CGame.needTrans = false;

CGame.GotoNextLevel = function( SaveLevelInfo) {
	CGame.bIsPaused = false;
		CGame._checkPointData = null;
	s_game_state = STATE.LOAD_UNLOAD;
	CGame.loadingPhase = -DLoadState.LOAD_OVER;
	if (CGame.needTrans) {
		CGame.s_next_game_state_after_unload = STATE.LOAD_UNLOAD;
		CGame.initMenus();
	}
	else {
			CGame.s_next_game_state_after_unload = STATE.MENU_MAP;
		}
		if (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME) {
			CGame._tempLevelId = 0;
			CGame.s_next_game_state_after_unload = STATE.MENU_MAP;
		} else {
			if (!CGame.needTrans && CGame._tempLevelId == DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
				CGame._tempLevelId = DAI.LEVEL_ID_INTRO_THE_END;
				CGame.s_next_game_state_after_unload = STATE.LOAD_UNLOAD;
				CGame.initMenus();
			} else if (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END) {
				CGame.initMenus();
				CGame.s_next_game_state_after_unload = STATE.GAMEEND;
				currentMenu[++currentMenuDepth] = MENU_THE_END_INDEX;
			} else if (SaveLevelInfo && (CGame._tempLevelId + 1 < RMS.LEVEL_INFO_NUM)) {
				CGame._levelInfo[CGame._tempLevelId+1] = 1;
			}
		}

	if (CGame.needTrans) {
		var i = 0;
		while (CEntity._miniGameTriger != null && true) {
			if ((CEntity._miniGameTriger._params[DParamIndex.TRIGGER_TRANSPORT_WORLD] >> i) == 1)
				break;
			i++;
		}

		if (CEntity._miniGameTriger != null) {
			CGame._worldId = i - 1;
			CGame._tempLevelId = CGame._worldId * DAI.LEVELS_NUM_PRE_WORLD + CEntity._miniGameTriger._params[DParamIndex.TRIGGER_TRANSPORT_LEVEL];
		}
	}
	CGame.needTrans = false;
	CGame.RMS_Save();
}
CGame.prototype.GotoMainMenu = function() {
//@#if RELEASE_BACKTOMAINMENU
//@		CGame.ReleaseLevel(false);
//@#endif
	Dbg("*** GotoMainMenu");
	CGame.bIsMainMain = true;
	CGame.bIsPaused = false;
	s_game_state = STATE.LOAD_UNLOAD;
	CGame.loadingPhase = -DLoadState.LOAD_OVER;
	CGame.s_next_game_state_after_unload = STATE.MENU_INIT;
	CGame.initMenus();
	CGame.PlaySound(DSound_Channel.BGM, DATA.SOUND_BGM_MAIN_MENU);
}

// if   i_is_igp_actived   is true,  enter end game igp after finish the game
CGame.GotoEndGameIGP = function() {
	CGame.bIsPaused = false;
	s_game_state = STATE.LOAD_UNLOAD;
	CGame.loadingPhase = -DLoadState.LOAD_OVER;
	CGame.s_next_game_state_after_unload = STATE.END_GAME_IGP;
}


CGame.prototype.UpdateGameState_GAMEPLAY_UPDATE = function() //throws Exception
{
	Dbg("*** [AW] ssssssssssssssss");
// try {
		if (s_game_interruptNotify) {
			CGame.initIngameMenu(STATE.MENU_INGAME);
			return;
	}
	DTimer.resetAll();
	DTimer.startTimer(DTimer.INDEX_AI);
	this.gameUpdate();
	if (s_game_state == STATE.GAMEPLAY_UPDATE) {
			DTimer.endTimer(DTimer.INDEX_AI);
			DTimer.startTimer(DTimer.INDEX_DRAW);
			this.gameDraw();
//@#if not RemoveInterface
			if (!CGame.InCinemitic()) {
	
				this.DrawInterface();
				if (this.GetLevelTextByLevelId(CGame._tempLevelId) != TEXT.MENU_SELECT_WORLD) {
				if( CGame._specialEffectStep <= CGame.EFFECT_OVER) { 
					var posX = DEF.VIEW_W_D2;
					var posY = 120 * DScreen.RATIO;
						this.DrawIntroAnimation( Text_GetString(this.GetLevelTextByLevelId(CGame._tempLevelId)), posX, posY, 0);
				}
			}
		} else {
//@#if not UseCommandBar
			fontSprBig.SetCurrentPalette(0);
			fontSprBig.DrawString(g, Text_GetString(TEXT.MENU_SK_SKIP), DEF.VIEW_W, DEF.VIEW_H, GRPH.RIGHT_BOTTOM);
//@#endif			
		}
		if (!CGame.bIsPaused) {
//@#if UseCommandBar
//@			this.setSoftKeys(TEXT.INIT_SK_MENU, (CGame.InCinemitic()?TEXT.MENU_SK_SKIP:SOFTKEY_NONE));
//@			this.drawSoftKeys();
//@#else			
				CGame._interface.PaintAFrame(	g,
						DAnimID.INTERFACE_IGM,
						s_game_currentFrameNB % CGame.spriteArray[DSpriteID.INTERFACE].GetAFrames(DAnimID.INTERFACE_IGM),
						DGUI.INTERFACE_IGM_OFFSET_X, DEF.VIEW_H - DGUI.INTERFACE_LEFTSOFTKEY_OFFSET_Y, 0);
//@#endif			
		}
//@#endif
		///////////////////
		this.DrawWeatherEffect();
		this.DrawFadeEffect();
		DTimer.endTimer(DTimer.INDEX_DRAW);
		DTimer.drawTimers(g);
		if (_gameRestart) {
			CGame.drawTheCurtainOpen();
		}
	}
// } catch (ex) {
		// Dbg("UpdateGameState_GAMEPLAY_UPDATE() -------------- error : " + ex.message);
		//ex.printStackTrace();
// }
}


CGame._firstEnterIntoThisFunction = true;
CGame._specialEffectStep = 0;
CGame.EFFECT_DOWNING_INTO_SCREEN = 0;
CGame.EFFECT_FLOWING_OUTOF_SCREEN = 1;
CGame.EFFECT_OVER = 2;
CGame._explode_step = 0;
CGame._lastFrameNB  = 0;
var initialPosForChars = null;
CGame._stringFrameLength = 0;
/*
 * draw an varroduce at the beginning of each level
 * step 1: draw the current level title in a special effect way
 * step 2: draw the "GO" down from the sky
 * step 3: explod the title once it was collided with the "GO"
 * step 4: clear and over
 */

CGame.prototype.DrawIntroAnimation = function( levelName, posX, posY, anchor )
{
	CGame.textChars = levelName.split('');//levelName.toCharArray();
	var palette = 0;
	switch ( CGame._specialEffectStep ) 
	{
		case CGame.EFFECT_DOWNING_INTO_SCREEN: 			
		var over = CGame.txtDrawSpecialEffectFlowFromTheSky(palette, levelName, posX, posY, anchor); 
		if (over) {
			CGame._lastFrameNB = /*GLLib.*/s_game_currentFrameNB;
			CGame._specialEffectStep++;
		}
		break;
		
	case CGame.EFFECT_FLOWING_OUTOF_SCREEN:
		if (/*GLLib.*/s_game_currentFrameNB - CGame._lastFrameNB > 20) {
			CGame._currentPosX-=20;
		}
		CGame.txtDrawSpecialEffectFlowFromTheSky(palette, levelName, posX + CGame._currentPosX, posY, anchor); 
		if (CGame._currentPosX < -240) {
			CGame._specialEffectStep++;
		}
		break;
		
	case CGame.EFFECT_OVER:
		CGame._specialEffectStep++;
		CGame._explode_step = 0;
		CGame._currentPosX = 0;
		CGame._currentPosY = 0;
		break;
	default:
		//CGame._specialEffectStep = 0;			
	}	
}



CGame.prototype.UpdateGameState_K_MRC_INIT = function() //throws Exception
{
	if (Build.useCGMRC)
	{
		s_License = new License(s_application);

		//cheat
		if (s_License.isLicenseValid())
		{
			//License is valid, start the game normally
			s_game_state = CGame.s_next_state;
			if (DEF.dbgEnable) Dbg("VALID");
		}
		else
		{
			s_License.sendValidateLicense();
			s_game_state = STATE.K_MRC_VALIDATING;
			if (DEF.dbgEnable) Dbg("go to VALIDATING");
		}
	}
}
CGame.prototype.UpdateGameState_K_MRC_VALIDATING = function() //throws Exception
{
	if (Build.useCGMRC)
	{
		SetClip(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		SetColor(0x000000);
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);

		var	_warp = fontSpr.WraptextB(Text_GetString(TEXT.INIT_MRC_VALIDATING), GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		fontSpr.DrawPageB(	g, Text_GetString(TEXT.INIT_MRC_VALIDATING), _warp, GLLibConfig.screenWidth>>1,
							(GLLibConfig.screenHeight>>1), 0, 10, Graphics.HCENTER|Graphics.VCENTER);

		if(GLLibConfig.softkeyOKOnLeft)
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
					1, GLLibConfig.screenHeight-1,
					Graphics.BOTTOM | Graphics.LEFT);
		}
		else
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
				GLLibConfig.screenWidth - 1, GLLibConfig.screenHeight - 1,
				Graphics.BOTTOM | Graphics.RIGHT);
		}

		if(WasKeyPressed(GLKey.k_menuBack) )
		{
		   if (DEF.dbgEnable) Dbg("k_mrc_validating MENU_CANCEL");

			s_License.cleanup();
			s_License = null;
			s_game_state = STATE.QUIT;
		}
		else if (s_License.handleValidateLicense() == true)
		{
			if (DEF.dbgEnable) Dbg("k_mrc_validating handleValidateLicense");

			var _errCode = s_License.getLastError();
			if (DEF.dbgEnable) Dbg(""+_errCode);
			s_License.cleanup();

			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					if (s_License.isLicenseValid())
					{
						s_game_state = CGame.s_next_state;
					}
					else
					{
						s_game_state = STATE.K_MRC_EXPIRED;
					}
					break;

				case XPlayer.Error.ERROR_CONNECTION:
					s_game_state = STATE.K_MRC_NETWORK_FAILED;
					break;

				default:
					if (DEF.dbgEnable) Dbg("UNKNOWN MRC ERROR : " + _errCode);
					s_game_state = STATE.QUIT;
					break;
			}
		}
	}
}

CGame.prototype.UpdateGameState_K_MRC_EXPIRED = function() //throws Exception
{
	if (Build.useCGMRC)
	{
		SetClip(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		SetColor(0x000000);
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);

		var	_warp = fontSpr.WraptextB(Text_GetString(TEXT.INIT_MRC_EXPIRED), GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		fontSpr.DrawPageB(	g, Text_GetString(TEXT.INIT_MRC_EXPIRED), _warp, GLLibConfig.screenWidth>>1,
							(GLLibConfig.screenHeight>>1), 0, 10, Graphics.HCENTER|Graphics.VCENTER);

		if(GLLibConfig.softkeyOKOnLeft)
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
					1, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.LEFT);
		}
		else
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
					GLLibConfig.screenWidth, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.RIGHT);
		}

		if( WasKeyPressed(GLKey.k_menuBack))
		{
			s_game_state = STATE.QUIT;
		}
	}
}

CGame.prototype.UpdateGameState_K_MRC_NETWORK_FAILED = function() //throws Exception
{
	if (Build.useCGMRC)
	{
		SetClip(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		SetColor(0x000000);
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);

		var	_warp = fontSpr.WraptextB(	Text_GetString(TEXT.INIT_MRC_NETWORK_FAILED),
				GLLibConfig.screenWidth, GLLibConfig.screenHeight);
		fontSpr.DrawPageB(g, Text_GetString(TEXT.INIT_MRC_NETWORK_FAILED), _warp,
							(GLLibConfig.screenWidth>>1), (GLLibConfig.screenHeight>>1), 0, 10,
							Graphics.HCENTER|Graphics.VCENTER);

		if(GLLibConfig.softkeyOKOnLeft)
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_RETRY),
					GLLibConfig.screenWidth, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.RIGHT);

			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
					1, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.LEFT);
		}
		else
		{
			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_RETRY),
					 1, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.LEFT);

			CGame.txtDraw(0,Text_GetString(TEXT.INIT_MRC_EXIT),
					GLLibConfig.screenWidth, GLLibConfig.screenHeight - 1,
					Graphics.BOTTOM | Graphics.RIGHT);
		}

		if( WasKeyPressed(GLKey.k_menuBack))
		{
			s_game_state = STATE.QUIT;
		}
		else if( WasKeyPressed(GLKey.k_menuOK))
		{
			s_game_state = STATE.K_MRC_INIT;
		}
	}
}

	// Recordstore name
//@#if not Shrink600K
//@	static String				RMS_NAME = "COMSAV";
//@#else
var RMS_NAME = "SCOMSAV";
//@#endif

// -----------------------------------------------------------------------------------------------------------------------------------------
// RMS

// RMS enumerator
// RMS = {};
// {
// 	RMS.LANGUAGE   = 0;
// 	RMS.SOUND_ENABLED 	 	= RMS.LANGUAGE + 1;
// 	RMS.SOUND_LEVEL	 	 	= RMS.SOUND_ENABLED + 1;
// 	RMS.GAME_PROGRESS          = RMS.SOUND_LEVEL + 1;
// 	RMS.LEVEL_INDEX            = RMS.GAME_PROGRESS + 1;
// 	RMS.LEVEL_INFO_STRAT       = RMS.LEVEL_INDEX + 1;
// 	RMS.LEVEL_INFO_NUM         = 28;
// 	RMS.LEVEL_INFO1      = RMS.LEVEL_INFO_STRAT + RMS.LEVEL_INFO_NUM;
// 	RMS.LEVEL_INFO2      = RMS.LEVEL_INFO1 + 1;
// 	RMS.PLAYER_INFO_STRAT      = RMS.LEVEL_INFO2 + 1;
// //@#if not Use_Motion_Sensor
// 	RMS.PLAYER_INFO_NUM        = 5;
// //@#else
// //@		var PLAYER_INFO_NUM        = 7;
// //@#endif
// 	RMS.LEVEL_STAR_INFO_START  = RMS.PLAYER_INFO_STRAT + RMS.PLAYER_INFO_NUM;
// 	RMS.LEVEL_STAR_INFO_NUM    = DAI.LEVELS_NUM_MAX * DAI.STAR_INFO_SIZE;
// 	RMS.LEVEL_TOTAL_SCORE_START= RMS.LEVEL_STAR_INFO_START + RMS.LEVEL_STAR_INFO_NUM * 2;
// 	RMS.LEVEL_TOTAL_SCORE_NUM  = DAI.LEVELS_NUM_MAX;
// 	RMS.SIZE       			= RMS.LEVEL_TOTAL_SCORE_START + RMS.LEVEL_TOTAL_SCORE_NUM * 4;
// };

// Save game state variables to the RMS
CGame.RMS_Save = function()
{
//		if (true) {
//			return;
//		}
	// try
	// {
		if (DEF.dbgEnable) Dbg("Saving RMS...");
		var data = LowAPI.Gen_Array([RMS.SIZE],0);//new byte[RMS.SIZE];
		data[RMS.LANGUAGE] = CGame.curLanguage;
		data[RMS.SOUND_ENABLED] = (CGame.isSoundEnabled ? 1 : 0);
		//data[RMS.SOUND_LEVEL] = GLLibPlayer.s_snd_masterVolume;
		data[RMS.GAME_PROGRESS] = CGame._gameProgress;
		data[RMS.LEVEL_INDEX] = CGame._levelId;
		data[RMS.LEVEL_INFO_STRAT] = 1;
		for (var i=1; i < RMS.LEVEL_INFO_NUM; i++)
		{
			data[RMS.LEVEL_INFO_STRAT+i] = CGame._levelInfo[i];
		}
		data[RMS.LEVEL_FINAL_INFO1] = CGame._levelFinalInfo1;
		data[RMS.LEVEL_FINAL_INFO2] = CGame._levelFinalInfo2;
		for (var i=0; i < RMS.PLAYER_INFO_NUM; i++)
		{
			data[RMS.PLAYER_INFO_STRAT+i] = CGame._playerInfo[i];
		}
		var offset = RMS.LEVEL_STAR_INFO_START;
		for (var i = 0; i < RMS.LEVEL_STAR_INFO_NUM; i++) {
			Mem_SetShort(data, offset, CGame._levelStarInfo[i]);
			offset += 2;
		}

		offset = RMS.LEVEL_TOTAL_SCORE_START;
		for (var i = 0; i < RMS.LEVEL_TOTAL_SCORE_NUM; i++) {
				Mem_SetInt(data, offset, CGame._levelTotalScore[i]);
			offset += 4;
		}
		Rms_Write(RMS_NAME, data);
	// } catch ( ex) {
			//ex.printStackTrace();
	// }
}

// Load game state variables from the RMS
CGame.RMS_Load = function() //throws Exception
{
//		if (true) {
//			return;
//		}
	if (DEF.dbgEnable) Dbg("Loading RMS...");
	// try {
		var data = Rms_Read(RMS_NAME);

		if(data == null || data.length == 0)
		{
			// If the RMS doesn't exist yet, call RMS initialization and create a new one.
			CGame.RMS_Init();
			CGame.isSoundEnabled = true;
			CGame.RMS_Save();
		}
		else
		{
			CGame.curLanguage = data[RMS.LANGUAGE];
			CGame.isSoundEnabled = data[RMS.SOUND_ENABLED] == 1;
			//GLLibPlayer.Snd_SetMasterVolume(data[RMS.SOUND_LEVEL]);
			CGame._gameProgress = data[RMS.GAME_PROGRESS];
			CGame._levelId = (data[RMS.LEVEL_INDEX] == 255) ? -1:data[RMS.LEVEL_INDEX];
			for (var i=0; i < RMS.LEVEL_INFO_NUM; i++)
			{
				CGame._levelInfo[i] = data[RMS.LEVEL_INFO_STRAT+i];
			}
				CGame._levelFinalInfo1 = data[RMS.LEVEL_FINAL_INFO1];
				CGame._levelFinalInfo2 = data[RMS.LEVEL_FINAL_INFO2];
			for (var i=0; i < RMS.PLAYER_INFO_NUM; i++)
			{
				CGame._playerInfo[i] = data[RMS.PLAYER_INFO_STRAT+i];
			}
			var offset = RMS.LEVEL_STAR_INFO_START;
			for (var i = 0; i < RMS.LEVEL_STAR_INFO_NUM; i++) {
				CGame._levelStarInfo[i] = Mem_GetShort(data, offset);
				offset += 2;
			}
			offset = RMS.LEVEL_TOTAL_SCORE_START;
			for (var i = 0; i < RMS.LEVEL_TOTAL_SCORE_NUM; i++) {
					CGame._levelTotalScore[i] = Mem_GetInt(data, offset);
				offset += 4;
			}
		}
	// } catch ( ex) {
			//ex.printStackTrace();
			// Dbg("Loading RMS... error : " + ex.message);
	// }
}

// Initialize the RMS for the first time
CGame.RMS_Init = function() //throws Exception
{
	if (DEF.dbgEnable) Dbg("Initializing RMS...");
	CGame.bSetLanguage = (Language.count > 1) ? true : false;
	CGame.curLanguage = 0;

	// CGame.bSetSound = true;
	CGame._gameProgress = GAME_PROGRESS_FIRST_PLAY;
	CGame._levelId = 255;
	CGame._levelInfo[0] = 1;
	GLLibPlayer.Snd_SetMasterVolume(SOUND_LEVEL_HIGH);
	var levelInfo = 0;
	if (DEF.dbgUnlockLevel) {
		levelInfo = 1;
	}
	for (var i = 1; i < RMS.LEVEL_INFO_NUM; i++)
	{
		 CGame._levelInfo[i] = levelInfo;
	}
		CGame._levelFinalInfo1 = 0;
		CGame._levelFinalInfo2 = 0;

	for (var i = 0; i < RMS.PLAYER_INFO_NUM; i++)
	{
		CGame._playerInfo[i] = 0;
	}
	CGame._playerInfo[DAI.HPI_LIVES] = 3;
	CGame._playerInfo[DAI.HPI_HP_MAX] = 0;

	for(var i = 0; i < CGame._levelStarInfo.length; i++) {
		CGame._levelStarInfo[i++] = DAI.MAX_STAR_NUM;
		//star 1 x,y information
		CGame._levelStarInfo[i++] = 0;
		CGame._levelStarInfo[i++] = 0;
		//star 2
		CGame._levelStarInfo[i++] = 0;
		CGame._levelStarInfo[i++] = 0;
		//star 3
		CGame._levelStarInfo[i++] = 0;
		CGame._levelStarInfo[i] = 0;
	}

	for (var i = 0; i < CGame._levelTotalScore.length; i++) {
		CGame._levelTotalScore[i] = 0;
	}
	
	// try {
		CGame.RMS_Save();
	// } catch (ex) {
			//ex.printStackTrace();
		// Dbg("RMS_Save saving error..." + ex.message);
	// }
	CGame._levelId = -1;
	CGame._worldId = 0;
}

// Reset only game-specific elements of the RMS for use with RESET_GAME
CGame.prototype.RMS_Reset = function()
{
	if (DEF.dbgEnable) Dbg("Resetting game-specific RMS...");

	// Put game-specific varialization here
}


	// The splash image

// array to store all the language currently in this build
var 									languageArray = null;
var 									languageArrayTextId = null;

// Action phase variables
CGame.spriteArray = LowAPI.Gen_Array([128], null);//new ASprite[128];
//@#if not RemoveBlendEffect
CGame.blendSpriteArray;
//@#endif
// text pack
var textPack = null;

// Font variables
var 								useStandardTextInsteadOfFont = false;
var fontSpr; // Aurora font sprite
var 									fontPalette; // font palette for language not usng Aurora font


CGame.m_chtFont;

var fontSprBig;
var fontSprSmall;

var useBitmapFont = false;
// Tileset variables
// var 									nTileSetDirection;
// var 									nMaxW;
// var 									nMaxH;
// var 									nMaxWLayer = -1;
// var 									nMaxHLayer = -1;
// boolean								bShowLayer0 = true;
// boolean								bShowLayer1 = true;
// boolean								bShowLayer2 = true;

// -----------------------------------------------------------------------------------------------------------------------------------------
// FONTS

CGame.prototype.fontLoad = function()// throws Exception
{
	// CGame.curLanguage = 0;
	var lang = languageArray[CGame.curLanguage];
	// Don't use system font and bitmap font from now !!!
	// if (lang == GLLang.CN || lang == GLLang.KR || lang == GLLang.JP) {
		// useStandardTextInsteadOfFont = true;
		// useBitmapFont = true;
	// } 
	// else 
	{
		useStandardTextInsteadOfFont = false;
		useBitmapFont = false;
	}
	if (useStandardTextInsteadOfFont)
	{
		fontPalette = LowAPI.Gen_Array([2], 0);//new var[2];
		fontPalette[0] = 0xff0000;
		fontPalette[1] = 0x00ff00;
	}
//		else
	{
		if (DEF.dbgEnable) Dbg("opening font pack");
		if (useBitmapFont) {
			fontSprBig = new CHT_ASprite();
			fontSprSmall = new CHT_ASprite();
		} else {
			fontSprBig = new ASprite();//new CHT_ASprite();
			fontSprSmall = new ASprite();//new CHT_ASprite();
		}

		
		if (DEF.dbgEnable) Dbg("reading font pack");
		var fontPack, fontName1, fontName2, fontTable;
		
		if (lang == GLLang.RU) {
			fontPack = DATA.PACK_FONT_EN;
			fontName1 = DATA.FONT_EN_01;
			fontName2 = DATA.FONT_EN_02;
			fontTable = DATA.FONT_EN_TABLE;	
		} else if (lang == GLLang.CN) {
			fontPack = DATA.PACK_FONT_CN;
			fontName1 = DATA.FONT_CN_01;
			fontName2 = DATA.FONT_CN_02;
			fontTable = DATA.FONT_CN_TABLE;
		} else {
			fontPack = DATA.PACK_FONT_EN;
			fontName1 = DATA.FONT_EN_01;
			fontName2 = DATA.FONT_EN_02;
			fontTable = DATA.FONT_EN_TABLE;
		}
		
		// open pack
		Pack_Open(fontPack);
		fontSprBig = CGame.Load_TextFontSprite(fontName1, fontTable);
		fontSprSmall = CGame.Load_TextFontSprite(fontName2, fontTable);
		
		// var fontTable = Pack_ReadArray(DATA.FONT_TABLE);
		// fontSprBig.Load(Pack_ReadData(DATA.FONT_01), 0);
		// fontSprSmall.Load(Pack_ReadData(DATA.FONT_02), 0);
//@#if CacheFontForOptimize
            // for( var i = 0 ; i < fontSprBig._palettes ; i ++)
			// 	fontSprBig.BuildCacheImages(i, 0, -1, -1);
			// for( var i = 0 ; i < fontSprSmall._palettes ; i ++)
			// 	fontSprSmall.BuildCacheImages(i, 0, -1, -1);
//@#endif

		//close pack
		Pack_Close();

		// Dbg("setting char map");

		//set the char map (must be done after that the sprite is assigned)
		// fontSprBig.SetCharMap(fontTable);
		// fontSprSmall.SetCharMap(fontTable);
		// Dbg("building font cache");
		// cache font images --> speed up rendering, consume more heap
			// for (var pal = 0; pal < fontSprBig._palettes; pal++) {
			// 	fontSprBig.BuildCacheImages(pal, 0, -1, -1);
			// }
			// for (var pal = 0; pal < fontSprSmall._palettes; pal++) {
			// 	fontSprSmall.BuildCacheImages(pal, 0, -1, -1);
			// }
	CGame.txtSetFont(fontSprBig);
	}
}

CGame.Load_TextFontSprite = function ( fontPackIdx, fontTablePackIdx )
{
	var isCacheFrames = false;
	var isFreeCacheData = false;
	
	var fontSprite = new ASprite ();
	fontSprite.Load ( Pack_ReadData ( fontPackIdx ) , 0 );
	var fontTable = Pack_ReadArray ( fontTablePackIdx );

	fontSprite.SetCharMap ( fontTable );

	// if ( GLLibConfiguration.sprite_useCachePool )
	// {
		// fontSprite.SetPool(IDefine.POOL_FONTS);
	// }
	// else
	{
		var palNum = fontSprite.GetNumPalettes ();
		for (var i = 0 ; i < palNum ; i ++ )
		{
			if(isCacheFrames)
			{
				fontSprite.BuildCacheImages ( i , 0 , - 1 , - 1 );
				fontSprite.BuildCacheFrames(i, 0 , - 1 );
			}
			else
			{
				fontSprite.BuildCacheImages ( i , 0 , - 1 , - 1 );
			}
		}
		
		if(isCacheFrames)
		{
			fontSprite.PushCacheFramesToGL( );
		}
		else
		{
			fontSprite.PushCacheImagesToGL( );
		}
		
	}
	
	
	if(isCacheFrames)
	{
		fontSprite.FreeCachedModules();
	}
	else
	{
		fontSprite.FreeCachedFrames();
	}
	
	if (isFreeCacheData) {
		fontSprite.FreeCacheData();
	}
	
	return fontSprite;
}

CGame.txtSetFont = function( font) {
	fontSpr = font;
}
CGame.txtDraw = function(palette, text, posX, posY, anchor) {
	CGame.txtDraw7(palette, text, posX, posY, anchor, -1, -1);
}

CGame.txtDraw7 = function(palette, text, posX, posY, anchor, start, end) {
	if (useStandardTextInsteadOfFont) {
		SetColor(fontPalette[palette]);
		DrawString(text, posX, posY, anchor);
	} else {
		fontSpr.SetSubString(start, end);//ASprite.SetSubString(start, end);		
		fontSpr.SetCurrentPalette(palette);
		fontSpr.DrawString(g, text, posX, posY, anchor);
	}
}

/* Text draw special effect:each char wave one after anthor
 *       C                G       
 *    B     D        F          H
 * A            E                     I
 */
var indexForJumpPos=0;
CGame.prototype.txtDrawSpecialEffectWave = function(palette, text, posX, posY, anchor) //throws Exception
{
	var textLength = (text == null) ? 0 : text.length;		
	
	var x = posX;
	var y = posY;
	var stringLen=0;
	var positions=[posY, posY-1, posY-1, posY-2, posY-2, posY-1,posY-1, posY,
					 posY, posY+1, posY+1, posY+2, posY+2, posY+1,posY+1, posY];		
	fontSpr.SetCurrentPalette(palette);				
	for(var i = 0; i < textLength; i++) {
		stringLen += fontSpr.getCharSize(text.charAt(i));	
	}
	
	var pos = LowAPI.Gen_Array([2], 0);//new var[2];
	x = ( GLLibConfig.screenWidth - stringLen )/2;
	pos[0] = x;
	indexForJumpPos = (++indexForJumpPos)%positions.length;
	for(var i=0; i<textLength; i++)
	{		
//@#if removeTextWaveEffect
//@            if( CGame.bIsPaused )
//@				y = posY;
//@			else
//@#endif
			y = positions[(indexForJumpPos+i)%positions.length];
		fontSpr.DrawString(g, text.charAt(i),x, y, anchor);
		x+=fontSpr.getCharSize(text.charAt(i));
	}
	pos[1] = x;
	return pos;
}

/*
 *  amplitude: direct the degree of the oscillation
 *  period: direct the speed of the oscillation  in fact it is
 *  the varerval of each povar in the oscillation
 *  not completed! in fact you can only adjust the value of amplitude
 */ 
var _waveStep;
CGame.prototype.txtDrawSpecialEffectWave_New = function(palette, text, posX, posY, amplitude, period, anchor) //throws Exception
{
	var textLength = text.length;		
	
	var x = posX;
	var y = posY;
	var stringLen=0;
//		var positions[]={posY, posY-1, posY-1, posY-2, posY-2, posY-1,posY-1, posY,
//						 posY, posY+1, posY+1, posY+2, posY+2, posY+1,posY+1, posY};	
	//var positonsDynamic[] = new var[amplitude/(period+1)*4];
//		var actionNum = 4*amplitude/(period + 1);
//		for (var i = 0; i < amplitude/(period+1)*4; i++) {
//			if (i < amplitude/(period+1)*2) { 
//				positonsDynamic[i] = posY - period*(amplitude - /*GLLib.*/Math_Abs(i-amplitude)); 
//			} else {
//				positonsDynamic[i] = posY + period*(amplitude - /*GLLib.*/Math_Abs(i-3* amplitude));
//			}
//		}
	var positonsDynamic = LowAPI.Gen_Array([amplitude * 4], 0);//new var[amplitude*4];
	for (var i = 0; i < amplitude*4; i++) {
		if (i < amplitude*2) { 
			positonsDynamic[i] = posY - (amplitude - /*GLLib.*/Math_Abs(i-amplitude)) - 1; 
		} else {
			positonsDynamic[i] = posY + (amplitude - /*GLLib.*/Math_Abs(i-3* amplitude)) + 1;
		}
	}
	fontSpr.SetCurrentPalette(palette);				
	for(var i = 0; i < textLength; i++) {
		stringLen += fontSpr.getCharSize(text.charAt(i));	
	}

	x = ( GLLibConfig.screenWidth - stringLen )/2;
	indexForJumpPos = (++indexForJumpPos)%positonsDynamic.length;
	for(var i=0; i<textLength; i++)
	{		
		y = positonsDynamic[(indexForJumpPos+i)%positonsDynamic.length];
		//y = (var) (posY + (var)amplitude*Math.sin(i*2*/*GLLib.*/Math_FixedPovar_PI/(textLength-2) + _waveStep));
		
		fontSpr.DrawString(g, /* text.valueOf */(text.charAt(i)),x, y, anchor);
		x+=fontSpr.getCharSize(text.charAt(i));
	}		
	_waveStep=0;
}

/* Text draw special effect: each char fly to the position one by one
 *   A    B       C           D
 *   A  B   C    D
 *   AB C   D
 *   ABCD 
 */

CGame._actionSpeed; // more larger, more quick the move of the chars
CGame._xCurrent;
CGame._yCurrent;
CGame._stopAdd;
CGame._stopAdd2;

/*
void txtDrawSpecialEffectCongregate(var palette, var text, var posX, var posY, var anchor) throws Exception
{
	var textLength = text.length;	
	char textChars[] = text.toCharArray();		 
	var finalX;
	var moduleWidth=0;
	var stringLength = 0;
	var initialPosForChars[] = new var[textLength];
	for(var i = 0; i < textLength; i++) {
		moduleWidth = fontSpr.getCharSize(textChars[i]);		
		stringLength += moduleWidth;			
		if( i> 0 ){
			initialPosForChars[i] = initialPosForChars[i-1] + i*2 + 9;
		}else{
			initialPosForChars[i] = stringLength  + 200; ///+ moduleWidth*i*i
		}
	}

	if (useStandardTextInsteadOfFont)
	{
		SetColor(fontPalette[palette]);
		DrawString(text, posX, posY, anchor);
	}
	else
	{
		for(var i=0; i<textLength; i++)
		{

			finalX = CGame.getTheFinalPosOfCurrentChar(textChars, i) + ( GetScreenWidth() - stringLength )/2;				
			///draw each char in the current position until its final pos!
			CGame._xCurrent = initialPosForChars[i] - CGame._actionSpeed;
			if( CGame._xCurrent <=  finalX){
				CGame._xCurrent = finalX;
				if( i == textLength-1 ){
					CGame._stopAdd = true;
				}
			}				
			fontSpr.SetCurrentPalette(0);
			ASprite.SetSubString(i, i+1);
			fontSpr.DrawStringOrChars(g, null, textChars, CGame._xCurrent, posY+10, anchor, true);
			ASprite.SetSubString(-1, -1);
		}
	}//end else		
	if( !CGame._stopAdd ){
		CGame._actionSpeed+=40;
	}		
}
*/

CGame.txtDrawSpecialEffectCongregate_NEW = function(palette, text, posX, posY, anchor)
{
	var textLength = text.length;	
	var textChars = text.split('');//	text.toCharArray();		 
	var finalX;
	var moduleWidth=0;
	var stringLength = 0;
	var stringLengthFirstLine = 0;
	var stringLengthSecondLine = 0;
	var beginIndexForSecondLine = 0;
	var initialPosForChars = LowAPI.Gen_Array([textLength], 0);//new var[textLength];
	var startPosIndex = 0;
	var eachLinePosY = 0;

	for(var i = 0; i < textLength; i++) {
		moduleWidth = fontSpr.getCharSize(textChars[i]);		
		stringLength += moduleWidth;		
		if (textChars[i] == '^') {
			beginIndexForSecondLine = i+1;
			stringLengthFirstLine = stringLength;
			//continue;
		}
		if( i> 0 ){
			initialPosForChars[i] = initialPosForChars[i-1] + i*2 + 9;
		}else{
			initialPosForChars[i] = stringLength  + 200; ///+ moduleWidth*i*i
		}
	}
	stringLengthSecondLine = stringLength - stringLengthFirstLine;
	if (useStandardTextInsteadOfFont)
	{
		SetColor(fontPalette[palette]);
		DrawString(text, posX, posY, anchor);
	}
	else
	{
		for(var i=0; i<textLength; i++)
		{				
			if (beginIndexForSecondLine <= i) {
				eachLinePosY = posY + 25;
				stringLength = stringLengthSecondLine;
				startPosIndex = beginIndexForSecondLine;
			} else {
				stringLength = stringLengthFirstLine;
				startPosIndex = 0;
				eachLinePosY = posY + 10;
			}

			finalX = CGame.getTheFinalPosOfCurrentChar(textChars, startPosIndex, i) + ( GLLibConfig.screenWidth - stringLength )/2;				
			///draw each char in the current position until its final pos!
			CGame._xCurrent = initialPosForChars[i] - CGame._actionSpeed;
			if( CGame._xCurrent <=  finalX){
				CGame._xCurrent = finalX;
				if( i == textLength-1 ){
					CGame._stopAdd2 = true;
				}
			}				

			fontSpr.SetCurrentPalette(0);
			fontSpr.SetSubString(i, i+1);//ASprite.SetSubString(i, i+1);
			fontSpr.DrawStringOrChars(g, null, textChars, CGame._xCurrent, eachLinePosY, anchor, true);
			fontSpr.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
		}
	}//end else		
	if( !CGame._stopAdd2 ){
		CGame._actionSpeed+=40;
	}		
}

/*
 * a general function to produce the effect of flowing varo the screen
 * you can give it -1 or 1 as the direction you want to flow from
 * the speed can adjust the speed of the flow
 * new=>
 * return: the index of the latest char which arrived its position
 * WARING: never try to set the maxLengthPerLine smaller than longest word in the string! I mean you must verify one whole word can be drawed in one line!
 */
var _flowFromLeft = -1;
var _flowFromRight = 1;
var _directDisplay = 0;
var stringLengthFirstLine = 0;
var stringLengthSecondLine = 0;
var beginIndexForSecondLine = 0;
var _firstLineCompleted;
var _secondLineCompleted;
CGame.textChars = null;
var _totalLines;
var _beginIndexOfEachLine = null;
var _endIndexOfEachLine = null;
var _lengthOfEachLine = null;
var _whetherCompletedOfEachLine = null;
CGame.prototype.txtDarwSpecialEffecFlowIntoTheScreen = function(text, fontSprite, posX, posY, direction, maxLengthPerLine, speed, anchor)
{
	var palette = 0;
	var latestStopCharIndex = 0;
	var textLength = text.length;	
	
	var finalX;
	var moduleWidth=0;

	var startPosIndex = 0;
	var eachLinePosY = 0;

	//var stringLength = 0;
		if(CGame._firstEnterIntoThisFunction) {
			CGame._firstEnterIntoThisFunction = false;
		CGame._stopAdd = false;
		CGame._actionSpeed = 0;
		CGame._stringFrameLength = 0;
		initialPosForChars = LowAPI.Gen_Array([textLength], 0);//new var[textLength];
		_totalLines = 1;
		CGame.textChars = text.split('');//	text.toCharArray();	
		for (var i = 0; i < textLength; i++) {
			if (CGame.textChars[i] == '^') {
				CGame.textChars[i] = ' ';
			}
		}
		var currentLineLength = 0;
		var previousBlankSpaceIndex = 0;
		var underLineWrapArray = LowAPI.Gen_Array([3], 0);//new var[3];
		var underLineWrapIndex = 0;
		for (var i = 0; i < textLength; i++) {
			moduleWidth = fontSprite.getCharSize(CGame.textChars[i]);
			currentLineLength += moduleWidth;
//				if (true) {
				if (currentLineLength > maxLengthPerLine) { //the strings before this blank space is longer than the max length per line!
					if(CGame.textChars[previousBlankSpaceIndex] == ' ') {
						CGame.textChars[previousBlankSpaceIndex] = '^';  // replace the privious blank space with '^'
					} else if(CGame.textChars[previousBlankSpaceIndex] == '-') {
						if(underLineWrapIndex < 3) {
							underLineWrapArray[underLineWrapIndex] = previousBlankSpaceIndex;
							underLineWrapIndex ++;
						}
					}
					currentLineLength = 0;
					++_totalLines;
					if (i != textLength - 1) {
						i = previousBlankSpaceIndex; // compute again from the index after that of '^'							
					}
					continue;
				}
				if (CGame.textChars[i] == ' ' || CGame.textChars[i] == '-') {
					previousBlankSpaceIndex = i; //record the previous index of blank space!
				}
//				}
		}
		currentLineLength = 0;
		_beginIndexOfEachLine = LowAPI.Gen_Array([_totalLines], 0);//new var[_totalLines];
		_endIndexOfEachLine = LowAPI.Gen_Array([_totalLines], 0);//new var[_totalLines];
		_lengthOfEachLine = LowAPI.Gen_Array([_totalLines], 0);//new var[_totalLines];
		_whetherCompletedOfEachLine = LowAPI.Gen_Array([_totalLines], false);//new boolean[_totalLines];
		_beginIndexOfEachLine[0] = 0;
		var lineIndex = 0;
		for (var i = 0; i < textLength; i++) {
			moduleWidth = fontSprite.getCharSize(CGame.textChars[i]);
			currentLineLength += moduleWidth;
			if (CGame.textChars[i] == '^' || CGame.textChars[i] == '-') {
				var newLine = false;
				if(CGame.textChars[i] == '-') {
					for(var j = 2; j>=0; j--) {
						if(underLineWrapArray[j] == i) {
							newLine = true;
						}
					}
				} else {
					newLine = true;
				}
				if(newLine) {
					_beginIndexOfEachLine[lineIndex+1] = i + 1;
					_endIndexOfEachLine[lineIndex] = i - 1;
					_whetherCompletedOfEachLine[lineIndex] = false;
					_lengthOfEachLine[lineIndex] = currentLineLength - moduleWidth;
					lineIndex++;
					currentLineLength = 0;
				}
			}
			if (i == textLength - 1) {
				_lengthOfEachLine[lineIndex] = currentLineLength;
				_endIndexOfEachLine[lineIndex] = i;
			}
		}
		if( direction == _flowFromRight ) {
			lineIndex = 0;
			var currentLineEndIndex = 0;
			for(var i = 0; i < textLength; i++) {
				moduleWidth = fontSprite.getCharSize(CGame.textChars[i]);		
				CGame._stringFrameLength += moduleWidth;
				if (CGame.textChars[i] == '^') {
					currentLineEndIndex = _beginIndexOfEachLine[lineIndex] - 1;
					lineIndex++;
					CGame._stringFrameLength = 0;
					initialPosForChars[i] = DEF.VIEW_W;
					continue;
				}
				if( i> 0 ){
					initialPosForChars[i] = initialPosForChars[i-1] + (i - _beginIndexOfEachLine[lineIndex])*moduleWidth + 2;
				}else{
					initialPosForChars[i] = CGame._stringFrameLength  + DEF.VIEW_W; ///+ moduleWidth*i*i
				}					
			}
		}else if( direction == _flowFromLeft ) {
			lineIndex = _totalLines - 1;
			var currentLineEndIndex = 0;
			for(var i=textLength - 1; i>=0; i--) {					
				moduleWidth = fontSprite.getCharSize(CGame.textChars[i]);		
				CGame._stringFrameLength += moduleWidth;	
				if (CGame.textChars[i] == '^') {						
					currentLineEndIndex = _beginIndexOfEachLine[lineIndex] - 1;
					lineIndex--;
					CGame._stringFrameLength = 0;
					initialPosForChars[i] = 0;
					continue;
				}
				
				if( i < textLength - 1 ){
					initialPosForChars[i] = initialPosForChars[i+1] - ( ( (currentLineEndIndex) - i) * moduleWidth + 2 );
				}else{ 
					initialPosForChars[i] = 0 - CGame._stringFrameLength;
					currentLineEndIndex = i;
				}
			}
		}				
	}
	
	if (useStandardTextInsteadOfFont)
	{
		SetColor(fontPalette[palette]);
		DrawString(text, posX, posY, anchor);
	}
	else
	{
		if( direction == _flowFromRight ) {
			for(var i=0; i<textLength; i++)
			{
				for (var j = 0; j < _totalLines; j++) {
					if (i >= _beginIndexOfEachLine[j]) {
						startPosIndex = _beginIndexOfEachLine[j];
						CGame._stringFrameLength = _lengthOfEachLine[j];
						eachLinePosY = posY + 15 + (6 + ASprite.GetCurrentStringHeight()) * j;
					}						
				}
				finalX = CGame.getTheFinalPosOfCurrentChar(CGame.textChars, startPosIndex, i) + ( GLLibConfig.screenWidth - CGame._stringFrameLength )/2;				
				///draw each char in the current position until its final pos!
				CGame._xCurrent = initialPosForChars[i] - CGame._actionSpeed;
				if( CGame._xCurrent <=  finalX ){
					CGame._xCurrent = finalX;
					latestStopCharIndex = i;
					var temp = true;;
					for (var j = 0; j < _totalLines; j++) {
						if ( i == _endIndexOfEachLine[j]) {
							_whetherCompletedOfEachLine[j] = true;
						}
						temp = temp & _whetherCompletedOfEachLine[j];
					}
					if (temp) {
						CGame._stopAdd = true;
					}										
				}				
				//fontSprite.SetCurrentPalette(0);
				fontSprite.SetSubString(i, i+1);//ASprite.SetSubString(i, i+1);	
				fontSprite.DrawStringOrChars(g, null, CGame.textChars, CGame._xCurrent, eachLinePosY, anchor, true);				
				fontSprite.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
			}
		}else if( direction == _flowFromLeft ) {
			for(var i = textLength - 1; i >= 0; i--) {
				for (var j = 0; j < _totalLines; j++) {
					if (i >= _beginIndexOfEachLine[j]) {
						startPosIndex = _beginIndexOfEachLine[j];
						CGame._stringFrameLength = _lengthOfEachLine[j];
						eachLinePosY = posY + 15 + (6 + ASprite.GetCurrentStringHeight()) * j;
					}						
				}
				
				finalX = CGame.getTheFinalPosOfCurrentChar(CGame.textChars, startPosIndex,i) + ( GLLibConfig.screenWidth - CGame._stringFrameLength )/2; ///the final absolute positon in the screen of the current char
				CGame._xCurrent = initialPosForChars[i] + CGame._actionSpeed;		
				
				if (CGame._xCurrent >= finalX) {
					CGame._xCurrent = finalX;
					latestStopCharIndex = i;							
					var temp = true;;
					for (var j = 0; j < _totalLines; j++) {
						if (i == _beginIndexOfEachLine[j]) {
							_whetherCompletedOfEachLine[j] = true;
						}
						temp = temp & _whetherCompletedOfEachLine[j];
					}
					if (temp) {
						CGame._stopAdd = true;
					}						
				}					
				fontSprite.SetSubString(i, i+1);//ASprite.SetSubString(i, i+1);
				//fontSprite.SetCurrentPalette(0);
				fontSprite.DrawStringOrChars(g, null, CGame.textChars, CGame._xCurrent, eachLinePosY, anchor, true);
				fontSprite.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
			}
		} else if (direction == _directDisplay) {
			for(var i = textLength - 1; i >= 0; i--) {
				for (var j = 0; j < _totalLines; j++) {
					if (i >= _beginIndexOfEachLine[j]) {
						startPosIndex = _beginIndexOfEachLine[j];
						CGame._stringFrameLength = _lengthOfEachLine[j];
						eachLinePosY = posY + 15 + (6 + ASprite.GetCurrentStringHeight()) * j;
					}						
				}
				
				finalX = CGame.getTheFinalPosOfCurrentChar(CGame.textChars, startPosIndex,i) + ( GLLibConfig.screenWidth - CGame._stringFrameLength )/2; ///the final absolute positon in the screen of the current char				
				fontSprite.SetSubString(i, i+1);//ASprite.SetSubString(i, i+1);
				//fontSprite.SetCurrentPalette(0);
				fontSprite.DrawStringOrChars(g, null, CGame.textChars, finalX, eachLinePosY, anchor, true);
				fontSprite.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
			}
		}
	}//end else		
	if( !CGame._stopAdd ){
		CGame._actionSpeed+=speed;
	}		
	return latestStopCharIndex;
}

var currentPos = 0;
var _currentAlpha = 0XFF;
CGame._popUpEnded = false;
CGame._initArrayForPalette = true;
var _popSpeed = 5;
/*
 * you should init CGame._popUpEnded = false; CGame._initArrayForPalette = true 
 * before calling this function, 
 * but don't do it more than one times if you want it execute just once!  
 * initSpeed must larger than zero! it direct the speed of poping up. 
 */
CGame.txtDrawSpecialEffectPopUp = function(palette, text, posX, posY, popHeight, initSpeed, moveHeight, anchor) 
{
	var changeDarkPos = posY - popHeight;	
	var disappearDistance = moveHeight;
	if (initSpeed <= 0) {
		initSpeed = 1;
	}
	CGame.txtSetFont(fontSprBig);
	 if (CGame._initArrayForPalette && useBitmapFont) { // DON'T CREATE ALPHA PALETTE FOR NORMAL FONT TO OPT FPS.
		 CGame.CreateAlphaPalette(fontSpr, palette, 4, 0xFF, false);
		 CGame._initArrayForPalette = false;			 
	 }
	 fontSpr.SetCurrentPalette(4);
	 fontSpr.ModifyPaletteAlpha(4, _currentAlpha);
	 if (useBitmapFont)
		fontSpr.CHT_ModifyPaletteAlpha(fontSpr._nModules, 4, _currentAlpha);
	 //txtDraw (palette, text, posX-50, posY, anchor);
	if (!CGame._popUpEnded) {
		if (!CGame.bIsPaused) {
			currentPos -= _popSpeed;
		}
//@#if CacheFontForOptimize
//@            txtDraw (2, text, posX, posY+currentPos, anchor);
//@#else
		CGame.txtDraw (4, text, posX, posY+currentPos, anchor);
//@#endif
	}
	if (currentPos+posY <= changeDarkPos) {
		_currentAlpha -= 0x0F;
		_popSpeed = 1;
	}
	if (currentPos+posY <= posY - disappearDistance) {
		CGame._initArrayForPalette = true;
		CGame._popUpEnded = true;
		currentPos = 0;
		_currentAlpha = 0XFF;
		_popSpeed = initSpeed;
	}
}

CGame._currentPosX = 0;
CGame._currentPosY = 0;
CGame.txtDrawSpecialEffectFlowFromTheSky = function(palette, text, posX, posY, anchor) 
{
	CGame._currentPosY += 20;
	if (CGame._currentPosY >= posY) {
		CGame._currentPosY = posY;
	}		
	var align = 1;
	var startLine = 0;
	var lineCount = 10;
	var lineInterval = 5;
	var maxLengthPerLine = DEF.VIEW_W - 20; 
	CGame.DrawMultiLineText ( g, text, posX, CGame._currentPosY, 
				align, 2, maxLengthPerLine, startLine, lineCount, lineInterval); 
	if (CGame._currentPosY == posY) {
		return true;
	} else {
		return false;
	}
}

CGame.txtDrawSpecialEffectFlowFromLeft = function(palette, text, posX, posY, anchor)
{
	var textLength = text.length;	
	var textChars = text.split('');//	text.toCharArray();		 
	var finalX;
	var moduleWidth=0;
	var stringLength = 0;
	var stringLengthFirstLine = 0;
	var stringLengthSecondLine = 0;
	var beginIndexForSecondLine = 0;
	var initialPosForChars = LowAPI.Gen_Array([textLength], 0);//new var[textLength];
	var startPosIndex = 0;
	var eachLinePosY = 0;

	for(var i = 0; i < textLength; i++) {
		moduleWidth = fontSpr.getCharSize(textChars[i]);		
		stringLength += moduleWidth;		
		if (textChars[i] == '^') {
			beginIndexForSecondLine = i+1;
			stringLengthFirstLine = stringLength;
			//continue;
		}
		if( i> 0 ){
			initialPosForChars[i] = initialPosForChars[i-1] + i*2 + 9;
		}else{
			initialPosForChars[i] = stringLength  + 200; ///+ moduleWidth*i*i
		}
	}
	stringLengthSecondLine = stringLength - stringLengthFirstLine;
	if (useStandardTextInsteadOfFont)
	{
		SetColor(fontPalette[palette]);
		DrawString(text, posX, posY, anchor);
	}
	else
	{
		for(var i=0; i<textLength; i++)
		{				
			if (beginIndexForSecondLine <= i) {
				eachLinePosY = posY + 25;
				stringLength = stringLengthSecondLine;
				startPosIndex = beginIndexForSecondLine;
			} else {
				stringLength = stringLengthFirstLine;
				startPosIndex = 0;
				eachLinePosY = posY + 10;
			}

			finalX = CGame.getTheFinalPosOfCurrentChar(textChars, startPosIndex, i) + ( GLLibConfig.screenWidth - stringLength )/2;				
			///draw each char in the current position until its final pos!
			CGame._xCurrent = initialPosForChars[i] - CGame._actionSpeed;
			if( CGame._xCurrent <=  finalX){
				CGame._xCurrent = finalX;
				if( i == textLength-1 ){
					CGame._stopAdd = true;
				}
			}				

			fontSpr.SetCurrentPalette(0);
			fontSprite.SetSubString(i, i+1);//ASprite.SetSubString(i, i+1);
			fontSpr.DrawStringOrChars(g, null, textChars, CGame._xCurrent, eachLinePosY, anchor, true);
			fontSprite.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
		}
	}//end else		
	if( !CGame._stopAdd ){
		CGame._actionSpeed+=40;
	}			
}



CGame.getTheFinalPosOfCurrentChar = function( charBuf, relativeStartPosIndex, currentChar )
{
	var finalPos_x = 0;
	var moduleWidth;
	var stringLength = 0;
	var textChars = charBuf;
	for( var i=relativeStartPosIndex; i<currentChar; i++){
		moduleWidth = fontSpr.getCharSize(textChars[i]); 
		stringLength += moduleWidth;			
	}
	finalPos_x = stringLength;
	return finalPos_x;
}
// -----------------------------------------------------------------------------------------------------------------------------------------

// LOADING/UNLOADING

// load a sprite, allocate CGame.spriteArray
// spr is one value of SPRITE varerface

CGame.LoadSprite = function()
{
	if(arguments)
	{
		switch(arguments.length)
		{
			case 4:
				// if(typeof arguments[0] == 'number' && typeof arguments[1] == 'number' && typeof arguments[2] == 'number')
				// {
					// CGame.LoadSprite4v.apply(this, arguments);
					// break;
				// }
				// else
					{return CGame.LoadSprite4.apply(this, arguments);};
			case 5:
			{
				if(typeof arguments[0] == 'number' && typeof arguments[1] == 'number' && typeof arguments[2] == 'number')
				{
					CGame.LoadSprite5v.apply(this, arguments);
					break;
				}
				else
				return CGame.LoadSprite5.apply(this, arguments);
			}
			case 6:
			{
				return CGame.LoadSprite6.apply(this, arguments);
			}
			case 8:
			{
				return CGame.LoadSprite8.apply(this, arguments);
			}
		}
	}
	else
	throw new Error("InvalidArguments");
}

// Constants for different types of sprite loading
var k_loadSpritePalAlphaNone				= 0;
var k_loadSpritePalAlphaConstant			= 1;
var k_loadSpritePalAlphaFromPal				= 2;
// Loads a sprite.
/*static void*/ CGame.LoadSprite5v  = function( spriteID,  libID,  pal, /*boolean*/ cacheSprite, freeCacheData)
{
	//TRACE("*** LoadSprite: size("+ _sprites.length +") _sprites["+ spriteID + "]= " + _sprites[spriteID] + "  libID = " + libID);
	
	if (CGame.spriteArray[spriteID] == null)
	{

		CGame.spriteArray[spriteID] = CGame.LoadSprite4( libID, pal, cacheSprite, freeCacheData/* true */ );
	}


	//TRACE("*** end LoadSprite");
}

///
/// @param dataID is the ID of the resource that holds the sprite data
/// @param paletteMask is a mask listing which palettes should be loaded
/// @param buildCache if true will convert all the image data into images
/// @param freeCacheData if true will release the sprite data before exiting
/// @param cacheAsRGB if TRUE the image cache will be built as int[]
//-----------------------------------------------------------------------------
/*public static ASprite*/  CGame.LoadSprite5  = function(/*int*/ dataID, /*int*/ paletteMask, /*boolean*/ buildCache, /*boolean*/ freeCacheData, /*boolean*/ cacheAsRGB)
{
    return  CGame.LoadSprite8(dataID, paletteMask, k_loadSpritePalAlphaNone, 0, buildCache, freeCacheData, cacheAsRGB, true);
}

//-----------------------------------------------------------------------------
/// Loads a sprite.
///
/// @param dataID is the ID of the resource that holds the sprite data
/// @param paletteMask is a mask listing which palettes should be loaded
/// @param buildCache if true will convert all the image data into images
/// @param freeCacheData if true will release the sprite data before exiting
/// @param cacheAsRGB if TRUE the image cache will be built as int[]
/// @param enableCompressAs256RLE if TRUE the sprite will be compressed to I256RLE if it will be kept compressed
//-----------------------------------------------------------------------------
/*public static ASprite*/ CGame.LoadSprite6  = function(/*int*/ dataID, /*int*/ paletteMask, /*boolean*/ buildCache, /*boolean*/ freeCacheData, /*boolean*/ cacheAsRGB, /*boolean*/ enableCompressAs256RLE)
{
    return  CGame.LoadSprite8(dataID, paletteMask, k_loadSpritePalAlphaNone, 0, buildCache, freeCacheData, cacheAsRGB, enableCompressAs256RLE);
}

//-----------------------------------------------------------------------------
/// Loads a sprite.
///
/// @param dataID is the ID of the resource that holds the sprite data
/// @param paletteMask is a mask listing which palettes should be loaded
/// @param buildCache if true will convert all the image data into images
/// @param freeCacheData if true will release the sprite data before exiting
//-----------------------------------------------------------------------------
/*public static ASprite*/ CGame.LoadSprite4  =  function(/*int*/ dataID, /*int*/ paletteMask, /*boolean*/ buildCache, /*boolean*/ freeCacheData)
{
    return CGame.LoadSprite8(dataID, paletteMask, k_loadSpritePalAlphaNone, 0, buildCache, freeCacheData, false, true);
}

//-----------------------------------------------------------------------------
/// Loads a sprite.
///
/// @param dataID is the ID of the resource that holds the sprite data
/// @param paletteMask is a mask listing which palettes should be loaded
/// @param alphaType determines if we should somehow modify the alpha channel of the palettes we are requesting
/// @param alphaParam is used for certain alphaTypes, mainly to set the constant alpha level at some value
/// @param buildCache if true will convert all the image data into images
/// @param freeCacheData if true will release the sprite data before exiting
/// @param enableCompressAs256RLE if TRUE the sprite will be compressed to I256RLE if it will be kept compressed
//-----------------------------------------------------------------------------
/*public static ASprite*/ CGame.LoadSprite8  = function(/*int*/ dataID, /*int*/ paletteMask, /*int*/ alphaType, /*int*/ alphaParam, /*boolean*/ buildCache, /*boolean*/ freeCacheData, /*boolean*/ cacheAsRGB, /*boolean*/ enableCompressAs256RLE)
{
    var sprite = new ASprite();
	var d = null;
	/*byte []*/ d = Pack_ReadData(dataID);
	
	// var dt = "";
	// for(var j = 0;j < d.length; j++)
		// dt += d[j] + ",";
	// console.log("data=" + dt);
	if(d.length == 0)
	{
		//Err(  "read pack error") ;
		return null;
	}
    if(sprite.Load(d, 0) === false)
	{
		Err(  "load sprite error") ;
		return null;
	}
	// --- check if we need to load all palettes
	if (paletteMask == -1)
	{
		paletteMask = 0;
		for (var i = 0; i < sprite._palettes; i++)
			paletteMask |= (1 << i);
	}
	/* not use in html
    if (cacheAsRGB)
    {
        sprite.SetUseCacheRGB(true);
    }
	*/
	var isForceCacheFrames = false;
	if (dataID == DATA.SPRITE_MOBS_CANNON || dataID == DATA.SPRITE_OBJ_BALANCE ) {
		if (DEF.dbgEnable) Dbg("=================================== cache frame sprite mobs_cannon.");
		isForceCacheFrames = true;
	}
	var isCacheFrames = false; // force for html5
    for (var n=0; (paletteMask >> n) != 0; n++)
    {
        if (((paletteMask >> n) & 0x01) != 0)
        {
            // Check if there is some alteration to the alpha channel we should do
            if (alphaType != k_loadSpritePalAlphaNone)
            {
                if (alphaType == k_loadSpritePalAlphaConstant)
                {
                    // Set a constant alpha value
                    sprite.ModifyPaletteAlpha(n, alphaParam);
                }
                else if (alphaType == k_loadSpritePalAlphaFromPal)
                {
                    // Use another palette which contains the alpha channel (last one)
                    sprite.ModifyPaletteAlphaUsingLastPalette(n);
                }
            }

            //if (buildCache)
			if(isCacheFrames || isForceCacheFrames)
			{
				sprite.BuildCacheImages ( n , 0 , - 1 , - 1 );
				if (isForceCacheFrames) {
					switch(dataID) {
						case DATA.SPRITE_MOBS_CANNON:
							sprite.BuildCacheFrames(n, 20 , 25 );
							sprite.BuildCacheFrames(n, 17 , 17 );
							break;
						case DATA.SPRITE_OBJ_BALANCE:
							sprite.BuildCacheFrames(n, 0 , 1 );
							break;
						default:
							break;
					}
					
				}
				else
					sprite.BuildCacheFrames(n, 0 , - 1 );
			}
			else
            {
                sprite.BuildCacheImages(n, 0, -1, -1);
            }
        }
    }
	if (isForceCacheFrames) sprite.PushCacheFramesToGL( );
	if(isCacheFrames)
	{
		sprite.PushCacheFramesToGL( );
	}
	else
	{
		sprite.PushCacheImagesToGL( );
	}
	
	// if(isCacheFrames)
	// {
		// sprite.FreeCachedModules();
	// }
	// else
	// {
		// sprite.FreeCachedFrames();
	// }
	// if (DEF.dbgEnable) Dbg("loadSprite : ******************* freeCacheData --- " + freeCacheData);
    if (buildCache && freeCacheData)
    {
        sprite.FreeCacheData();
    }
	else
	{
		if (!freeCacheData && enableCompressAs256RLE && (sprite._data_format == ASprite.ENCODE_FORMAT_I256))
		{
			sprite.ConvertCompressedData_I256_I256RLE(true);
		}
	}
	d = null;
    return sprite;
}


CGame.spriteLoad  = function(spriteSlot, dataID, buildCache, bKeepModuleData)
{
	// Default palette = 1 
	CGame.LoadSprite(spriteSlot, dataID, -1, buildCache, !bKeepModuleData);	
	/*if (CGame.spriteArray[spriteSlot] == null)
	{
		CGame.spriteArray[spriteSlot] = new ASprite();
		CGame.spriteArray[spriteSlot].Load(Pack_ReadData(dataID), 0);
		if (buildCache)
		{
//@#if BREW_CacheAllSprite
//@				for (var i = 0; i < CGame.spriteArray[spriteSlot]._palettes; i++)
//@				{
//@					if (dataID == DATA.SPRITE_HERO)// || dataID == DATA.SPRITE_OBJ_BALANCE || dataID == DATA.SPRITE_MAP_ACTOR)
//@					{
//@						CGame.spriteArray[spriteSlot].BuildCacheImages(0, 0, -1, -1);
//@						break;
//@					}
//@					else
//@					{
//@						CGame.spriteArray[spriteSlot].BuildCacheImages(i, 0, -1, -1);
//@					}
//@				}
//@#else // BREW_CacheAllSprite
			CGame.spriteArray[spriteSlot].BuildCacheImages(0, 0, -1, -1);
//@#endif // BREW_CacheAllSprite

			if(bKeepModuleData == false)
			{
				CGame.spriteArray[spriteSlot].FreeCacheData();
			}
		}
	}*/
}

CGame.spriteUnLoad  = function(spriteSlot)
{
	// TEMP ----------------------------------------------------------
	// TEMP ----------------------------------------------------------
	// TEMP ----------------------------------------------------------
	if (spriteSlot == DATA.SPRITE_MOBS_WHITE // CRASH at NEW GAME.
	 ||spriteSlot ==  DATA.SPRITE_BONUS //CRASH at BOSS LEVEL 3
	){ 
		if (DEF.dbgEnable) Dbg("spriteUnLoad : ******************* IGNORE --- " + spriteSlot);
		return;
	}
	if (CGame.spriteArray[spriteSlot] != null)
	{
		if (DEF.dbgEnable) Dbg("spriteUnLoad : ******************* " + spriteSlot);
		CGame.spriteArray[spriteSlot].FreeCacheData();
		CGame.spriteArray[spriteSlot].FreeCachedFrames();
		CGame.spriteArray[spriteSlot].FreeCachedModules();
		CGame.spriteArray[spriteSlot] = null;
	}
}

CGame._loadingSpriteMap = [ DSpriteID.MOBS_WHITE,  DAnimID.MOBS_WHITE_WALK,
//@#if not RemovePirateLevel
													DSpriteID.SEAGULL,  DAnimID.SEAGULL_FLY,  
//@#endif
													DSpriteID.HERO,  DAnimID.HERO_FAT_WALK,  
//@#if not RemoveIceLevel
//@														DSpriteID.MOBS_PENGUIN, DAnimID.MOBS_PENGUIN_SLIDE,
//@#endif
													DSpriteID.MOBS_UFO, DAnimID.MOBS_UFO_MOVE,
													DSpriteID.BOSS_WATCH, DAnimID.BOSS_WATCH_LAUGH];

CGame.level2Tiled = function(levelId, nLayer) {
	var levleId = CGame._tempLevelId;
//@#if RemoveBeeKillerBoss
//@		if(CGame._tempLevelId >= (DAI.WORLD_ID_CAKE + 1) * DAI.LEVELS_NUM_PRE_WORLD - 1) {
//@			levleId ++;
//@		}
//@#endif
//@#if RemoveUfoBoss
//@		if(CGame._tempLevelId >= DAI.LEVEL_ID_CASTLE - 1) {
//@			levleId ++;
//@		}
//@#endif
	return CGame._level2tiled[(levleId * (GLLibConfig.tileset_maxLayerCount)) + nLayer];
}

/*
* Ignore some sprite without any module (optimized).
*/
CGame._optimizeSprite = [DATA.SPRITE_GAMELOFT_LOGO, DATA.SPRITE_LV1_ELEMENTS, DATA.SPRITE_MOBS_YETI, DATA.SPRITE_MOBS_PENGUIN, DATA.SPRITE_ACTOR_SNOWMAN];

CGame.LoadUnload = function(loading_Phase) //throws Exception
{
	switch (loading_Phase)
	{
		// load text
		case 0:
			CGame._actionSpeed = 0;
				CGame._firstEnterIntoThisFunction = true;
			CGame._stopMove = false;
			CGame._stopAdd = false;
				CGame._moveSpeed = 0;
				if (CGame._tempLevelId > DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
					CGame._specialEffectStep = CGame.EFFECT_OVER;
				} else {
					CGame._specialEffectStep = CGame.EFFECT_DOWNING_INTO_SCREEN;
			}

			loading_Phase = DLoadState.LOAD_TEXT;
			GLLibPlayer.Snd_Stop(DSound_Channel.BGM);
//				if (CGame._menu_bg == null) {
//					Pack_Open(DATA.PACK_IMAGE);
//					byte[] data = Pack_ReadData(DATA.IMAGE_MENU_BG);
//					CGame._menu_bg = Image.createImage(data, 0, data.length);
//					Pack_Close();
//				}
			// no break
		case DLoadState.LOAD_TEXT:
		{
			CGame.InitLevel();
			// if there is only one language, no need to go to language selection screen
			Text_LoadTextFromPack_INI(textPack, DATA.TEXT_MENU);
		}
		break;
		case DLoadState.UNLOAD_TEXT:
		{
			CGame.ReleaseLevel(false);
				CGame._checkPointData = null;
				CGame._actionSpeed = 0;
				CGame._firstEnterIntoThisFunction = true;
				CGame._stopMove = false;
			CGame._stopAdd = false;
			CGame._moveSpeed = 0;
			//Text_FreeAll();
		}
		break;

		case DLoadState.LOAD_TILESET:
			if (DEF.dbgEnable) Dbg("loading tilesets");

			Pack_Open(DATA.PACK_TILESET);
			for (var i = 0; i < GLLibConfig.tileset_maxLayerCount; i++) {
				var tiled = CGame.level2Tiled(CGame._tempLevelId, i);
				if (tiled != -1
//@#if RemoveTilesetBTM2
						&& i != 1
//@#endif
						) {
//@#if Nokia5300
//@                    	boolean buildCache = false;
//@                    	boolean keepModuleData = true;
//@#else
					var buildCache = true;
					var keepModuleData = true/* false */;
//@#endif                 
//@#if RemoveTilesetBTM2
//@    #if RemoveTilesetBTM2_for_N95_1M
//@                        spriteLoad(tiled + DSpriteID.TILESET_BASE, tiled, buildCache, keepModuleData);
//@    #else
					var dataIndex = tiled;
					dataIndex -= Math.floor(tiled / GLLibConfig.tileset_maxLayerCount);
					if (tiled == DClassID.BG_6 - DClassID.BTM) {
						dataIndex ++;
					}
					if (DEF.dbgEnable) Dbg("loading tilesets ------------------------------ i : " + i);
					CGame.spriteLoad(tiled + DSpriteID.TILESET_BASE, i > 1 ? dataIndex - 1 : dataIndex, buildCache, keepModuleData);	
//@    #endif
//@#else
//@                    	CGame.spriteLoad(tiled + DSpriteID.TILESET_BASE, tiled, buildCache, keepModuleData);
//@#endif
				}
			}
//				if (DEF.dbgDrawPhyfield) {
//					CGame.spriteLoad(DSpriteID.PHYSICAL, DATA.PACK_TILESET, DATA.TILESET_PHYSICAL, true, false);
//				}

			Pack_Close();
			
			
//				Pack_Open("/" + Integer.toString((DATA.PACK_LEVEL01_1.charAt(1) - '0') + CGame._tempLevelId));
			GLLibPlayer.Tileset_Init(DGUI.SCREEN_WIDTH_FORTILE, DGUI.SCREEN_HEIGHT_FORTILE, DEF.TILE_W, DEF.TILE_H);

			var mapsize;
			var mapdata = null;
			var mapflip = null;
			var id = 10000;

			

			for (var i = 0; i < GLLibConfig.tileset_maxLayerCount; i++) {
				if (i == 0) {// Start Load BTM and BTM2 from Castle Levels(4th level for each world)
					var packFile = (DATA.PACK_LEVEL01_B.charAt(1) - '0') * 10  + (DATA.PACK_LEVEL01_B.charAt(2) - '0');
						if (CGame._tempLevelId > DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
							packFile += DAI.WORLD_ID_PIRATE;
						} else if (CGame._tempLevelId > DAI.LEVELS_NUM_PRE_WORLD * DAI.WORLD_ID_CASTLE) {
							packFile += CGame._tempLevelId - DAI.LEVELS_NUM_PRE_WORLD * DAI.WORLD_ID_CASTLE - 1;
						} else {
							packFile += Math.floor(CGame._tempLevelId / DAI.LEVELS_NUM_PRE_WORLD);
						}
						Pack_Open("/" + packFile);//Integer.toString(packFile));
					} else if (i == 2) {//Load other levels
						Pack_Close();
					var packFile = (DATA.PACK_LEVEL01_1.charAt(1) - '0') + CGame._tempLevelId;
						if (CGame._tempLevelId > DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
							packFile = (DATA.PACK_INTRO_1.charAt(1) - '0') + CGame._tempLevelId - DAI.LEVEL_ID_INTRO_NEW_GAME;
						}
						Pack_Open("/" + packFile);//Integer.toString(packFile));
				}						
				var tiled = CGame.level2Tiled(CGame._tempLevelId, i);
//@#if RemoveTilesetBTM2
				if (tiled == -1 || i == 1) {
//@#else
//@                    if (tiled == -1) {
//@#endif
					continue;
				}

				var tileRepeat = GLLibPlayer.WRAP_CLAMP;
				var useCb = false;
				// if (i == 0) {
					// useCb = true;
				// }
				if (tiled == DClassID.BG_6 - DClassID.BTM) {
					tileRepeat = GLLibPlayer.WRAP_REPEAT;
				}
//					var dataOffset = i * 3;
				var dataOffset;
				if (i > 1) {
					dataOffset = (i - 2) * 3;
				} else {
					dataOffset = i * 3;
				}
				mapsize = Pack_ReadData(dataOffset++);
				mapdata = Pack_ReadData(dataOffset++);
				mapflip = Pack_ReadData(dataOffset++);
				GLLibPlayer.Tileset_LoadLayer(i,
						mapsize,
						mapdata,
						mapflip,
						CGame.spriteArray[tiled + DSpriteID.TILESET_BASE],
						useCb,
						/*GLLib.*/TOP, // set origin on top left
						tileRepeat, tileRepeat);
				GLLibPlayer.Tileset_SetCamera(i, 0, 0);

				if (DClassID.BTM + i == DClassID.BG) {
					CGame._mapTileCountWidth = Mem_GetShort(mapsize, 0);
					CGame._mapTileCountHeight = Mem_GetShort(mapsize, 2);
				}
			}
			CGame._topLayerData = mapdata;
			CGame._topLayerFlip = mapflip;

			break;
		case DLoadState.UNLOAD_TILESET:
			for (var i = 0; i < GLLibConfig.tileset_maxLayerCount; i++) {
				GLLibPlayer.Tileset_Destroy(i);
			}
			CGame._topLayerData = null;
			CGame._topLayerFlip = null;
			break;

		case DLoadState.LOAD_ENTITY:
			if (DEF.dbgEnable) Dbg("loading entities");
			CGame.LoadLevelData(DATA.LEVEL01_1_DESIGN);
			CGame.InitTraceAreas();
			CGame.InitCamera();
			CEntity.MonsterchestInitHP();
			CGame._entityMaxId = DYNAMIC_TILE_ID;
			for (var i = 0; i < GLLibConfig.tileset_maxLayerCount; i++) {
				var params = LowAPI.Gen_Array([DParamIndex.ANIMID + 1], 0);//new short[DParamIndex.ANIMID + 1];
				params[DParamIndex.ID] = CGame._entityMaxId++;
				params[DParamIndex.CLASS_ID] = (DClassID.BTM + i);
				params[DParamIndex.FLAGS] = DFlags.FIXED;
					CGame._entitiesRowTable.put(params[DParamIndex.ID], params);//(new Integer(params[DParamIndex.ID]), params);
				CGame._entitiesRowData[CGame._entityRowDataCount++] = params;
			}
			CGame.LoadCinematics(Pack_ReadData(DATA.LEVEL01_1_CINEMATICS));
			Pack_Close();
			break;
		case DLoadState.UNLOAD_ENTITY:
			CEntity.RemoveAll();
			CGame._entitiesRowTable.clear();
			CGame._entitiesRowData = null;
			break;
//@#if not SimplePhysics
		case DLoadState.LOAD_SEGMENT:
			Pack_Open(DATA.PACK_SEGMENT);
			var buffer = Pack_ReadData(CGame._tempLevelId);
			var offset = 0;
			var count = Mem_GetShort(buffer, offset);
			CGame._segmentCount = count;
			offset += 2;
			var paramCount = Mem_GetShort(buffer, offset);
			offset += 2;
			CGame._segments = LowAPI.Gen_Array([count + 500], null);//new int[count + 500][];
			CGame._segmentParams = LowAPI.Gen_Array([count + 500], 0);//new int[count + 500];
			CGame._segmentAngles = LowAPI.Gen_Array([count + 500], null);//new int[count + 500][];
			CGame._entityMaxId = DYNAMIC_SEGMENT_ID;
			for (var i = 0; i < count; i++) {
				for (var j = 0; j < paramCount; j++) { // only one param
					CGame._segmentParams[i] = Mem_GetShort(buffer, offset);
					offset += 2;
				}
				var pointCount = Mem_GetShort(buffer, offset);
				offset += 2;
				CGame._segmentAngles[i] = LowAPI.Gen_Array([pointCount - 1], 0);//new var[pointCount - 1];
				pointCount <<= 1;
				CGame._segments[i] = LowAPI.Gen_Array([pointCount], 0);//new var[pointCount];
				var posx = 0;
				var posy = 0;
				var left = Number.MAX_VALUE;
				var right = Number.MIN_VALUE;
				var top = Number.MAX_VALUE;
				var bottom = Number.MIN_VALUE;
				for (var j = 0; j < pointCount; j += 2) {
					var x = Mem_GetShort(buffer, offset);
					offset += 2;
					var y = Mem_GetShort(buffer, offset);
					offset += 2;
					if (j == 0) {
						posx = x;
						posy = y;
					}

					left = Math.min(x, left);
					right = Math.max(x, right);
					CGame._segments[i][j] = (x - posx) << DEF.SHIFT;

					top = Math.min(y, top);
					bottom = Math.max(y, bottom);
					CGame._segments[i][j + 1] = (y - posy) << DEF.SHIFT;

					var lineIndex = (j - 2 + j) >> 2;
					if (lineIndex >= 0) {
						var angle = Math_Atan(CGame._segments[i][j] - CGame._segments[i][j - 2], CGame._segments[i][j + 1] - CGame._segments[i][j - 1]);
						CGame._segmentAngles[i][lineIndex] = angle; // only acute angle
					}
				}
//					if (povarCount > 0 && CGame._segments[i][0] > CGame._segments[i][CGame._segments[i].length - 2]) {
//						// reverse segment
//						var begin = 0;
//						var end = CGame._segments[i].length - 2;
//						var tempX, tempY;
//						while (end > begin) {
//							tempX = CGame._segments[i][begin];
//							tempY = CGame._segments[i][begin + 1];
//							CGame._segments[i][begin] = CGame._segments[i][end];
//							CGame._segments[i][begin + 1] = CGame._segments[i][end + 1];
//							CGame._segments[i][end] = tempX;
//							CGame._segments[i][end + 1] = tempY;
//							begin += 2;
//							end -= 2;
//						}
//						begin = 0;
//						end = CGame._segmentAngles[i].length - 1;
//						var temp;
//						while (end > begin) {
//							temp = CGame._segmentAngles[i][begin];
//							CGame._segmentAngles[i][begin] = (CGame._segmentAngles[i][end] + Math_Angle180) & 0xFF;
//							CGame._segmentAngles[i][end] = (temp + Math_Angle180) & 0xFF;
//							begin++;
//							end--;
//						}
//					}
				var params = LowAPI.Gen_Array([DParamIndex.SEGMENT_HEIGHT + 1], 0);//new short[DParamIndex.SEGMENT_HEIGHT + 1];
				params[DParamIndex.CLASS_ID] = DClassID.SEGMENT;
				params[DParamIndex.ID] = CGame._entityMaxId++;
				params[DParamIndex.POSX] = posx;
				params[DParamIndex.POSY] = posy;
				params[DParamIndex.FLAGS] = (DFlags.FIXED | DFlags.NO_UPDATE_AI);
				params[DParamIndex.EX_FLAGS] = DFlags.EX_SEGMENT;
				params[DParamIndex.SEGMENT_SEGMENT_ID] = i;
				params[DParamIndex.SEGMENT_LEFT] = (left - posx - 1);
				params[DParamIndex.SEGMENT_TOP] = (top - posy - 1);
				params[DParamIndex.SEGMENT_WIDTH] = (right - left + 2);
				params[DParamIndex.SEGMENT_HEIGHT] = (bottom - top + 2);
				params[DParamIndex.SEGMENT_WIDTH] = Math.max(params[DParamIndex.SEGMENT_WIDTH], 1);
				params[DParamIndex.SEGMENT_HEIGHT] = Math.max(params[DParamIndex.SEGMENT_HEIGHT], 1);
				CGame._entitiesRowTable.put(params[DParamIndex.ID], params);//(new Integer(params[DParamIndex.ID]), params);
				CGame._entitiesRowData[CGame._entityRowDataCount++] = params;

			}
			CGame._entityMaxId = DYNAMIC_ENTITY_ID;
			Pack_Close();
			break;

		case DLoadState.UNLOAD_SEGMENT:
			CGame._segments = null;
			CGame._segmentAngles = null;
			CGame._segmentParams = null;
			CGame._segmentCount = 0;
			break;
//@#endif
			// load - unload sprite
		case DLoadState.LOAD_SPRITE:
		{
			if (DEF.dbgEnable) Dbg("loading sprites");
			Pack_Open(DATA.PACK_SPRITE);
			for (var i = 0; i < DATA.SPRITE_MAX; i++) {
				if ((CGame._sprites_load_mask & (1 << i)) != 0 && CGame.spriteArray[i] == null) {
//@#if BREW_CacheAllSprite
//@						if (i == DATA.SPRITE_HERO)// || i == DATA.SPRITE_OBJ_BALANCE)
//@						{
//@							CGame.spriteLoad(i, i, true, true);
//@						}
//@						else if(i == DATA.SPRITE_SPAWN_POINT || i == DATA.SPRITE_MAP_ACTOR || i == DATA.SPRITE_OBJ_WAVE || i == DATA.SPRITE_OBJ_BALANCE)
//@						{
//@							CGame.spriteLoad(i, i, false, true);
//@						}
//@						else
//@						{
//@							CGame.spriteLoad(i, i, true, false);
//@						}
//@#else // BREW_CacheAllSprite
						if( CGame._optimizeSprite.indexOf(i) > -1) continue;
						if (DEF.dbgEnable) Dbg("loading sprite id : ----------------------------- " + i);
                        // if( i == DATA.SPRITE_INTERFACE ){
							// CGame.spriteArray[i] = CGame._interface;//CGame.spriteLoad(i, i, true, false);
						// }else
						CGame.spriteLoad(i, i, true, true);//CGame.spriteLoad(i, i, false, true);
//@#endif // BREW_CacheAllSprite
				} else if ((i == DATA.SPRITE_HINT || i == DATA.SPRITE_BONUS || i == DATA.SPRITE_STONE) && CGame.spriteArray[i] == null) {
					if (DEF.dbgEnable) Dbg("loading missing sprite id : ----------------------------- " + i);
					CGame.spriteLoad(i, i, true, true);
				}
			}

			Pack_Close();
//@#if not RemoveModuleMap
			if (CGame.spriteArray[DSpriteID.MOBS_WHITE] != null) {
				Pack_Open(DATA.PACK_MODULE_MAP);
				for (var i = 0; i < DATA.MODULE_MAP_MAX; i++) {
					CGame.spriteArray[DSpriteID.MOBS_WHITE].SetModuleMapping(i, Pack_ReadData(i));
				}
				Pack_Close();
			}

			if (CGame.spriteArray[DSpriteID.MOBS_FLY] != null) {
				Pack_Open(DATA.PACK_MODULE_MAP_FLY);
				for (var i = 0; i < DATA.MODULE_MAP_FLY_MAX; i++) {
					CGame.spriteArray[DSpriteID.MOBS_FLY].SetModuleMapping(i, Pack_ReadData(i));
				}
				Pack_Close();
			}
			
			if (CGame.spriteArray[DSpriteID.BOSS_OCTOPUS] != null) {
				Pack_Open(DATA.PACK_MODULE_MAP_BOSS_OCTOPUS);
				for (var i = 0; i < DATA.MODULE_MAP_BOSS_OCTOPUS_MAX; i++) {
					CGame.spriteArray[DSpriteID.BOSS_OCTOPUS].SetModuleMapping(i, Pack_ReadData(i));
				}
				Pack_Close();
			}

			if (CGame.spriteArray[DSpriteID.HERO] != null) {
				Pack_Open(DATA.PACK_MODULE_MAP_HERO);
				for (var i = 0; i < DATA.MODULE_MAP_HERO_MAX; i++) {
					CGame.spriteArray[DSpriteID.HERO].SetModuleMapping(i, Pack_ReadData(i));
				}
				Pack_Close();
			}
			if (CGame.spriteArray[DSpriteID.MAP_ACTOR] != null) {
				CGame.CreateAlphaPalette(CGame.spriteArray[DSpriteID.MAP_ACTOR], 0, CGame.MINI_MAP_ALPHA_PAL, 0xFF, false);
			}
//@#endif
		}
		break;
		case DLoadState.UNLOAD_SPRITE:
		{
			if (DEF.dbgEnable) Dbg("UNLOAD_SPRITE *************");
			for (var i = 0; i < CGame.spriteArray.length; i++) {
				// CGame.spriteArray[i] = null;
				CGame.spriteUnLoad(i);
			}
		}
		break;
//@#if not RemoveBlendEffect
		case DLoadState.LOAD_EFFECT:
		{
			CGame.CreateSpriteEffect();
			
/*//@#if CacheSpriteForOptimize
			for (var i = 0; i < DATA.SPRITE_MAX; i++) {
				if ((CGame._sprites_load_mask & (1 << i)) != 0) {
					if( i == DATA.SPRITE_HERO )
					{
						Dbg(" Reload ====================================== SPRITE_HERO ");
						CGame.spriteArray[i].BuildCacheImages(0, 0, -1, -1);
//@	#if CacheHeroSpriteForN73						
//@							CGame.spriteArray[i].BuildCacheImages(4, 0, 100, -1);
//@							CGame.spriteArray[i].BuildCacheImages(1, 225, 260, -1);
//@							CGame.spriteArray[i].BuildCacheImages(2, 225, 260, -1);						
//@							for (int j = 0; j < CGame._entityRowDataCount; j++) {
//@								short[] params = CGame._entitiesRowData[j];
//@								if (params[DParamIndex.CLASS_ID] == DClassID.HINT)
//@								{
//@									int hero_frame = params[DParamIndex.HINT_HERO_FRAME];
//@									if( hero_frame >= 0 )
//@									    CGame.spriteArray[i].BuildFrameCacheImages(5,hero_frame);
//@								}
//@							}
//@	#endif
					}
					else
					{
						// Sprite interface was loaded already !!!!!!!!!!!!!!!!!!!!!
						if( i == DATA.SPRITE_INTERFACE ) continue;// Dbg("LOAD_EFFECT SPRITE_INTERFACE 122222222222222222222222222222222222");
                        
						if (CGame.spriteArray[i] == null){
							// Pack_Open(DATA.PACK_SPRITE);
							Dbg(" Reload ====================================== i " + i); // i == 33 is null.
							// CGame.spriteLoad(i, i, false, true);
							// Pack_Close();
						} else {
							for( var j = 0 ; j < CGame.spriteArray[i]._palettes ; j ++)
								CGame.spriteArray[i].BuildCacheImages(j, 0, -1, -1);
							CGame.spriteArray[i].FreeCacheData();
						}
						
					}
				}
			}
//@#endif*/
//@#if catchOctopusBoss
//@				                for (int i = 0; i < DATA.SPRITE_MAX; i++) {
//@									if ((CGame._sprites_load_mask & (1l << i)) != 0) {
//@										if( i == DATA.SPRITE_BOSS_OCTOPUS )
//@										{
//@										    for( int j = 0 ; j < CGame.spriteArray[i]._palettes ; j ++)
//@										    CGame.spriteArray[i].BuildCacheImages(j, 19, 28, -1);
//@										}
//@									}
//@								}
//@#endif
			CGame.blendSpriteArray = LowAPI.Gen_Array([DATA.EFFECT_MAX], null);//new CBlendSprite[DATA.EFFECT_MAX];
			Pack_Open(DATA.PACK_EFFECT);
			for (var i = 0; i < DATA.EFFECT_MAX; i++) {
				// CGame.blendSpriteArray[i] = new CBlendSprite();
				// CGame.blendSpriteArray[i].Load(Pack_ReadData(i), 0);
				if (DEF.dbgEnable) Dbg("loading effect -------------------------------");
				CGame.blendSpriteArray[i] = CGame.LoadSprite4(i, -1, true, false);

			}
//				CGame.blendSpriteArray[DATA.EFFECT_SPLASH]._blend = CBlendSprite.BLEND_DISPLACEMENT;
//
//				CGame.blendSpriteArray[DATA.EFFECT_BLOOD].ModifyPalette(0, 0xFF0000);
//
//				CGame.blendSpriteArray[DATA.EFFECT_DUST].ModifyPalette(0, 0xFFFFFF);
//
//				CGame.blendSpriteArray[DATA.EFFECT_HITWAVE]._blend = CBlendSprite.BLEND_DISPLACEMENT;
//
//				CGame.blendSpriteArray[DATA.EFFECT_MARK_SHAPES]._blend = CBlendSprite.BLEND_ADDITIVE;
//
//				CGame.blendSpriteArray[DATA.EFFECT_SWARM]._blend = CBlendSprite.BLEND_DISPLACEMENT;

//				CGame.blendSpriteArray[DATA.EFFECT_RAIN]._blend = CBlendSprite.BLEND_DISPLACEMENT;

			CGame.blendSpriteArray[DATA.EFFECT_SPAWN]._blend = CBlendSprite.BLEND_DISPLACEMENT;
			CGame.blendSpriteArray[DATA.EFFECT_SPAWN].ModifyPalette(1, 0x5A1758);
			CGame.blendSpriteArray[DATA.EFFECT_SPAWN].ModifyPalette(2, 0x080598);
			CGame.ApplyModifyPalette(CGame.blendSpriteArray[DATA.EFFECT_SPAWN], [1,2]);
			
			CGame.blendSpriteArray[DATA.EFFECT_ATMOSPHERE].ModifyPalette(0, 0xff4040);
			CGame.blendSpriteArray[DATA.EFFECT_ATMOSPHERE].ModifyPalette(1, 0x3c84ef);
			CGame.ApplyModifyPalette(CGame.blendSpriteArray[DATA.EFFECT_ATMOSPHERE], [0,1]);
//@#if not RemoveEffectInk
//@				CGame.blendSpriteArray[DATA.EFFECT_INK].ModifyPalette(0, 0x000000);
//@#endif
			for (var i = 0; i < CGame.spriteArray.length; i++) {
				if (CGame.spriteArray[i] != null) {
					CGame.spriteArray[i].SetPool(1);
				}
			}
		}
		break;
		case DLoadState.UNLOAD_EFFECT:
		{
			CGame.blendSpriteArray = null;
		}
		break;
//@#endif
		// load/unload sound
		case DLoadState.LOAD_SOUND:
		{
			if (DEF.dbgEnable) Dbg("init sound engine");
			// init sound engine with 2 channel

			if (DEF.dbgEnable) Dbg("load some sound");
			// load some sound from pack file
			for (var i = 0; i < DATA.SOUND_MAX; i++) {
				if(GLLibConfiguration.sound_allowURLCreation)
				{
					var name = CGame.getSoundName(i);
					var url = window.location.href.split("index")[0] + "/js/sounds/MP3/" + name;//cheat here!
					var mime = "audio/mpeg";//cheat here!
					GLLibPlayer.Snd_LoadSound (url , mime, i, true); 
				} else
					GLLibPlayer.Snd_LoadSound(DATA.PACK_SOUND, i);
			}
		}
		break;
		case DLoadState.UNLOAD_SOUND:
		{
			if (DEF.dbgEnable) Dbg("unload some sound -------------------------");
			for (var i = 0; i < DATA.SOUND_MAX; i++) {
				GLLibPlayer.Snd_UnLoadSound(i);
			}
			GLLibPlayer.Snd_Quit();
		}
		break;
	}
	loading_Phase++;
//@#if UseGCLoading
//@		System.gc();
//@#endif
	return loading_Phase;
}



CGame.getSoundName = function(index)
{
	var name = null;
	switch(index)
	{
			case DATA.SOUND_HERO_HURT : 
				name = "sfx_hero_hurt.mp3";
				break;
			case DATA.SOUND_MAGIC_ATTACK : 
				name = "sfx_magic_attack.mp3";
			break;
			case DATA.SOUND_HIT_ENEMY : 
				name = "sfx_hit_enemy.mp3";
			break;
			case DATA.SOUND_MENU_CONFIRM : 
				name = "sfx_menu_confirm.mp3";
			break;
			case DATA.SOUND_STONE_BREAK : 
				name = "sfx_stone_break.mp3";
			break;
			case DATA.SOUND_TRANSFORM : 
				name = "sfx_transform.mp3";
			break;
			case DATA.SOUND_HIDDEN_BONUS : 
				name = "sfx_hidden_bonus.mp3";
			break;
			case DATA.SOUND_BGM_LOSE : 
				name = "m_lose.mp3";
			break;
			case DATA.SOUND_BGM_LEVEL_CLEAR : 
				name = "m_level_clear.mp3";
			break;
			case DATA.SOUND_BGM_TITLE : 
				name = "m_title.mp3";
			break;
			case DATA.SOUND_BGM_STAGE_CHOOSE : 
				name = "m_stage_choose.mp3";
			break;
			case DATA.SOUND_BGM_LABYRINTH_LEVEL : 
				name = "m_bgm_01.mp3";
			break;
			case DATA.SOUND_BGM_BOSS_FIGHT 	: 
				name = "m_boss_fight.mp3";
			break;
			case DATA.SOUND_BGM_CUTSCENE_STORY 	: 
				name = "m_cutscene_story.mp3";
			break;
			case DATA.SOUND_BGM_MAIN_MENU : 
				name = "m_menu.mp3";
			break;
			case DATA.SOUND_BGM_01 	: 
				name = "m_bgm_01.mp3";
			break;
			case DATA.SOUND_BGM_02 	: 
				name = "m_bgm_02.mp3";
			break;

	}
	return name;
}
/**
*
* Must apply this function after modify palette.
* @param spr : sprite.
* @param pal : list palette need apply.
*/
CGame.ApplyModifyPalette = function (spr, pals) {
	for (var i = 0; i < pals.length; i ++){
		spr.BuildCacheImages(pals[i], 0, -1, -1);
	}
	spr.PushCacheImagesToGL();	
}

CGame.CreateAlphaPalette = function(spr, srcPal, destPal, alpha, makeBlue) {
	if( GLLibConfig.sprite_useNokiaUI )
	{
		var srcData = spr._pal_short[0][srcPal];
		var destData = LowAPI.Gen_Array([srcData.length], 0);//new short[srcData.length];
		System.arraycopy(srcData, 0, destData, 0, destData.length);
		spr._pal_short[0][destPal] = destData;
	}
	else
	{
		var srcData = spr._pal_int[0][srcPal];
		var destData = LowAPI.Gen_Array([srcData.length], 0);//new var[srcData.length];
		System.arraycopy(srcData, 0, destData, 0, destData.length);
		spr._pal_int[0][destPal] = destData;
	}
	// MUST INCREASE _palettes HERE !!!!!!!!!!!!!!!
	spr._palettes++;
	if (makeBlue) {
		if (GLLibConfig.sprite_useNokiaUI)
		{
			spr._pal_short[0][destPal] = LowAPI.Gen_Array([spr._pal_short[0][ srcPal ].length], 0);//new short[spr._pal_short[0][ srcPal ].length];
			alpha = (alpha>>4) & 0xFF;

			for( var i = 0; i < spr._pal_short[0][ srcPal ].length;i++)
			{
				if( (spr._pal_short[0][ srcPal ][ srcPal ] & 0x0fff) != 0x0f0f )
					spr._pal_short[0][ destPal ][ i ] = ( ( (alpha & 0xf) << 12) | (spr._pal_short[0][srcPal][i] &0x0fff) | alpha);
			}
		}
		else
		{
			spr._pal_int[0][destPal] = LowAPI.Gen_Array([spr._pal_int[0][ srcPal ].length], 0);//new var[spr._pal_int[ srcPal ].length];
			alpha = alpha & 0xFF;
			for ( var i = 0; i < spr._pal_int[0][ srcPal ].length; i++ )
			{
				if((spr._pal_int[0][ srcPal ][ i ] & 0xFF000000 ) != 0 && (spr._pal_int[0][ srcPal ][ i ] & 0xFFFFFF ) != 0xFF00FF )
					spr._pal_int[0][ destPal ][ i ] = ( ( ( alpha ) << 24 ) | ( spr._pal_int[0][ srcPal ][ i ] & 0x00FFFFFF ) | alpha);
			}
		}
	} else {
		spr.ModifyPaletteAlpha(destPal, alpha);
	}
	
	// ******************************************
	// !!! Use cache image when create an palette.	
	var isCacheFrames = false;
	if (isCacheFrames) {
		spr.BuildCacheImages (destPal , 0 , - 1 , - 1 );
		spr.BuildCacheFrames(destPal, 0 , - 1 );
		spr.PushCacheFramesToGL();
	} else {
		spr.BuildCacheImages(destPal, 0, -1, -1);
		spr.PushCacheImagesToGL( );
	}
	
}
// -----------------------------------------------------------------------------------------------------------------------------------------
// XPLAYER

CGame.LoadLevelData = function(dataIndex) {
	var buffer;
	buffer = Pack_ReadData(dataIndex);
	var length = buffer.length;
	var offset = 0;
	while (offset < length) {
		var nParams = (buffer[offset++] & 0xff);
		var params = LowAPI.Gen_Array([nParams], 0);//new short[nParams];
		for (var i = 0; i < nParams; i++) {
			params[i] = Mem_GetShort(buffer, offset);
			offset += 2;
		}
			CGame._entitiesRowTable.put(params[DParamIndex.ID], params);//(new Integer(params[DParamIndex.ID]), params);
		CGame._entitiesRowData[CGame._entityRowDataCount++] = params;
		var spriteId = CEntity.InitSprite(params);
		CGame._sprites_load_mask |= CEntity.GetSpriteLoadMask(spriteId);
	}
}

CGame.InitCamera = function() {
	for (var i = 0; i < CGame._entityRowDataCount; i++) {
		var params = CGame._entitiesRowData[i];
		if (params[DParamIndex.CLASS_ID] == DClassID.CAMERA) {
			if (params[DParamIndex.CAMERA_WIDTH] == DEF.DESIGN_SCR_W) {
				params[DParamIndex.POSX] -= (DEF.SCR_W - DEF.DESIGN_SCR_W) / 2;
				params[DParamIndex.POSX] = Math.max(0, params[DParamIndex.POSX]);
				params[DParamIndex.POSX] = Math.min(CGame._mapTileCountWidth * DEF.TILE_W - DEF.SCR_W, params[DParamIndex.POSX]);
				params[DParamIndex.CAMERA_WIDTH] = DEF.SCR_W;
			}
			if (params[DParamIndex.CAMERA_HEIGHT] == DEF.DESIGN_SCR_H) {
				params[DParamIndex.POSY] -= (DEF.SCR_H - DEF.DESIGN_SCR_H) / 2;
				params[DParamIndex.POSY] = Math.max(0, params[DParamIndex.POSY]);
				params[DParamIndex.POSY] = Math.min(CGame._mapTileCountHeight * DEF.TILE_H - DEF.SCR_H, params[DParamIndex.POSY]);
				params[DParamIndex.CAMERA_HEIGHT] = DEF.SCR_H;
			}
		}
	}
}

CGame.InitTraceAreas = function() {
	for (var i = 0; i < CGame._entityRowDataCount; i++) {
		var params = CGame._entitiesRowData[i];
		var firstIndex = -1;
		var lastIndex = -1;
		if (params[DParamIndex.CLASS_ID] == DClassID.TRACE_RENDER) {
			firstIndex = params[DParamIndex.TRACE_RENDER_FIRST_TRACE];
			lastIndex = params[DParamIndex.TRACE_RENDER_LAST_TRACE];
		} else if (params[DParamIndex.CLASS_ID] == DClassID.PLATFORM) {
			firstIndex = params[DParamIndex.PLATFORM_TRACE];
		} else if (params[DParamIndex.CLASS_ID] == DClassID.ROLLING_PLATFORM) {
			firstIndex = params[DParamIndex.ROLLING_PLATFORM_TRACE];
		} else if (params[DParamIndex.CLASS_ID] == DClassID.OBJ_DAMAGE_STONE) {
			firstIndex = params[DParamIndex.OBJ_DAMAGE_STONE_TRACE];
		} else if (params[DParamIndex.CLASS_ID] == DClassID.MOBS_UFO) {
			firstIndex = params[DParamIndex.MOBS_UFO_TRACE];
		}
		if (firstIndex > 0) {
			var traceIndex = firstIndex;
			var traceData = null;
			var left = Number.MAX_VALUE;
			var right = Number.MIN_VALUE;
			var top = Number.MAX_VALUE;
			var bottom = Number.MIN_VALUE;
			while (traceIndex > 0) {
				traceData = CEntity.GetRowDataByID(traceIndex);
				left = Math.min(left, traceData[DParamIndex.POSX]);
				top = Math.min(top, traceData[DParamIndex.POSY]);
				right = Math.max(right, traceData[DParamIndex.POSX]);
				bottom = Math.max(bottom, traceData[DParamIndex.POSY]);
				if (traceIndex == lastIndex) {
					break;
				}
				traceIndex = traceData[DParamIndex.TRACE_NEXT_TRACE];
				if (traceIndex == firstIndex) {
					break;
				}
			}
			params[DParamIndex.POSX] = left;
			params[DParamIndex.POSY] = top;
			if (params[DParamIndex.CLASS_ID] == DClassID.TRACE_RENDER) {
				params[DParamIndex.TRACE_RENDER_WIDTH] = (right - left);
				params[DParamIndex.TRACE_RENDER_HEIGHT] = (bottom - top);
			} else if (params[DParamIndex.CLASS_ID] == DClassID.PLATFORM) {
				params[DParamIndex.PLATFORM_WIDTH] = (right - left);
				params[DParamIndex.PLATFORM_HEIGHT] = (bottom - top);
			} else if (params[DParamIndex.CLASS_ID] == DClassID.ROLLING_PLATFORM) {
				params[DParamIndex.ROLLING_PLATFORM_WIDTH] = (right - left);
				params[DParamIndex.ROLLING_PLATFORM_HEIGHT] = (bottom - top);
			} else if (params[DParamIndex.CLASS_ID] == DClassID.OBJ_DAMAGE_STONE) {
				params[DParamIndex.OBJ_DAMAGE_STONE_WIDTH] = (right - left);
				params[DParamIndex.OBJ_DAMAGE_STONE_HEIGHT] = (bottom - top);
			} else if (params[DParamIndex.CLASS_ID] == DClassID.MOBS_UFO) {
				params[DParamIndex.MOBS_UFO_WIDTH] = (right - left);
				params[DParamIndex.MOBS_UFO_HEIGHT] = (bottom - top);
			}
		}
	}
}

//@#if BREW_Alpha
//@	var s_brewDrawAlphaFlag = false;
//@	var s_brewCacheAlphaFlag = false;
//@#endif // BREW_Alpha

CGame.CreateSpriteEffect = function() {
	var blueColor;
	var sprite;
	var startPal;
	var srcPal;
	sprite = CGame.spriteArray[DSpriteID.HERO];
	startPal = DAI.HERO_PAL_SHADOW1;
	srcPal = DAI.HERO_PAL_NORMAL;
	for (var k = 0; k < 2; k++) {
		if (k == 1) {
			startPal = DAI.HERO_PAL_POWERUP_SHADOW1;
			srcPal = DAI.HERO_PAL_POWERUP;
		}
		for (var j = startPal; j < startPal + 3; j++) {
			var alpha = 0xAA;
			if (j == startPal + 1) {
				alpha = 0x88;
			} else if (j == startPal + 2) {
				alpha = 0x66;
			}
			CGame.CreateAlphaPalette(sprite, srcPal, j, alpha, true);
		}
	}
	if(CGame.spriteArray[DSpriteID.BOSS_WATCH] != null) {
		sprite = CGame.spriteArray[DSpriteID.BOSS_WATCH];
		startPal = DAI.BOSS_WITCH_PAL_SHADOW1;
		srcPal = DAI.BOSS_WITCH_PAL_NORMAL;
		for (var k = 0; k < 1; k++) {
			for (var j = startPal; j < startPal + DAI.BOSS_WITCH_PAL_SHADOWMAX; j++) {
				var alpha = 0xAA;
				if (j == startPal + 1) {
					alpha = 0x88;
				} else if (j == startPal + 2) {
					alpha = 0x66;
				} else if (j == startPal + 3) {
					alpha = 0x44;
				} else if (j == startPal + 4) {
					alpha = 0x22;
				}
				CGame.CreateAlphaPalette(sprite, srcPal, j, alpha, true);
			}
		}
	}

	if (CGame.spriteArray[DSpriteID.OBJ_WAVE] != null) {
		CGame.spriteArray[DSpriteID.OBJ_WAVE].ModifyPaletteAlpha(0, 0x20);
//			CGame.spriteArray[DSpriteID.OBJ_WAVE].ModifyPaletteAlpha(1, 0xCC);
		CGame.spriteArray[DSpriteID.OBJ_WAVE]._alpha = true;
//@#if BREW_Alpha
//@			s_brewCacheAlphaFlag = true;
//@#endif // BREW_Alpha
		CGame.spriteArray[DSpriteID.OBJ_WAVE].BuildCacheImages(0, 0, -1, -1);
		CGame.spriteArray[DSpriteID.OBJ_WAVE].BuildCacheImages(1, 0, -1, -1);
		CGame.spriteArray[DSpriteID.OBJ_WAVE].PushCacheImagesToGL();
		// CGame.spriteArray[DSpriteID.OBJ_WAVE].FreeCacheData();
//@#if BREW_Alpha
//@			s_brewCacheAlphaFlag = false;
//@#endif // BREW_Alpha
//@#if not SimpleWaterEffect
//@			InitShineEffect();
//@#endif
	}

//@#if not RemoveBalance
	if (CGame.spriteArray[DSpriteID.OBJ_BALANCE] != null) {
		var moduleCount = CGame.spriteArray[DSpriteID.OBJ_BALANCE].GetModuleCount();
		CGame._balanceImageData = LowAPI.Gen_Array([moduleCount], null);//new var[moduleCount][];
		CGame._balanceImageSize = LowAPI.Gen_Array([moduleCount << 1], 0);//new var[moduleCount << 1];
		for (var i = 0; i < CGame.spriteArray[DSpriteID.OBJ_BALANCE].GetModuleCount(); i++) {
			var w = CGame.spriteArray[DSpriteID.OBJ_BALANCE].GetModuleWidth(i);
			var h = CGame.spriteArray[DSpriteID.OBJ_BALANCE].GetModuleHeight(i);
			CGame._balanceImageSize[i << 1] = w;
			CGame._balanceImageSize[(i << 1) + 1] = h;
			CGame._balanceImageData[i] = LowAPI.Gen_Array([w * h], 0);//new var[w * h];
			var imageData = CGame.spriteArray[DSpriteID.OBJ_BALANCE].DecodeImage(i);
			System.arraycopy(imageData, 0, CGame._balanceImageData[i], 0, CGame._balanceImageData[i].length);
		}
	}
//@#endif
//@#if not RemoveIceLevel
//@		if (CGame.spriteArray[DSpriteID.MOBS_YETI] != null) {
//@			CGame.spriteArray[DSpriteID.MOBS_YETI].ModifyPaletteAlpha(1, 0x28);
//@		}
//@#endif
	if (CGame.spriteArray[DSpriteID.FIELD] != null) {
		CGame.spriteArray[DSpriteID.FIELD].ModifyPaletteAlpha(0, 0x88);
	}
}

var DOnlineState = {};
{
	DOnlineState.ENDED = -1;
	DOnlineState.INIT = 1;
	DOnlineState.MENU = 2;
	DOnlineState.TEST_ARENA = 3;

	// online states that require network transmission - use them as consecutive numbers in this order
	DOnlineState.TEST_LOGIN = 20;
	DOnlineState.TEST_SENDINGSCORE = 21;
	DOnlineState.TEST_GETSTATES = 22;
	DOnlineState.TEST_GETRANK = 23;
	DOnlineState.TEST_GETRANK_AROUND_PLAYER = 24;
	DOnlineState.TEST_RATEGAME = 25;
	DOnlineState.TEST_RECOMMENDGAME = 26;

	// online states that don't require a network transmission
	DOnlineState.TEST_REGISTER = 30;
	DOnlineState.TEST_NICK_TAKEN = 31;
	DOnlineState.TEST_DISPLAY_GAME_RATINGS = 32;

	// online error states
	DOnlineState.TEST_CONNECTION_ERROR = 40;
	DOnlineState.TEST_SERVER_ERROR = 41;
};

// every game can have a different score policy :
// every leaderboard can be send separately, or multiple leaderboards can be sent in a single request ..
// each leaderboard can have only one or multiple supplemental data fields ..
// if the leaderboads has supplemental data fields, the score cannot be uploaded unless all the
// supplemental data fields are contained in the request
// this test application contains the demo code for sending one single score wihtout supplemental data,
// one single score for a leaderboard having one supplemental data field, or two leaderboards at the same time,
// wihout or with supplemental data ....
// when varegarating varo a game, keep the code that is appropriate for the leaderboards included in that specific game..
// when using this test application, make sure you set the scoring policy according to the leaderboard settings that
// correspond to the GGI you are using, otherwise the request will fail ..
var ScoreSendingPolicies = {};
{
	ScoreSendingPolicies.SINGLE_SCORE = 0;
	ScoreSendingPolicies.SINGLE_SCORE_SUPPLEMENTAL_DATA = 1;
	ScoreSendingPolicies.MULTIPLE_SCORE = 2;
	ScoreSendingPolicies.MULTIPLE_SCORE_SUPPLEMENTAL_DATA = 3;
};

CGame.currentScoreSendingPolicy = ScoreSendingPolicies.
	SINGLE_SCORE;

// if this is true, the leaderboard and "my states" data is taken from the vareractive class using single functions
// that receive fake array arguments to emulate C style "pass by reference" arguments ..
// this reduces the number of functions, thus package size, but may have an impact on code readability and speed
// use it only if facing package space limitations
CGame.USE_CONDENSED_VERSION = false;

// when sending a request to the server, there are 4 substates :
var DOnlineSubstate = {};
{
	DOnlineSubstate.SET = 0; // the request is composed and sent
	DOnlineSubstate.WAIT = 1; // the request is pending, waiting for answer from server
	DOnlineSubstate.PROCESS = 2; // the request answer is processed
	DOnlineSubstate.DISPLAY = 3; // the result is displayed on screen .. this part is not used for some of the requests
};
CGame.vareractiv = null;

var options =
	[
		TEXT.MENU_XPLAYER_GAMELOFT_LIVE,
		TEXT.MENU_XPLAYER_PLAY,
	];

//private var STR_GAMELOFT_TESTS = "Main Menu";
//private var STR_PRESS_5 = "Press 5 to continue";
//private var STR_OK = "OK";
//private var STR_CANCEL = "CANCEL";

CGame.MENU_STATE_TEST_ARENA = 0;
CGame.MENU_STATE_EXIT = 1;

var actions =
	[
		TEXT.MENU_XPLAYER_SEND_SCORE,
		TEXT.MENU_XPLAYER_GET_TOP_PLAYERS,
		TEXT.MENU_XPLAYER_GET_RANKING,
		TEXT.MENU_XPLAYER_MY_STATS,
		TEXT.MENU_XPLAYER_RATE_GAME,
		TEXT.MENU_XPLAYER_RECOMMEND_GAME,
		TEXT.MENU_XPLAYER_VISIT_GAME_LOBBY,
	];

 var ACTION_NUMBER = actions.length;

var ratings =
	[
		TEXT.MENU_XPLAYER_ROOT_CANAL,
		TEXT.MENU_XPLAYER_GARBAGE,
		TEXT.MENU_XPLAYER_AWFUL,
			TEXT.MENU_XPLAYER_DISAPPOINTING,
		TEXT.MENU_XPLAYER_AVERAGE,
		TEXT.MENU_XPLAYER_GOOD,
		TEXT.MENU_XPLAYER_GREAT,
		TEXT.MENU_XPLAYER_EXCELLENT,
		TEXT.MENU_XPLAYER_OUTSTANDING,
		TEXT.MENU_XPLAYER_THE_BEST,
	];

var RATING_NUMBER = ratings.length;

var redrawBK = true;
var crtChar = 0;
var entryData = "";
var lastKeyPressed = 0;
var lastKeyIndex = 0;
var lastKeyTime = 0;
CGame.keymap =
	[
		[
			'0'],
		[
			'_', '1'],
		[
			'A', 'B', 'C', '2'],
		[
			'D', 'E', 'F', '3'],
		[
			'G', 'H', 'I', '4'],
		[
			'J', 'K', 'L', '5'],
		[
			'M', 'N', 'O', '6'],
		[
			'P', 'Q', 'R', 'S', '7'],
		[
			'T', 'U', 'V', '8'],
		[
			'W', 'X', 'Y', 'Z', '9']
		];

var selectedAction = 0;
var TOTAL_MENU_ITEMS = 2;
var _onlineState = 1;

var _online_substate = 0;
var _menustate = 0;
var _ratestate = 0;
var _keycode = -1;
var _errCode = -1;

// if this is true, the starting game login is in progress ..
var is_initial_login = true;

//@#if TOUCH_SCREEN
//@@    touchScreen.h
var pointerPosX = 0;
var pointerPosY = 0;
var pointerHeldX = 0;
var pointerHeldY = 0;
var pointerDragX = 0;
var pointerDragY = 0;
var translated_keyCode = -256;
var s_cursorAnim = null;


CGame.prototype.pointerPressed = function(x, y)
{
	// x = (x*GAME_SIZE_X)/REAL_SCREEN_W;
	// 	y = (y*GAME_SIZE_Y)/REAL_SCREEN_H;
		
		pointerPosX = x;
		pointerPosY = y;
		pointerHeldX = x;
		pointerHeldY = y;
		pointerDragX = x;
		pointerDragY = y;
		if (DEF.dbgEnable) Dbg("called Pressed  pointerPosX : "  + pointerPosX +  "  pointerPosY : " + pointerPosY);
		// IGP.updatePointerPressed(x, y);
}
CGame.prototype.pointerDragged = function(x, y)
{
	// x = (x*GAME_SIZE_X)/REAL_SCREEN_W;
	// 	y = (y*GAME_SIZE_Y)/REAL_SCREEN_H;
		if (DEF.dbgEnable) Dbg("called Dragged.");

		pointerDragX = x;
		pointerDragY = y;
		// IGP.updatePointerDragged(x, y);
	
}
CGame.prototype.pointerReleased = function(x, y)
 {
	// x = (x*GAME_SIZE_X)/REAL_SCREEN_W;
	// 	y = (y*GAME_SIZE_Y)/REAL_SCREEN_H;
		 if (DEF.dbgEnable) Dbg("called Released.");
			pointerPosX = -1000;
			pointerPosY = -1000;
			pointerHeldX = -1000;
			pointerHeldY = -1000;
			pointerDragX = -1000;
			pointerDragY = -1000;
		// IGP.updatePointerReleased(x, y);
			ResetKey();///*GLLib.*/ResetKey();
//			if (/*GLLib.*/s_keyState[4] != 0)
//				Dbg("!!");
//			Dbg(translated_keyCode);
//			this.keyReleased(translated_keyCode);//temporary key will be released here.
//	        translated_keyCode = -256;
		// cGame.ClearKey();
 }

 CGame.isPointInRect = function( x,  y,  w,  h)
{
		return CGame.isPointInRectAbs(x, y, x+w, y+h);
}

CGame.isPointInRectAbs = function( x1, y1, x2, y2)
{
	//debug
	if (DEF.dbgEnableTouchBox)
	{
		g.setColor(0xff0000);
		g.drawRect(x1, y1, x2-x1, y2-y1);
	}
	
		return (pointerPosX > x1 && pointerPosY >y1 && pointerPosX < x2 && pointerPosY < y2)	;
}
CGame.isPointHoldInRect = function( x, y, w, h)
{
		return CGame.isPointHoldInRectAbs(x, y, x+w, y+h);
}

CGame.isPointHoldInRectAbs  = function(x1, y1, x2, y2)
{
		return (pointerHeldX > x1 && pointerHeldY >y1 && pointerHeldX < x2 && pointerHeldY < y2)	;
}
CGame.isPointInRect_FixedPoint = function(x, y, w, h) 
{
    	return CGame.isPointInRect(Math_FixedPointToInt(x - CEntity._camX), Math_FixedPointToInt(y - CEntity._camY), Math_FixedPointToInt(w), Math_FixedPointToInt(h));
}

CGame.isPointInRectAbs_FixedPoint = function(x, y, x1, y1) 
{
    	return CGame.isPointInRectAbs(Math_FixedPointToInt(x - CEntity._camX), Math_FixedPointToInt(y - CEntity._camY), 
    			Math_FixedPointToInt(x1 - CEntity._camX), Math_FixedPointToInt(y1 - CEntity._camY));
}

//@#if not UseCommandBar
CGame.prototype.detectSoftKeys = function()
{

	if (s_game_state == STATE.GAMEPLAY_UPDATE && !CGame.InCinemitic())
		{
			if (CGame.isPointInRect(0, DEF.SCR_H - TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, TOUCH_SOFTKEY_GAMEPLAY_WIDTH, TOUCH_SOFTKEY_GAMEPLAY_HEIGHT))
			{
				this.keyPressed(GLLibConfig.keycodeLeftSoftkey);
				this.keyReleased(GLLibConfig.keycodeLeftSoftkey);
			}
			if (CGame.isPointInRect(DEF.SCR_W - TOUCH_SOFTKEY_GAMEPLAY_WIDTH, DEF.SCR_H - TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, TOUCH_SOFTKEY_GAMEPLAY_WIDTH, TOUCH_SOFTKEY_GAMEPLAY_HEIGHT))
			{
				this.keyPressed(GLLibConfig.keycodeRightSoftkey);
				this.keyReleased(GLLibConfig.keycodeRightSoftkey);
			}
		
		}
		else
		{
			if (CGame.isPointInRect(0, DEF.SCR_H- TOUCH_SOFTKEY_MENU_HEIGHT, TOUCH_SOFTKEY_MENU_WIDTH, TOUCH_SOFTKEY_MENU_HEIGHT))
			{
				if(s_game_state == STATE.GAMEPLAY_UPDATE ||  s_game_state == STATE.MENU_HELP || s_game_state == STATE.MENU_MAP) //bugID 9736143
				{
					this.keyPressed(GLLibConfig.keycodeLeftSoftkey);
					this.keyReleased(GLLibConfig.keycodeLeftSoftkey);
				}
			}
			if (CGame.isPointInRect(DEF.SCR_W - TOUCH_SOFTKEY_MENU_WIDTH, DEF.SCR_H- TOUCH_SOFTKEY_MENU_HEIGHT, TOUCH_SOFTKEY_MENU_WIDTH, TOUCH_SOFTKEY_MENU_HEIGHT))
			{
				this.keyPressed(GLLibConfig.keycodeRightSoftkey);
				this.keyReleased(GLLibConfig.keycodeRightSoftkey);
			}
		}

}
//@#endif

CGame.prototype.ClearPointer = function()
{
			pointerPosX = -1000;
			pointerPosY = -1000;
			pointerDragX = -1000;
			pointerDragY = -1000;
}

CGame.isAnyPointPressed = function()
{
		return !(pointerPosX == -1000 && pointerPosY == -1000);
}

//@#if UseOutScreenButton
//@    var F490VHeight = 432;
//@#endif    

CGame.s_isEnemyPointed = false; 
CGame.prototype.UpdatePointerEvents = function( isEnd) 	
{
	if (isEnd)//after all game updated
	{
		if (s_game_state == STATE.GAMEPLAY_UPDATE)
		{
			var box;

//				SetColor(0x333333);
//				FillRoundRect(softkeyWidth, DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, DEF.SCR_W - (softkeyWidth<<1), TOUCH_SOFTKEY_GAMEPLAY_HEIGHT , 10, 10);
//				SetColor(0xcccccc);
//				FillRoundRect(softkeyWidth - 1, DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT -1, DEF.SCR_W - (softkeyWidth<<1)-1, TOUCH_SOFTKEY_GAMEPLAY_HEIGHT -1, 10, 10);
//				fontSprBig.SetCurrentPalette(0);
//				fontSprBig.DrawString(g, "OK",DEF.SCR_W>>1 , DEF.SCR_H- (TOUCH_SOFTKEY_GAMEPLAY_HEIGHT>>1), GRPH.HCENTER_VCENTER);

//@#if not UseOutScreenButton						
				if (!CGame.InCinemitic() && CGame.isPointInRect((DEF.SCR_W - TOUCH_BUTTON_WIDTH >> 1), DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, TOUCH_BUTTON_WIDTH, TOUCH_BUTTON_HEIGHT))
				{
					this.keyPressed(GLLibConfig.keycodeFire);
					// this.keyReleased(GLLibConfig.keycodeFire);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== ");
					// return;
				}
//@#endif				


				if(CGame.InCinemitic() || CEntity._hero._subState == DState.SS_HERO_IN_FLY_CANNON)
				{
					if (CGame.isPointInRectAbs(0, 0, DEF.SCR_W, DEF.SCR_H - TOUCH_SOFTKEY_GAMEPLAY_HEIGHT)){
						this.keyPressed(GLLibConfig.keycodeFire);						
						// this.keyReleased(GLLibConfig.keycodeFire);		
						if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 1");
					}
					
					return;
				}
//				Dbg(pointerPosX + "," + pointerPosY);
//				Dbg("DRAGGING:"+(pointerDragX-pointerPosX)+","+(pointerDragY-pointerPosY));
			var isGravityReversed = CEntity._hero.CheckFlag(DFlags.REVERSAL_GRAVITY);
				box = CEntity._hero.GetAbsoluteBox(isGravityReversed?TOUCH_HERO_BOUNDING_REV:TOUCH_HERO_BOUNDING);
//				/*GLLib.*/SetColor(0x00FF00);
//				DrawRect_FixedPoint(box[0], box[1], box[2] - box[0], box[3] - box[1]);
//				Dbg(box[0]+","+box[1]+","+box[2]+","+box[3]);
				if (CGame.s_isEnemyPointed || CGame.isPointInRectAbs_FixedPoint(box[0], box[1], box[2], box[3]))
				{
					if(CEntity.show_hint_Press2)
					{
						this.keyPressed(GLLibConfig.keycodeUp);
						CEntity.show_hint_Press2 = false
					}
					this.keyPressed(GLLibConfig.keycodeFire);
					CGame.s_isEnemyPointed = false;
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 2");
					// return;
				}
				else if (!isGravityReversed && CGame.isPointInRectAbs_FixedPoint(box[2], box[1], Math_IntToFixedPoint(DEF.SCR_W) +  CEntity._camX, Math_IntToFixedPoint(DEF.SCR_H - TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY)
						|| isGravityReversed && CGame.isPointInRectAbs_FixedPoint(box[2], CEntity._camY, Math_IntToFixedPoint(DEF.SCR_W) +  CEntity._camX, box[3])
				)
				{
					this.keyPressed(GLLibConfig.keycodeRight);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 3");
					// return;
				}
				else if (!isGravityReversed && CGame.isPointInRectAbs_FixedPoint(CEntity._camX, box[1], box[0], Math_IntToFixedPoint(DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY)
						|| isGravityReversed && CGame.isPointInRectAbs_FixedPoint(CEntity._camX, CEntity._camY, box[0], box[3])
				)					
				{
					this.keyPressed(GLLibConfig.keycodeLeft);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 4");
					// return;
				}
				else if (CGame.isPointInRectAbs_FixedPoint(box[0], CEntity._camY, box[2], box[1]))
				{
					this.keyPressed(GLLibConfig.keycodeUp);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 5");
					// return;
				}
				else if (CGame.isPointInRectAbs_FixedPoint(box[0], box[3], box[2], Math_IntToFixedPoint(DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY))
				{
					this.keyPressed(GLLibConfig.keycodeDown);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 6");
					// return;
				}
				else if (!isGravityReversed &&CGame.isPointInRectAbs_FixedPoint( CEntity._camX,   CEntity._camY,box[0], box[1]))
				{
					this.keyPressed(GLKey.k_num1/* Canvas.KEY_NUM1 */);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 7");
					// return;
				}
				else if (!isGravityReversed &&CGame.isPointInRectAbs_FixedPoint( box[2],   CEntity._camY,Math_IntToFixedPoint(DEF.SCR_W) +  CEntity._camX, box[1]))
				{
					this.keyPressed(GLKey.k_num3/* Canvas.KEY_NUM3 */);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 8");
					// return;
				}
				else if (isGravityReversed &&CGame.isPointInRectAbs_FixedPoint( CEntity._camX, box[3],box[0], Math_IntToFixedPoint(DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY))
				{
					this.keyPressed(GLKey.k_num7/* Canvas.KEY_NUM7 */);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 9");
					// return;
				}
				else if (isGravityReversed &&CGame.isPointInRectAbs_FixedPoint( box[2], box[3], Math_IntToFixedPoint(DEF.SCR_W) +  CEntity._camX, Math_IntToFixedPoint(DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY))
				{
					this.keyPressed(GLKey.k_num9/* Canvas.KEY_NUM9 */);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 10");
					// return;
				}
				else if (CEntity._hero._state == DState.STATE_INAIR && pointerDragX - pointerHeldX > 0 && pointerDragX > Math_FixedPointToInt(box[2]  - CEntity._camX))
				{
					this.keyReleased(GLLibConfig.keycodeLeft);
					this.keyPressed(GLLibConfig.keycodeRight);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 11");
					// return;
				}
				else if (CEntity._hero._state == DState.STATE_INAIR && pointerDragX != -1000 &&pointerDragX - pointerHeldX < 0 && pointerDragX < Math_FixedPointToInt(box[0] - CEntity._camX))
				{
					this.keyReleased(GLLibConfig.keycodeRight);
					this.keyPressed(GLLibConfig.keycodeLeft);
					if(DEF.dbgEnableKey) Dbg("UpdatePointerEvents GAMEPLAY_UPDATE =============================================== 12");
					// return;
				}
//				else if (pointerDragX - pointerHeldX < 0)
//				{
//				Dbg(pointerDragX+","+pointerHeldX);
//				this.keyPressed(GLLibConfig.keycodeLeft);
//				}

				if (CGame.isAnyPointPressed()){
					CGame.UpdateKeyState();
					// ResetKey();
				}
			}
			// WARNIN : NEED RESET KEY WHEN END GAME UPDATE !!!!!!!
			// if (CGame.isAnyPointPressed()){
				// CGame.UpdateKeyState();
				// ResetKey();
			// }
			return;
		}
//@#if not UseCommandBar
		if (s_game_state != STATE.IGP)
		this.detectSoftKeys();
//@#endif
//@#if UseOutScreenButton
//@		if (CGame.isPointInRect(0, 320, 240, F490VHeight-320))
//@		{
//@			this.keyPressed(GLLibConfig.keycodeFire);
//@			if(!(s_game_state == STATE.GAMEPLAY_UPDATE //&& ((CGame.InCinemitic() || CEntity._hero._subState == DState.SS_HERO_IN_FLY_CANNON))
//@					|| s_game_state == STATE.MENU_MAP))
//@				this.keyReleased(GLLibConfig.keycodeFire);
//@		}		
//@#endif		
		
		switch (s_game_state)
		{
			case STATE.GAMEPLAY_UPDATE:
				return;
			case STATE.ASK_SOUND:
				if (s_cursorAnim == null && _touchInterface != null)
					s_cursorAnim = new GLLibPlayer(_touchInterface, -1000, -1000);
				break;

//			case STATE.MENU_NEW_GAME:
//				if (CEntity._hero != null)
//				{
//					box = CEntity._hero.GetAbsoluteBox(TOUCH_HERO_BOUNDING);
//					if (CGame.isPointInRectAbs_FixedPoint(box[0], box[1], box[2], box[3]))
//					{
//						this.keyPressed(GLLibConfig.keycodeFire);
//					}
//					else if (CGame.isPointInRectAbs_FixedPoint(box[2], CEntity._camY, Math_IntToFixedPoint(DEF.SCR_W) +  CEntity._camX, Math_IntToFixedPoint(DEF.SCR_H - TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY))
//					{
//						this.keyPressed(GLLibConfig.keycodeRight);
//					}
//					else if (CGame.isPointInRectAbs_FixedPoint(CEntity._camX, CEntity._camY, box[0], Math_IntToFixedPoint(DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT ) +  CEntity._camY))
//					{
//						this.keyPressed(GLLibConfig.keycodeLeft);
//					}
//				}
//				break;
			case STATE.MENU_MAP:
				if (CGame.isPointInRectAbs(0, 0, DEF.SCR_W, DEF.SCR_H)) {
					if (CGame._miniMapState == CGame.MINI_MAP_STATE_IDLE){
					    CGame._miniMapCursorX = pointerPosX + CGame._miniMapCameraX;
					    CGame._miniMapCursorY = pointerPosY + CGame._miniMapCameraY - 2 * DEF.TILE_H;
					}
				    this.keyPressed(GLLibConfig.keycodeFire);
				    // this.keyReleased(GLLibConfig.keycodeFire);
				}
				break;
			case STATE.GAMEOVER :
				if (CGame.isPointInRectAbs(0, 0, DEF.SCR_W, DEF.SCR_H))
					this.keyPressed(GLLibConfig.keycodeFire);
			break;
			case STATE.SPLASH :
			case STATE.GAME_STATISTIC:
			case STATE.LOAD_UNLOAD:
			case STATE.GAMEEND:
				if(CGame._isInputEvent)
				{
					if (s_cursorAnim == null && _touchInterface != null)
						s_cursorAnim = new GLLibPlayer(_touchInterface, -1000, -1000);
					CGame._isInputEvent = false;
					var posF = this._FakegetMousePos(CGame._eventCallback );
					// CGame._eventCallback = null;
					pointerPosX = posF.x ;
					pointerPosY = posF.y ;
					// this.keyPressed(GLKey.k_fire);
					// this.keyReleased(GLKey.k_fire);
					CGame.PlaySoundBGM();
				}
				if (CGame.isPointInRectAbs(0, 0, DEF.SCR_W, DEF.SCR_H))
				{
					this.keyPressed(GLLibConfig.keycodeFire);
					this.keyReleased(GLLibConfig.keycodeFire);
				}
			break;
			// case STATE.IGP:
				// IGP.updatePointerPressed(pointerPosX, pointerPosY);
			default:

//				this.keyPressed(pressedKeyCode);
//				this.keyReleased(pressedKeyCode);
//				pressedKeyCode = 0;
			break;
		}
		

		if (CGame.isAnyPointPressed()){
			CGame.UpdateKeyState();
			// ResetKey();
		}
}	
var s_prev_game_state;
CGame.prototype.RenderPointerEvent = function()
{
	if (s_game_state < 0)
		return;

//@#if not UseOutScreenButton		
	if (s_game_state == STATE.GAMEPLAY_UPDATE && !CGame.InCinemitic() && s_prev_game_state == s_game_state)
	{
		fontSprBig.SetCurrentPalette(1);
		if (CGame.isPointInRect((DEF.SCR_W - TOUCH_BUTTON_WIDTH >> 1), DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, TOUCH_BUTTON_WIDTH, TOUCH_BUTTON_HEIGHT)
				||(CGame.isPointHoldInRect((DEF.SCR_W - TOUCH_BUTTON_WIDTH >> 1), DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, TOUCH_BUTTON_WIDTH, TOUCH_BUTTON_HEIGHT)))
			_touchInterface.PaintFrame(g, DAnimID.TOUCHINTERFACE_FRAME_BUTTON, DEF.SCR_W>>1, DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, HCENTER|TOP);
		else
		{
			_touchInterface.PaintFrame(g, DAnimID.TOUCHINTERFACE_FRAME_BUTTON_DOWN, DEF.SCR_W>>1, DEF.SCR_H- TOUCH_SOFTKEY_GAMEPLAY_HEIGHT, HCENTER|TOP);
			fontSprBig.SetCurrentPalette(0);
		}
		fontSprBig.DrawString(g, Text_GetString(TEXT.MENU_ATTACK_TS),DEF.SCR_W>>1 , DEF.SCR_H- (TOUCH_SOFTKEY_GAMEPLAY_HEIGHT) + (TOUCH_BUTTON_HEIGHT>>1) + fontSprBig.GetCurrentPalette(), GRPH.HCENTER_VCENTER);
	}
	
//@		#if UseForLGKE850
//@			g.setClip(0, 0, DEF.True_SCR_W, DEF.True_SCR_H);
//@			g.setColor(DEF.Bottom_Color);
//@			g.fillRect(0, DEF.SCR_H, DEF.True_SCR_W, DEF.True_SCR_H-DEF.SCR_H);
//@		#endif
//@#else
//@		if (fontSprBig != null)
//@		{
//@			fontSprBig.SetCurrentPalette(0);
//@			SetClip(0, 0, 240,F490VHeight);
//@			SetColor(0);
//@			FillRect(0, 320, 240, F490VHeight);
//@            
//@			if (!(CGame.isPointInRect(0, 320, 240, F490VHeight-320)
//@					|| isPointHoldInRect(0, 320, 240, F490VHeight-320)
//@			))
//@			{
//@				SetColor(0x333333);
//@				FillRoundRect(0, DEF.SCR_H , DEF.SCR_W  , F490VHeight - 320 , 10, 10);
//@				SetColor(0xcccccc);
//@				FillRoundRect( 3, DEF.SCR_H + 3, DEF.SCR_W - 6, F490VHeight -320 - 6, 10, 10);
//@
//@			}
//@			else
//@			{
//@				SetColor(0xcccccc);
//@				FillRoundRect(0, DEF.SCR_H , DEF.SCR_W  , F490VHeight - 320 , 10, 10);
//@				fontSprBig.SetCurrentPalette(1);
//@
//@			}
//@			if (s_game_state == STATE.GAMEPLAY_UPDATE && !CGame.InCinemitic() && s_prev_game_state == s_game_state)
//@			{
//@				fontSprBig.DrawString(g, Text_GetString(TEXT.MENU_ATTACK_TS),DEF.SCR_W>>1 , 320 + ((F490VHeight - 320)>>1) , GRPH.HCENTER_VCENTER);
//@			}
//@			else
//@				fontSprBig.DrawString(g, Text_GetString(TEXT.MENU_SK_OK),DEF.SCR_W>>1 , 320 + ((F490VHeight - 320)>>1) , GRPH.HCENTER_VCENTER);
//@		}
//@
//@
//@#endif		
	s_prev_game_state = s_game_state;
	if (s_cursorAnim != null)// && s_game_state != STATE.GAMEPLAY_UPDATE)
	{
		if (CGame.isAnyPointPressed())
		{
		s_cursorAnim.SetPos(pointerPosX, pointerPosY);
		s_cursorAnim.SetAnim(DAnimID.TOUCHINTERFACE_WAVE_TAP, 1);
		s_cursorAnim.Render();
		}
		else if (!s_cursorAnim.IsAnimOver())
		{
			s_cursorAnim.Update(s_game_frameDT);
			s_cursorAnim.Render();
			
		}

	}
}
var s_keyStateRT = LowAPI.Gen_Array([GLKey.k_nbKey], 0);
CGame.UpdateKeyState  = function()
{
	UpdateKeypad_Game();
	if (GLLibConfig.useKeyAccumulation)
	{
		//solve keyRelease state only
/* 		for (var i = 0; i < GLKey.k_nbKey ; i++)
		{
			if (s_keyStateRT[i] < 0 )
				s_keyState[i] = s_keyStateRT[i];
//				if (i >= GLKey.k_menuOK && s_keyStateRT[i] > 0)
//				{
//					// all key after (and including) GLKey.k_menuOK are
//					// automatically set to released state, they do not
//					// perform accumulation
//					s_keyStateRT[i] *= -1;
//				}
		} */
	}
	else // if (GLLibConfig.useKeyAccumulation)
	{
//			m_keys_pressed			= m_current_keys_pressed;
//			m_keys_released			= m_current_keys_released;
//			m_keys_state			= m_current_keys_state;
//			m_current_keys_pressed 	= 0;
//			m_current_keys_released = 0;
//			s_game_keyPressedTime	= s_game_timeWhenFrameStart;
	}

}

//@@touchScreenDUI.h
var TOUCH_SOFTKEY_MENU_WIDTH          =   60 * DScreen.RATIO;
var TOUCH_SOFTKEY_MENU_HEIGHT         =   23 * DScreen.RATIO;
var TOUCH_SOFTKEY_GAMEPLAY_WIDTH          =   30 * DScreen.RATIO;
var TOUCH_SOFTKEY_GAMEPLAY_HEIGHT         =   TOUCH_SOFTKEY_MENU_HEIGHT;
var TOUCH_BUTTON_WIDTH 					= 120 * DScreen.RATIO;
var TOUCH_BUTTON_HEIGHT				= 20 * DScreen.RATIO;
var TOUCH_MENU_ITEM_HEIGHT			= 30 * DScreen.RATIO;
var TOUCH_MENU_ITEM_WIDTH			= DEF.SCR_W - (MENU_MAIN_X << 1);
var TOUCH_IGMENU_OFFSET_Y				= -3 * DScreen.RATIO;
var TOUCH_HERO_BOUNDING= [
Math_IntToFixedPoint(-20  * DScreen.RATIO),Math_IntToFixedPoint(-40  * DScreen.RATIO),
Math_IntToFixedPoint(20 * DScreen.RATIO),Math_IntToFixedPoint(10  * DScreen.RATIO)
];
var TOUCH_HERO_BOUNDING_REV= [
	TOUCH_HERO_BOUNDING[0],TOUCH_HERO_BOUNDING[3],
	TOUCH_HERO_BOUNDING[2],-TOUCH_HERO_BOUNDING[1]
];
CGame.TOUCH_ENEMY_BOUNDING_OFFSET = Math_IntToFixedPoint(20);
//@@
//@@
//@#endif
// -----------------------------------------------------------------------------------------------------------------------------------------
// FUNCTIONS

CGame.prototype.setState = function( state)
{
	_onlineState = state;

	// init the online substate ..
	_online_substate = DOnlineSubstate.SET;
	ResetKey ();
}

CGame.prototype.setOnlineSubstate = function( substate)
{
	_online_substate = substate;
}

CGame.prototype.OnlineTypeinData = function( strTextToDisplay1,
								 strTextToDisplay2,  bNumeric,
								 iPrevAppState,  iPrevOnlineState,
								 iMaxChar,  g)
{
	try
	{
		var sReturnValue = null;

		if (s_keyState[GLKey.k_menuOK] > 0) //Left soft key
		{
			if (0 != iPrevAppState)
			{
				setState(iPrevAppState);
			}
			if (0 != iPrevOnlineState)
			{
				setOnlineSubstate(iPrevOnlineState);
			}

			entryData = "";
			crtChar = 0;
		}

		if (redrawBK)
		{
			g.setColor(0, 0, 0);
			g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
		}
		g.setColor(0xD0, 0x50, 0x50);

		CGame.txtDraw(0,strTextToDisplay1, 3, 10, Graphics.LEFT | Graphics.TOP);
		CGame.txtDraw(0,strTextToDisplay2, 3, 20, Graphics.LEFT | Graphics.TOP);

		redrawBK = false;

		//}

		redrawBK = WasAnyKeyReleased() >= 0;

		if ((0 != crtChar) && (iMaxChar > entryData.length))
		{
			CGame.txtDraw(0,entryData + crtChar, 3, 50,
				Graphics.LEFT | Graphics.TOP);
		}
		else
		{
			CGame.txtDraw(0,entryData, 3, 50, Graphics.LEFT | Graphics.TOP);
		}

		//soft key right
		if (((s_keyState[GLKey.k_menuBack] > 0) /*|| (s_keyState[GLKey.k_fire] > 0)*/) &&
				(2 < entryData.length))
		{
			if ((0 != crtChar) && (iMaxChar > entryData.length))
			{
				entryData = entryData + crtChar;
			}

			sReturnValue = entryData;
			redrawBK = true;
			entryData = "";
			crtChar = 0;
		}

		if ((_keycode = WasAnyKeyReleased()) >= 0)
		{
			if ( (_keycode >= GLKey.k_num0) && (_keycode <= GLKey.k_num9))
			{
				_keycode -=  GLKey.k_num0;
				if ( (!bNumeric) || (_keycode == 0))
				{
					if (_keycode != lastKeyPressed)
					{
						if ( (0 != crtChar) && (iMaxChar > entryData.length))
						{
							entryData = entryData + crtChar;
						}

						lastKeyIndex = 0;
						crtChar = keymap[_keycode][lastKeyIndex];
						lastKeyTime = System.currentTimeMillis();
						lastKeyPressed = _keycode;
					}
					else
					{
						if ((System.currentTimeMillis() - lastKeyTime) > 1000)
						{

							if ( (0 != crtChar) &&
								(iMaxChar > entryData.length))
							{
								entryData = entryData + crtChar;
							}

							lastKeyIndex = 0;
							crtChar = keymap[_keycode][lastKeyIndex];
							lastKeyTime = System.currentTimeMillis();
							lastKeyPressed = _keycode;
						}
						else
						{
							lastKeyIndex =  ( (lastKeyIndex + 1) %
								keymap[_keycode].length);

							crtChar = keymap[_keycode][lastKeyIndex];
							lastKeyTime = System.currentTimeMillis();
							lastKeyPressed = _keycode;
						}
					}
				}
				else
				{
					if (_keycode != lastKeyPressed)
					{
						if ( (0 != crtChar) &&
							(iMaxChar > entryData.length))
						{
							entryData = entryData + crtChar;
						}
					}

					lastKeyIndex =  (keymap[_keycode ].length - 1);

					crtChar = keymap[_keycode ][lastKeyIndex];
					lastKeyTime = System.currentTimeMillis();
					lastKeyPressed = _keycode;
					//#line 981 "matrix-src\\CGame.java"
					if ( (0 != crtChar) && (iMaxChar > entryData.length))
					{
						entryData = entryData + crtChar;
					}

					crtChar = 0;
					lastKeyIndex = 0;
				}
			}
			else if ((s_keyState[GLKey.k_star] > 0)/*||(s_keyState[GLKey.k_left] > 0)*/)
			{
				if (entryData.length > 0)
				{
					crtChar = entryData.charAt(entryData.length - 1);

					entryData = entryData.substring(0,
						entryData.length - 1);
				}
				else
				{
					if (crtChar != 0)
					{
						crtChar = 0;
					}
					else
					{
						sReturnValue = "";
					}
				}
			}

			_keycode = 0;
		}

		return sReturnValue;
	}
	catch( e){if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message); return null;}
}

// -----------------------------------------------------------------------------------------------------------------------------------------
// ONLINE MAIN DRAW FUNCTION



CGame.prototype.drawOnline = function( g)
{
	try
	{
		var todraw = null;
		var str0 = "";

		g.setColor(0, 0, 0);
		g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
		g.setColor(0xD0, 0x50, 0x50);


		if (	_onlineState >= DOnlineState.TEST_LOGIN
			&&	_onlineState <= DOnlineState.TEST_RECOMMENDGAME
			&&	_online_substate != DOnlineSubstate.DISPLAY
			)
		{
			// network transmission in progress .. draw waiting screen
			todraw = Text_GetString(TEXT.MENU_XPLAYER_PLEASE_WAIT);
			CGame.txtDraw(0,todraw, g.getClipWidth() / 2,
				g.getClipHeight() / 2,
				Graphics.TOP | Graphics.HCENTER);

			CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1, g.getClipHeight() - 1,
				Graphics.BOTTOM | Graphics.LEFT);

			// nothing more to do ..
			return;
		}

		switch (_onlineState)
		{
			case DOnlineState.INIT :	{ DrawOnlineState_INIT (g); } break ;
			case DOnlineState.MENU :	{ DrawOnlineState_MENU (g); } break ;

			case DOnlineState.TEST_ARENA :	{ DrawOnlineState_TEST_ARENA (g); } break ;
			case DOnlineState.TEST_REGISTER :	{ DrawOnlineState_TEST_REGISTER (g); } break ;
			case DOnlineState.TEST_NICK_TAKEN :	{ DrawOnlineState_TEST_NICK_TAKEN (g); } break ;
			case DOnlineState.TEST_LOGIN :	{ DrawOnlineState_TEST_LOGIN (g); } break ;
			case DOnlineState.TEST_SENDINGSCORE :	{ DrawOnlineState_TEST_SENDINGSCORE (g); } break ;
			case DOnlineState.TEST_GETRANK :	{ DrawOnlineState_TEST_GETRANK (g); } break ;
			case DOnlineState.TEST_GETRANK_AROUND_PLAYER :	{ DrawOnlineState_TEST_GETRANK_AROUND_PLAYER (g); } break ;
			case DOnlineState.TEST_DISPLAY_GAME_RATINGS :	{ DrawOnlineState_TEST_DISPLAY_GAME_RATINGS (g); } break ;
			case DOnlineState.TEST_RATEGAME :	{ DrawOnlineState_TEST_RATEGAME (g); } break ;
			case DOnlineState.TEST_RECOMMENDGAME :	{ DrawOnlineState_TEST_RECOMMENDGAME (g); } break ;
			case DOnlineState.TEST_CONNECTION_ERROR :	{ DrawOnlineState_TEST_CONNECTION_ERROR (g); } break ;
			case DOnlineState.TEST_SERVER_ERROR :	{ DrawOnlineState_TEST_SERVER_ERROR (g); } break ;

			case DOnlineState.ENDED:
				break;

			/*
			case OnlineState.TEST_GETSTATES:
				 {
				 str0 = "";
				 // we are in DISPLAY online substate ... otherwise we'll not be here
				 CGame.txtDraw(0,STR_PRESS_5, g.getClipWidth() / 2,
				 g.getClipHeight() - 1,
				 Graphics.BOTTOM | Graphics.HCENTER);

				 str0 = "states: ";
				 CGame.txtDraw(0,str0, 10,
				 20, 0);

				 if (USE_CONDENSED_VERSION)
				 {
				 int[] bestRank = new int[1];
				 int[] highScore = new int[1];
				 int[] lowScore = new int[1];
				 int[] avgScore = new int[1];
				 int[] numberOfGames = new int[1];
				 String[] lastTimePlayed = new String[1];

				 interactiv.getPlayerStates(bestRank, highScore, lowScore,
				 avgScore,
				 numberOfGames, lastTimePlayed);

				 str0 = "Best rank: " + bestRank[0];
				 CGame.txtDraw(0,str0, 10,
				 30, 0);

				 str0 = "Highest score: " +
				 highScore[0];
				 CGame.txtDraw(0,str0, 10,
				 40, 0);

				 str0 = "Lowest score: " + lowScore[0];
				 CGame.txtDraw(0,str0, 10,
				 50, 0);

				 str0 = "Average score: " + avgScore[0];
				 CGame.txtDraw(0,str0, 10,
				 60, 0);

				 str0 = "Number of games: " + numberOfGames[0];

				 CGame.txtDraw(0,str0, 10,
				 70, 0);

				 str0 = "Last time played: ";
				 CGame.txtDraw(0,str0, 10,
				 80, 0);
				 str0 = "  " + lastTimePlayed[0];
				 CGame.txtDraw(0,str0, 10,
				 90, 0);

				 }
				 else
				 {
				 str0 = "Best rank: " + interactiv.getMyBestRank();
				 CGame.txtDraw(0,str0, 10,
				 30, 0);

				 str0 = "Highest score: " +
				 interactiv.getMyHighScore();
				 CGame.txtDraw(0,str0, 10,
				 40, 0);

				 str0 = "Lowest score: " + interactiv.getMyLowScore();
				 CGame.txtDraw(0,str0, 10,
				 50, 0);

				 str0 = "Average score: " + interactiv.getMyAvgScore();
				 CGame.txtDraw(0,str0, 10,
				 60, 0);

				 str0 = "Number of games: " +
				 interactiv.getMyNumberOfGamesPlayed();
				 CGame.txtDraw(0,str0, 10,
				 70, 0);

				 str0 = "Last time played: ";
				 CGame.txtDraw(0,str0, 10,
				 80, 0);
				 str0 = "  " + interactiv.getMyLastTimePlayed();
				 CGame.txtDraw(0,str0, 10,
				 90, 0);

				 }
				 }
				 break;
				 */

		}
	}
	catch( e)
	{if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);}
}



// -----------------------------------------------------------------------------------------------------------------------------------------
// SPECIFIC ONLINE STATE DRAW FUNCTIONS
CGame.prototype.DrawOnlineState_INIT = function( g)// throws Exception
{
	// go to initial registration ..
	// the user is not logged in .. try to do it !
	setState(DOnlineState.TEST_LOGIN);
	is_initial_login = true;
}

CGame.prototype.DrawOnlineState_MENU = function( g) //throws Exception
{
	var todraw = null;

	CGame.txtDraw(0, Text_GetString(TEXT.MENU_XPLAYER_MAIN_MENU), g.getClipWidth() / 2,
		g.getClipHeight() / 4,
		Graphics.TOP | Graphics.HCENTER);
	g.setColor(0xC0, 0xB0, 0);
	todraw = Text_GetString(options[_menustate]);
	if (_menustate > 0)
	{
		todraw = "<- " + todraw;
	}
	if (_menustate < TOTAL_MENU_ITEMS - 1)
	{
		todraw = todraw + " ->";
	}
	CGame.txtDraw(0,todraw, g.getClipWidth() / 2,
		g.getClipHeight() / 2,
		Graphics.TOP | Graphics.HCENTER);

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);
}


CGame.prototype.DrawOnlineState_TEST_ARENA = function( g) //throws Exception
{
	var todraw = null;

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_ONLINE_MENU), g.getClipWidth() / 2,
		10,
		Graphics.TOP | Graphics.HCENTER);

	if(!(GLLibConfig.xplayer_CARRIER_USSPRINT|
		GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE|
		GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE|
		GLLibConfig.xplayer_CARRIER_USNEXTEL|
		GLLibConfig.xplayer_CARRIER_USVIRGIN))
	{
		ACTION_NUMBER = 3;
	}


	for (var i = 0; i < ACTION_NUMBER; i++)
	{
		todraw = Text_GetString(actions[i]);

		if (selectedAction == i)
		{
			todraw += "*";
		}

		CGame.txtDraw(0,todraw, g.getClipWidth() / 2,
			30 + i * 15,
			Graphics.TOP | Graphics.HCENTER);
	}

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.LEFT);
}

CGame.prototype.DrawOnlineState_TEST_REGISTER = function( g) //throws Exception
{
	var username = interactiv.getUsername();
	if (username.length == 0)
	{
		// input the username ...
		username = OnlineTypeinData(Text_GetString(TEXT.MENU_XPLAYER_ENTER_YOUR_USERNAME),
			Text_GetString(TEXT.MENU_XPLAYER_MAX_15_CHARACTERS), false,
			DOnlineState.MENU, 0, 15, g);

		if ( (username != null) && (username.length > 0))
		{ // the username was input ...
			lastKeyTime = 0;
			lastKeyPressed = 0;
			lastKeyIndex = 0;
			crtChar = 0;
			interactiv.setUsername(username);
		}
	}
	else
	{
		// the username is input, get the phone number too
		var phoneNumber = OnlineTypeinData(
			Text_GetString(TEXT.MENU_XPLAYER_ENTER_YOUR_PHONE_NUMBER),
			Text_GetString(TEXT.MENU_XPLAYER_10_CHARS), true, DOnlineState.MENU, 0,
			10, g);
		if ( (phoneNumber != null) && (phoneNumber.length > 0))
		{
			lastKeyTime = 0;
			lastKeyPressed = 0;
			lastKeyIndex = 0;
			crtChar = 0;
			interactiv.setPhoneNumber(phoneNumber);
			this.setState(DOnlineState.TEST_LOGIN);
		}
	}
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_STAR_TO_DELETE), g.getClipWidth()/2,
		g.getClipHeight() *2/ 3,
		Graphics.HCENTER | Graphics.HCENTER);
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.LEFT);
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_OK), g.getClipWidth() - 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.RIGHT);

}

CGame.prototype.DrawOnlineState_TEST_NICK_TAKEN = function( g) //throws Exception
{
	var username = interactiv.getUsername();
	if (username.length == 0)
	{
		// input the username ...
		username = OnlineTypeinData(Text_GetString(TEXT.MENU_XPLAYER_NICK_TAKEN),
			Text_GetString(TEXT.MENU_XPLAYER_MAX_15_CHARACTERS), false,
			DOnlineState.MENU, 0, 15, g);

		if ( (username != null) && (username.length > 0))
		{ // the username was input ...
			lastKeyTime = 0;
			lastKeyPressed = 0;
			lastKeyIndex = 0;
			crtChar = 0;
			// got the new username
			interactiv.setUsername(username);

			// send login again ..
			this.setState(DOnlineState.TEST_LOGIN);
		}
	}

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.LEFT);
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_OK), g.getClipWidth() - 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.RIGHT);
}

CGame.prototype.DrawOnlineState_TEST_LOGIN = function( g) //throws Exception
{
	// we are in DISPLAY online substate ... otherwise we'll not be here
	if (interactiv.isLoggedIn())
	{
		CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_WELCOME)+" " + interactiv.getUsername(),
			g.getClipWidth() / 2,
			g.getClipHeight() / 2,
			Graphics.TOP | Graphics.HCENTER);
		CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5),
			g.getClipWidth() / 2,
			g.getClipHeight() / 2 + 10,
			Graphics.TOP | Graphics.HCENTER);
		CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1,
			g.getClipHeight() - 1,
			Graphics.BOTTOM | Graphics.LEFT);

	}
}

CGame.prototype.DrawOnlineState_TEST_SENDINGSCORE = function( g) //throws Exception
{
	var str0 = "";

	// we are in DISPLAY online substate ... otherwise we'll not be here
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);

	str0 = Text_GetString(TEXT.MENU_XPLAYER_NEW_RANK) + ": " +
		interactiv.getNewRankAfterScoreSending();

	CGame.txtDraw(0,str0, 10,
		g.getClipHeight() >> 1, 0);
}

CGame.prototype.DrawOnlineState_TEST_GETRANK = function( g) //throws Exception
{
	var str0 = "";

	// we are in DISPLAY online substate ... otherwise we'll not be here
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);

	var tmp;

	if (USE_CONDENSED_VERSION)
	{
		var size = interactiv.getLeaderboardSize();

		var names = LowAPI.Gen_Array([size], null);//new String[size];
		var positions = LowAPI.Gen_Array([size], 0);//new int[size];
		var scores = LowAPI.Gen_Array([size], 0);//new int[size];
		var scoreDatas = LowAPI.Gen_Array([size], 0);//new int[size][];

		if (interactiv.getLeaderboardData(names, positions, scores,
			scoreDatas) == false)
		{
			return;
		}

		for (var r = 0; r < size; r++)
		{

			tmp = "" +
				positions[r] +
				": " +
				names[r] +
				" " +
				scores[r];

			if (scoreDatas != null)
			{
				var score_data = scoreDatas[r];

				if (score_data != null)
				{
					for (var i = 0; i < score_data.length; i++)
					{
						tmp += " " + score_data[i];
					}
				}
			}

			str0 = tmp;

			CGame.txtDraw(0,str0, 30, 30 + r * 14, 0);
		}
	}
	else
	{
		for (var r = 0; r < interactiv.getLeaderboardSize(); r++)
		{

			tmp = "" +
				interactiv.
				getLeaderboardEntryPlayerPosition(r) +
				": " +
				interactiv.getLeaderboardEntryPlayerName(r) +
				" " +
				interactiv.getLeaderboardEntryPlayerScore(r);

			var score_data = interactiv.
				getLeaderboardEntryPlayerScoreData(r);

			if (score_data != null)
			{
				for (var i = 0; i < score_data.length; i++)
				{
					tmp += " " + score_data[i];
				}
			}

			str0 = tmp;

			CGame.txtDraw(0,str0, 30, 30 + r * 14, 0);
		}
	}

	if (interactiv.getCurrentPlayerLeaderboardPosition() >
		0)
	{ //my rank
		tmp = Text_GetString(TEXT.MENU_XPLAYER_YOU) + ":" +
			interactiv.
			getCurrentPlayerLeaderboardPosition() +
			" " +
			interactiv.
			getCurrentPlayerLeaderboardScore();

		var score_data = interactiv.
			getCurrentPlayerLeaderboardScoreData();

		if (score_data != null)
		{
			for (var i = 0; i < score_data.length; i++)
			{
				tmp += " " + score_data[i];
			}
		}

		CGame.txtDraw(0,tmp,
			0, 20, 0);
	}
}

CGame.prototype.DrawOnlineState_TEST_GETRANK_AROUND_PLAYER = function( g) //throws Exception
{
	var str0 = "";

	// we are in DISPLAY online substate ... otherwise we'll not be here
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);

	var tmp;

	if (interactiv.getLeaderboardSize() <= 0)
	{
		tmp = Text_GetString(TEXT.MENU_XPLAYER_NO_SCORE_SENT);
		str0 = tmp;
		CGame.txtDraw(0,str0, 30, 50, 0);

		return;
	}

	if (USE_CONDENSED_VERSION)
	{
		var size = interactiv.getLeaderboardSize();

		var names = LowAPI.Gen_Array([size], null);//new String[size];
		var positions = LowAPI.Gen_Array([size], 0);//new int[size];
		var scores = LowAPI.Gen_Array([size], 0);//new int[size];
		var scoreDatas = LowAPI.Gen_Array([size], null);//new int[size][];

		if (interactiv.getLeaderboardData(names, positions, scores,
			scoreDatas) == false)
		{
			return;
		}

		for (var r = 0; r < size; r++)
		{

			tmp = "" +
				positions[r] +
				": " +
				names[r] +
				" " +
				scores[r];

			if (scoreDatas != null)
			{
				var score_data = scoreDatas[r];

				if (score_data != null)
				{
					for (var i = 0; i < score_data.length;
						i++)
					{
						tmp += " " + score_data[i];
					}
				}
			}

			if (names[r].compareTo(interactiv.getUsername()) == 0)
			{
				g.setColor(0xC0, 0xB0, 0);
			}
			else
			{
				g.setColor(0xD0, 0x50, 0x50);
			}

			str0 = tmp;

			CGame.txtDraw(0,str0, 30, 30 + r * 14, 0);
		}
	}
	else
	{
		for (var r = 0; r < interactiv.getLeaderboardSize();
			r++)
		{

			tmp = "" +
				interactiv.
				getLeaderboardEntryPlayerPosition(r) +
				": " +
				interactiv.getLeaderboardEntryPlayerName(r) +
				" " +
				interactiv.getLeaderboardEntryPlayerScore(r);

			var score_data = interactiv.
				getLeaderboardEntryPlayerScoreData(r);

			if (score_data != null)
			{
				for (var i = 0; i < score_data.length; i++)
				{
					tmp += " " + score_data[i];
				}
			}

			if ( (interactiv.getLeaderboardEntryPlayerName(
				r)).compareTo(interactiv.getUsername()) ==
				0)
			{
				g.setColor(0xC0, 0xB0, 0);
			}
			else
			{
				g.setColor(0xD0, 0x50, 0x50);
			}

			str0 = tmp;
			CGame.txtDraw(0,str0, 30, 30 + r * 14, 0);

		}
	}
}

CGame.prototype.DrawOnlineState_TEST_DISPLAY_GAME_RATINGS = function( g) //throws Exception
{
	// display the possible game ratings ....
	for (var i = RATING_NUMBER; i > 0; i--)
	{
		if (RATING_NUMBER - _ratestate == i)
		{
			g.setColor(0xD0FF00);
		}
		else
		{
			g.setColor(0xD05050);
		}
		CGame.txtDraw(0,"" + i + " - " + ratings[i - 1],
			g.getClipWidth() / 2,
			20 + (RATING_NUMBER - i) * 10,
			Graphics.TOP | Graphics.HCENTER);

	}
	g.setColor(0xD05050);
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_CANCEL), 1, g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.LEFT);
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_OK), g.getClipWidth() - 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.RIGHT);
}

CGame.prototype.DrawOnlineState_TEST_RATEGAME = function( g) //throws Exception
{
	var str0 = "";

	// we are in DISPLAY online substate ... otherwise we'll not be here
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);

	str0 = Text_GetString(TEXT.MENU_XPLAYER_RATING_SENT);
	CGame.txtDraw(0,str0, 5,
		g.getClipHeight() >> 1, 0);
}

CGame.prototype.DrawOnlineState_TEST_RECOMMENDGAME = function( g) //throws Exception
{
	var str0 = "";

	// we are in DISPLAY online substate ... otherwise we'll not be here
	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_PRESS_5), g.getClipWidth() / 2,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.HCENTER);

	str0 = Text_GetString(TEXT.MENU_XPLAYER_RECOMMENDATION_SENT);

	CGame.txtDraw(0,str0, 5,
		g.getClipHeight() >> 1, 0);
}

CGame.prototype.DrawOnlineState_TEST_CONNECTION_ERROR = function( g) //throws Exception
{
	var str0 = "";

	g.setColor(0);
	g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
	g.setColor(0xD05050);

	str0 = Text_GetString(TEXT.MENU_XPLAYER_CONNECTION_ERROR);
	CGame.txtDraw(0,str0, 10,
		g.getClipHeight() >> 1, 0);

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_OK), g.getClipWidth() - 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.RIGHT);
}

CGame.prototype.DrawOnlineState_TEST_SERVER_ERROR = function( g) //throws Exception
{
	var str0 = "";

	g.setColor(0);
	g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
	g.setColor(0xD05050);

	str0 = Text_GetString(TEXT.MENU_XPLAYER_SERVER_ERROR_NR) + ":" + interactiv.getLastError();
	CGame.txtDraw(0,str0, 10,
		g.getClipHeight() >> 1, 0);

	CGame.txtDraw(0,Text_GetString(TEXT.MENU_XPLAYER_OK), g.getClipWidth() - 1,
		g.getClipHeight() - 1,
		Graphics.BOTTOM | Graphics.RIGHT);
}

// -----------------------------------------------------------------------------------------------------------------------------------------
// ONLINE MAIN UPDATE FUNCTION



CGame.prototype.updateOnline = function()
{
	// main loop

	//dnay
	// the first thing we must do when the game is started
	// is to prompt for registration

	// for this , we must create an interactive object ....
	// after the registration is complete , we must destroy this object
	// and eventually create it again when the users chooses arena mode ..

	//while (_onlineState != OnlineState.ENDED)
	{
		switch (_onlineState)
		{
			case DOnlineState.INIT:
			{
				break;
			}

			case DOnlineState.MENU :	{ UpdateOnlineState_MENU (); } break ;
			case DOnlineState.TEST_LOGIN :	{ UpdateOnlineState_TEST_LOGIN (); } break ;
			case DOnlineState.TEST_ARENA :	{ UpdateOnlineState_TEST_ARENA (); } break ;
			case DOnlineState.TEST_SENDINGSCORE :	{ UpdateOnlineState_TEST_SENDINGSCORE (); } break ;
			case DOnlineState.TEST_GETRANK :	{ UpdateOnlineState_TEST_GETRANK (); } break ;
			case DOnlineState.TEST_GETRANK_AROUND_PLAYER :	{ UpdateOnlineState_TEST_GETRANK_AROUND_PLAYER (); } break ;
			case DOnlineState.TEST_DISPLAY_GAME_RATINGS :	{ UpdateOnlineState_TEST_DISPLAY_GAME_RATINGS (); } break ;
			case DOnlineState.TEST_RATEGAME :	{ UpdateOnlineState_TEST_RATEGAME (); } break ;
			case DOnlineState.TEST_RECOMMENDGAME :	{ UpdateOnlineState_TEST_RECOMMENDGAME (); } break ;
			case DOnlineState.TEST_CONNECTION_ERROR :	{ UpdateOnlineState_TEST_CONNECTION_ERROR (); } break ;
			case DOnlineState.TEST_SERVER_ERROR :	{ UpdateOnlineState_TEST_SERVER_ERROR (); } break ;
			case DOnlineState.ENDED :	{ UpdateOnlineState_ENDED (); } break ;

			/*
			 UPDATE_ONLINESTATE_SWITCHCASE(TEST_GETSTATES:
				{
				switch (_online_substate)
				{
					case OnlineSubstate.SET:
						{
						// send the get states request ..
						interactiv.sendStatsGet(0); // get states for level 0
						this.setOnlineSubstate(OnlineSubstate.WAIT);
					}
					case OnlineSubstate.WAIT:
						{
						if (s_keyState[GLKey.k_fire] > 0)
						{
							interactiv.cancel();
							this.setState(OnlineState.TEST_ARENA);
						}

						interactiv.handleStatsGet();
						_errCode = interactiv.getLastError();

						if (_errCode != XPlayer.Error.ERROR_PENDING)
						{
							interactiv.cleanup();
							this.setOnlineSubstate(OnlineSubstate.PROCESS);
						}

						break;
					}
					case OnlineSubstate.PROCESS:
						{
						switch (_errCode)
						{
							case XPlayer.Error.ERROR_NONE:
								{ //no error
								this.setOnlineSubstate(OnlineSubstate.
									DISPLAY);
								break;
							}
							case XPlayer.Error.ERROR_CONNECTION:
								{
								this.setState(OnlineState.TEST_CONNECTION_ERROR);
								break;
							}
							default:
								{
								this.setState(OnlineState.TEST_SERVER_ERROR);
								break;
							}
						}
						break;
					}
					case OnlineSubstate.DISPLAY:
						{
						if (s_keyState[GLKey.k_num5] > 0)
						{
							this.setState(OnlineState.TEST_ARENA);
						}
						break;
					}
				}

				break;s
			}
			*/
		}
	}

	// user quit
}



// -----------------------------------------------------------------------------------------------------------------------------------------
// ONLINE SPECIFIC UPDATE FUNCTIONS

CGame.prototype.UpdateOnlineState_MENU = function()
{
	//Process the menu
	if ((s_keyState[GLKey.k_left]>0))
	{
		//go back 1 option
		if (_menustate > 0)
		{
			_menustate--;
		}
	}
	else if ((s_keyState[GLKey.k_right]>0))
	{

		//go forward 1 option
		if (_menustate < TOTAL_MENU_ITEMS - 1)
		{
			_menustate++;
		}

	}
	else if (s_keyState[GLKey.k_fire]>0)
	{	//perform the selected action

		switch (_menustate)
		{
			case MENU_STATE_TEST_ARENA:
				if(interactiv == null )
				{
					if (DEF.dbgEnable) Dbg("make sure xplayer is here");
					interactiv = new XPlayer(s_application);
				}
				if (interactiv.isLoggedIn())
				{
					// go to menu ...
					this.setState(DOnlineState.TEST_ARENA);
					break;
				}

				// this is not the initial login ...
				is_initial_login = false;

				// the user is not logged in .. try to do it !
				setState(DOnlineState.TEST_LOGIN);
				break;

			case MENU_STATE_EXIT:
				_onlineState = DOnlineState.ENDED;
				break;
		}
	}
	else if ((s_keyState[GLKey.k_menuOK] > 0) || (s_keyState[GLKey.k_num3] > 0))//gb fire2?
	{
		interactiv.cancel();
		_onlineState = DOnlineState.ENDED;

	}
}

CGame.prototype.UpdateOnlineState_TEST_LOGIN = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
			{
			if (DEF.dbgEnable) Dbg("Xplayer is "+interactiv);
			interactiv.sendLogin(null); // no player data ..
			this.setOnlineSubstate(DOnlineSubstate.WAIT);
			break;
		}
		case DOnlineSubstate.WAIT:
			{
			if (s_keyState[GLKey.k_menuOK] > 0)
			{
				interactiv.cancel();
				interactiv.setUsername("");
				interactiv.setPhoneNumber("");
				this.setState(DOnlineState.MENU);
			}

			interactiv.handleLogin();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.PROCESS);
			}
			break;
		}
		case DOnlineSubstate.PROCESS:
			{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error
					//success login - go to display
					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
				}
					break;

				case XPlayer.Error.ERROR_NICK_TAKEN:
					{
					// try to register again ..
					// get the suggested nickname
					entryData = interactiv.getUsername();

					// reset the nickname in interactive class
					interactiv.setUsername("");

					this.setState(DOnlineState.TEST_NICK_TAKEN);
					_keycode = 0;
				}
					break;

				case XPlayer.Error.ERROR_REGISTER_FAILED:
				case XPlayer.Error.ERROR_NO_NICKNAME:
				case XPlayer.Error.ERROR_NO_PHONE_NUMBER:
					{
					//regenerate username
					//here a client must go to another state
					//and ask for another username ( input)
					interactiv.setUsername("");
					interactiv.setPhoneNumber("");
					this.setState(DOnlineState.TEST_REGISTER);
					_keycode = -1;

					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}

			break;
		}
		case DOnlineSubstate.DISPLAY:
			{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				/*
				 * if (is_initial_login)
				{
					this.setState(OnlineState.MENU);
				}
				else
				*/
				{
					this.setState(DOnlineState.TEST_ARENA);
				}
			}
			else if (s_keyState[GLKey.k_menuOK] > 0)
			{
				this.setState(DOnlineState.MENU);
			}
			break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_ARENA = function()
{
// key input ..
	if( s_keyState[GLKey.k_menuOK] > 0)
	{
		interactiv.cancel();
		_onlineState = DOnlineState.MENU;

	}
	else if (s_keyState[GLKey.k_up] > 0)
	{
		if (selectedAction > 0)
		{
			selectedAction--;
		}
	}

	else if (s_keyState[GLKey.k_down] > 0)
	{
		if (selectedAction < ACTION_NUMBER - 1)
		{
			selectedAction++;
		}
	}


	else if (s_keyState[GLKey.k_fire] > 0)
	{
		switch (selectedAction)
		{
			case 0:
				{ //send highscore
				//interactiv.sendHighscore(5, 0, XPlayer.SCORE_TYPE_POINTS, "1000");
				this.setState(DOnlineState.TEST_SENDINGSCORE);
				break;
			}
			case 1:
				{
				//get rank
				this.setState(DOnlineState.TEST_GETRANK);
				break;

			}
			case 2:
				{
				//get rank around player
				this.setState(DOnlineState.
					TEST_GETRANK_AROUND_PLAYER);
				break;
			}
		/*	case 3:
				{ // get my states
				this.setState(OnlineState.TEST_GETSTATES);
				break;

			}
		*/

			case 3:
				{ //rate game
				this.setState(DOnlineState.
					TEST_DISPLAY_GAME_RATINGS);
				break;
			}
			case 4:
				{ //recommend game
				//interactiv.sendRecommendGame();
				this.setState(DOnlineState.TEST_RECOMMENDGAME);
				break;
			}
			case 5:
				{ //visit game lobby
			/*	var game_lobby_url = TestMIDlet.midlet_.
					getAppProperty("PCS-Game-Lobby-URI");
				com.sprintpcs.util.System.setExitURI(
					game_lobby_url);*/
				_onlineState = DOnlineState.ENDED;
				break;
			}

			default:
				break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_SENDINGSCORE = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
		{
			// do the score sending according to the current selected score policy ..
			// this is for demo only, in the actual game use only the code appropriate for the game ...
			switch (currentScoreSendingPolicy)
			{
				case ScoreSendingPolicies.SINGLE_SCORE:
				{
					// use this code to update only one leaderboard that has no supplemental data
					interactiv.sendHighscore(500, 0,
						XPlayer.SCORE_TYPE_POINTS);
					this.setOnlineSubstate(DOnlineSubstate.WAIT);
				}
				break;
				case ScoreSendingPolicies.SINGLE_SCORE_SUPPLEMENTAL_DATA:
					{
					// use this code to update only one leaderboard with one supplemental data field
					var supplemental = LowAPI.Gen_Array([1], 0);//new int[1];
					supplemental[0] = 56;
					interactiv.
						sendHighscoreWithSupplementalData(600,
						0, XPlayer.SCORE_TYPE_POINTS,
						supplemental);
					this.setOnlineSubstate(DOnlineSubstate.WAIT);
					}
					break;
				case ScoreSendingPolicies.MULTIPLE_SCORE:
				{
					// use this code to update 2 leaderboards, none of them with supplemental data

					interactiv.initMultipleScores();
					interactiv.addMultipleScoreEntry(600, 0,
						XPlayer.SCORE_TYPE_POINTS);
					interactiv.addMultipleScoreEntry(700, 1,
						XPlayer.SCORE_TYPE_POINTS);
					interactiv.sendMultipleHighscores();
					this.setOnlineSubstate(DOnlineSubstate.WAIT);
				}
				break;
				case ScoreSendingPolicies.
			MULTIPLE_SCORE_SUPPLEMENTAL_DATA:
				{
					// use this code to update 2 leaderboard, each of them with one supplemental data field

					interactiv.initMultipleScores();
					var supplemental = LowAPI.Gen_Array([1], 0);//new int[1];

					supplemental[0] = 1000;
					interactiv.
						addMultipleScoreEntryWithSupplementalData(
						600, 0, XPlayer.SCORE_TYPE_POINTS,
						supplemental);

					supplemental[0] = 1100;
					interactiv.
						addMultipleScoreEntryWithSupplementalData(
						700, 1, XPlayer.SCORE_TYPE_POINTS,
						supplemental);

					interactiv.sendMultipleHighscores();
					this.setOnlineSubstate(DOnlineSubstate.WAIT);
				}
				break;
			}
		}

		case DOnlineSubstate.WAIT:
		{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				interactiv.cancel();
				this.setState(DOnlineState.TEST_ARENA);
			}

			interactiv.handleHighscore();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.PROCESS);
			}

			break;
		}
		case DOnlineSubstate.PROCESS:
		{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error
					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}
			break;
		}
		case DOnlineSubstate.DISPLAY:
		{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				this.setState(DOnlineState.TEST_ARENA);
			}
			break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_GETRANK = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
			{
			interactiv.sendRankGet(0, 10, 1, 2);
			this.setOnlineSubstate(DOnlineSubstate.WAIT);
			break;
		}
		case DOnlineSubstate.WAIT:
			{
			if (s_keyState[GLKey.k_menuOK] > 0)
			{
				interactiv.cancel();
				this.setState(DOnlineState.TEST_ARENA);
			}

			interactiv.handleRankGet();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.PROCESS);
			}

			break;

		}
		case DOnlineSubstate.PROCESS:
			{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error
					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}

			break;
		}
		case DOnlineSubstate.DISPLAY:
			{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				this.setState(DOnlineState.TEST_ARENA);
			}
			break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_GETRANK_AROUND_PLAYER = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
			{
			interactiv.sendRankGetAroundPlayer(0, 3, 1, 2);
			this.setOnlineSubstate(DOnlineSubstate.WAIT);
			break;
		}
		case DOnlineSubstate.WAIT:
			{
			if (s_keyState[GLKey.k_menuOK] > 0)
			{
				interactiv.cancel();
				this.setState(DOnlineState.TEST_ARENA);
			}

			interactiv.handleRankGetAroundPlayer();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.PROCESS);
			}

			break;

		}
		case DOnlineSubstate.PROCESS:
			{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error
					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}

			break;
		}
		case DOnlineSubstate.DISPLAY:
			{
			if ((s_keyState[GLKey.k_fire] > 0))
			{
				this.setState(DOnlineState.TEST_ARENA);
			}
			break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_DISPLAY_GAME_RATINGS = function()
{

		if (s_keyState[GLKey.k_up] > 0)
		{

			//go back 1 option
			if (_ratestate > 0)
			{
				_ratestate--;
			}
		}
		else if (s_keyState[GLKey.k_down] > 0)
		{

			//go forward 1 option
			if (_ratestate < RATING_NUMBER - 1)
			{
				_ratestate++;
			}
		}
		else if (s_keyState[GLKey.k_fire] > 0)
		{
			// rate the game !!
			this.setState(DOnlineState.TEST_RATEGAME);

		}
		else if (s_keyState[GLKey.k_fire] > 0) //fire2 ?
		{
			this.setState(DOnlineState.TEST_ARENA);

		}
}

CGame.prototype.UpdateOnlineState_TEST_RATEGAME = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
			{
			interactiv.sendRateGame(RATING_NUMBER -
				_ratestate);
			this.setOnlineSubstate(DOnlineSubstate.WAIT);
			break;
		}
		case DOnlineSubstate.WAIT:
			{
			if (s_keyState[GLKey.k_menuOK] > 0)
			{
				interactiv.cancel();
				this.setState(DOnlineState.TEST_ARENA);
			}

			interactiv.handleRateGame();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.
					PROCESS);
			}
			break;
		}
		case DOnlineSubstate.PROCESS:
			{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error

					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}
			break;
		}
		case DOnlineSubstate.DISPLAY:
			{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				this.setState(DOnlineState.TEST_ARENA);
			}
			break;
		}

	}
}

CGame.prototype.UpdateOnlineState_TEST_RECOMMENDGAME = function()
{
	switch (_online_substate)
	{
		case DOnlineSubstate.SET:
			{
			interactiv.sendRecommendGame();
			this.setOnlineSubstate(DOnlineSubstate.WAIT);
			break;
		}
		case DOnlineSubstate.WAIT:
			{
			if (s_keyState[GLKey.k_menuOK] > 0)
			{
				interactiv.cancel();
				this.setState(DOnlineState.TEST_ARENA);
			}

			interactiv.handleRecommendGame();
			_errCode = interactiv.getLastError();

			if (_errCode != XPlayer.Error.ERROR_PENDING)
			{
				interactiv.cleanup();
				this.setOnlineSubstate(DOnlineSubstate.PROCESS);
			}

			break;

		}
		case DOnlineSubstate.PROCESS:
			{
			switch (_errCode)
			{
				case XPlayer.Error.ERROR_NONE:
					{ //no error
					this.setOnlineSubstate(DOnlineSubstate.
						DISPLAY);
					break;
				}
				case XPlayer.Error.ERROR_CONNECTION:
					{
					this.setState(DOnlineState.TEST_CONNECTION_ERROR);
					break;
				}
				default:
					{
					this.setState(DOnlineState.TEST_SERVER_ERROR);
					break;
				}
			}
			break;
		}
		case DOnlineSubstate.DISPLAY:
			{
			if (s_keyState[GLKey.k_fire] > 0)
			{
				this.setState(DOnlineState.TEST_ARENA);
			}
			break;
		}
	}
}

CGame.prototype.UpdateOnlineState_TEST_CONNECTION_ERROR = function()
{
	UpdateOnlineState_TEST_SERVER_ERROR();
}

CGame.prototype.UpdateOnlineState_TEST_SERVER_ERROR = function()
{
	if(s_keyState[GLKey.k_fire] > 0)//fire2
	{

		// go back to menu
		if (interactiv.isLoggedIn())
		{
			_onlineState = DOnlineState.TEST_ARENA; // if user logged in, go to interactive menu
		}
		else
		{
			_onlineState = DOnlineState.MENU; // if user not logged in yet, exit to main menu
		}

	}
}

CGame.prototype.UpdateOnlineState_ENDED = function()
{
	// Dbg("ENDED");
	s_game_state = STATE.GAMEPLAY_UPDATE;
}


// -----------------------------------------------------------------------------------------------------------------------------------------
// CONSTRUCTOR

//CGame( app, disp)
//{
//	super (app, disp);	// pass application type and display to father
//	m_chtFont = new BitmapFont("/chtFont");
////@#if UseCommandBar
////@		setCommandListener(this);
////@#endif
////@#if SupportLandspaceMode
////@        sizeChanged(getWidth(),getHeight());
////@#endif
//}

// -----------------------------------------------------------------------------------------------------------------------------------------
// ACTION PHASE


// Draw action phase elements
CGame.prototype.gameDraw = function()// throws Exception
{
//		GLLibPlayer.Tileset_Draw(/*GLLib.*/g, 0);
//		//---------------------------------------------------------------------------------------------------------
//		GLLibPlayer.Tileset_Draw(/*GLLib.*/g, 1);
//
//		GLLibPlayer.Tileset_Draw(/*GLLib.*/g, 2);
//
//		if (DEF.dbgDrawPhyfield)
//			GLLibPlayer.Tileset_Draw(/*GLLib.*/g, 4);
	// paint stuff in graphics context
	SetClip(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);

	if (CGame._inCinematicBlackScreen) {
		FillRect(0, 0, GLLibConfig.screenWidth, GLLibConfig.screenHeight);
	} else {
		// try {
			//draw all entity
			CEntity.DrawAll(-1);
	
			//GLLibPlayer.Tileset_Draw(/*GLLib.*/g, 3);
			CEntity.DrawRender(-1);
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@				if (CGame._textBubbleState != CGame.TEXT_BUBBLE_OVER) {
//@					DrawTextBubble();
//@					if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
//@						UpdateBubbleTextIndex();
//@					}
//@				}
//@#else
			this.DrawTextBubble();
//@#endif
			// } catch (ex) {
			// Dbg("gameDraw()");
			//ex.printStackTrace();
		// }
	}
}

CGame.TEXT_BUBBLE_OVER = 0;
CGame.TEXT_BUBBLE_OPEN = 1;
CGame.TEXT_BUBBLE_TEXT = 2;
CGame.TEXT_BUBBLE_CLOSE = 3;
CGame._textBubbleState = CGame.TEXT_BUBBLE_OVER;
CGame._textBubbleTime = 0;
CGame._textBubbleCurrentLine = 0;
CGame._textBubbleX = 0;
CGame._textBubbleY = 0;
CGame._textBubbleText = 0;
CGame._textBubbleCinematicID = 0;
CGame._textBubbleBigOne = false;
CGame._textBubbleCurrentCursor = -1;

CGame.StartTextBubble = function( cinematicID, x, y, text) {
	CGame._textBubbleState = CGame.TEXT_BUBBLE_OPEN;
	CGame._textBubbleX = x;
	CGame._textBubbleY = y;
	CGame._textBubbleText = text;
	CGame._textBubbleCinematicID = cinematicID;
	CGame._textBubbleTime = 0;
	CGame._textBubbleCurrentLine = 0;
	CGame._textBubbleCurrentCursor = 0;
}

CGame.TEXT_BUBBLE_TEXT_LINE_COUNT = 2;
CGame.TEXT_BUBBLE_TEXT_ENTITY_HEIGHT = 60 * DScreen.RATIO;
CGame.TEXT_BUBBLE_TEXT_ENTITY_OFFSET_X = 20;
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@//	for ku580
//@	var TEXT_BUBBLE_TEXT_POS_ARRAY_SIZE = 5;
//@	var _text_bubble_text_pos = null;
//@	var _text_bubble_text_pos_cursor = 0;
//@	var GetCurrentBubbleTextPos(int index) {
//@		_text_bubble_text_pos_cursor = Math.min(TEXT_BUBBLE_TEXT_POS_ARRAY_SIZE - 1, index);
//@		return _text_bubble_text_pos[index];
//@	}
//@	static void initCurrentBubbleTextPos(boolean inMiniMap) {
//@		_text_bubble_text_pos = null;
//@		int []pos = null;
//@		if(inMiniMap) {
//@			if(CGame._worldId == DAI.WORLD_ID_LABYRINTH - 1) {
//@				int []temppos = {
//@						TransBubbleTextPos(180, 180),
//@						TransBubbleTextPos(125, 175),
//@						0,
//@						};
//@				pos = temppos;
//@			} else if(CGame._worldId == DAI.WORLD_ID_PIRATE - 1) {
//@				int []temppos = {
//@						TransBubbleTextPos(90, 140),
//@						0,
//@						0,
//@						};
//@				pos = temppos;
//@			} else if(CGame._worldId == DAI.WORLD_ID_CAKE - 1) {
//@				int []temppos = {
//@						TransBubbleTextPos(180, 150),
//@						0,
//@						0,
//@						};
//@				pos = temppos;
//@			} else if(CGame._worldId == DAI.WORLD_ID_SPACE - 1) {
//@				int []temppos = {
//@						TransBubbleTextPos(140, 180),
//@						0,
//@						0,
//@						};
//@				pos = temppos;
//@			} else if(CGame._worldId == DAI.WORLD_ID_CASTLE - 1) {
//@				int []temppos = {
//@						TransBubbleTextPos(160, 120),
//@						0,
//@						0,
//@						};
//@				pos = temppos;
//@			} else {
//@				int []temppos = {
//@						TransBubbleTextPos(180, 180),
//@						TransBubbleTextPos(125, 175),
//@						0,
//@						};
//@				pos = temppos;
//@			}
//@		} else {
//@			int level = CGame._tempLevelId % DAI.LEVELS_NUM_PRE_WORLD;
//@			if(level == 0) {
//@				if(CGame._worldId == DAI.WORLD_ID_LABYRINTH) {
//@					int []temppos = {
//@						TransBubbleTextPos(100, 180),
//@						TransBubbleTextPos(100, 180),
//@						0,
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_PIRATE) {
//@					int []temppos = {
//@						TransBubbleTextPos(120, 170),
//@						TransBubbleTextPos(120, 170),
//@						0,
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_CAKE) {
//@					int []temppos = {
//@						TransBubbleTextPos(140, 140),
//@						TransBubbleTextPos(140, 140),
//@						0,
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_SPACE) {
//@					int []temppos = {
//@						TransBubbleTextPos(140, 150),
//@						TransBubbleTextPos(140, 150),
//@						0,
//@					};
//@					pos = temppos;
//@				}
//@			} else if(level == DAI.LEVLE_ID_BOSS_FIGHT) {
//@				if(CGame._worldId == DAI.WORLD_ID_LABYRINTH) {
//@					int []temppos = {
//@						TransBubbleTextPos(110, 90),
//@						TransBubbleTextPos(110, 240),
//@						TransBubbleTextPos(110, 90),
//@						TransBubbleTextPos(110, 240),
//@						TransBubbleTextPos(110, 90),
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_PIRATE) {
//@					int []temppos = {
//@						TransBubbleTextPos(80, 110),
//@						TransBubbleTextPos(200, 110),
//@						TransBubbleTextPos(200, 110),
//@						0,
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_CAKE) {
//@					int []temppos = {
//@						TransBubbleTextPos(120, 110),
//@						TransBubbleTextPos(120, 110),
//@						0,
//@					};
//@					pos = temppos;
//@				} else if(CGame._worldId == DAI.WORLD_ID_SPACE) {
//@					int []temppos = {
//@						TransBubbleTextPos(160, 90),
//@						TransBubbleTextPos(160, 90),
//@						TransBubbleTextPos(160, 200),
//@						TransBubbleTextPos(100, 80),
//@						TransBubbleTextPos(100, 80),
//@					};
//@					pos = temppos;
//@				}
//@			}
//@			if (CGame._tempLevelId == DAI.LEVEL_ID_CASTLE_FINAL_BOSS) {
//@				int []temppos = {
//@					TransBubbleTextPos(180, 130),
//@					TransBubbleTextPos(180, 130),
//@					TransBubbleTextPos(100, 230),
//@					TransBubbleTextPos(180, 130),
//@					0,
//@				};
//@				pos = temppos;
//@			}
//@			if (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_NEW_GAME) {
//@				int []temppos = {
//@					TransBubbleTextPos(160, 200),
//@					TransBubbleTextPos(160, 200),
//@					TransBubbleTextPos(180, 200),
//@					TransBubbleTextPos(160, 200),
//@				};
//@				pos = temppos;
//@			}
//@			if (CGame._tempLevelId == DAI.LEVEL_ID_INTRO_THE_END) {
//@				int []temppos = {
//@					TransBubbleTextPos(160, 200),
//@					TransBubbleTextPos(160, 200),
//@					TransBubbleTextPos(180, 200),
//@					TransBubbleTextPos(160, 200),
//@				};
//@				pos = temppos;
//@			}
//@		}
//@		
//@		int len = TEXT_BUBBLE_TEXT_POS_ARRAY_SIZE;
//@		if(pos != null) {
//@			len = pos.length;
//@			_text_bubble_text_pos = new int[len];
//@			for(int i=len-1;i>=0;i--) {
//@				_text_bubble_text_pos[i] = pos[i];
//@			}
//@		} else {
//@			_text_bubble_text_pos = new int[len];
//@		}
//@		_text_bubble_text_pos_cursor = 0;
//@	}
//@	var TransBubbleTextPos(int posx, int posy) {
//@		return ((posx & 0xffff) << 16) | (posy & 0xffff);
//@	}
//@	static void UpdateBubbleTextIndex() {
//@		_text_bubble_text_pos_cursor ++;
//@	}
//@#endif
CGame.prototype.DrawTextBubble = function() {
	if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
		return true;
	}
	var camX = CEntity._camX;
	var camY = CEntity._camY;
	var isMiniMap = false;
	if (CGame._textBubbleCinematicID < 0) {
		isMiniMap = true;
	}
	if (isMiniMap) {
		camX = Math_IntToFixedPoint(CGame._miniMapCameraX);
		camY = Math_IntToFixedPoint(CGame._miniMapCameraY + CGame.MINI_MAP_OFFSET_Y);
	}
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@		//for ku580
//@		int pos = GetCurrentBubbleTextPos(_text_bubble_text_pos_cursor);
//@ 		int x = (pos & 0xffff0000)>>16;
//@		int y = pos & 0xffff;
//@#else
	var x = DEF.VIEW_W_D2;
	var y = Math_FixedPointToInt(CGame._textBubbleY - camY);
//@#endif
	var flags = 0;
	var lineCount = CGame.TEXT_BUBBLE_TEXT_LINE_COUNT;
	if (CGame._textBubbleBigOne) {
		y = DEF.VIEW_H_D2;
		lineCount += 1;
	} else {
		flags = CGame._textBubbleX < camX + DEF.VIEW_W_D2_FLOAT ? 0 : DFlags.FLIP_X;
		x += (flags & DFlags.FLIP_X) != 0 ? CGame.TEXT_BUBBLE_TEXT_ENTITY_OFFSET_X : -CGame.TEXT_BUBBLE_TEXT_ENTITY_OFFSET_X;
		if (!isMiniMap) {
			flags |= CGame._textBubbleY < camY + DEF.VIEW_H_D2_FLOAT ? DFlags.FLIP_Y : 0;
		}
		y += (flags & DFlags.FLIP_Y) != 0 ? CGame.TEXT_BUBBLE_TEXT_ENTITY_HEIGHT >> 2 : -CGame.TEXT_BUBBLE_TEXT_ENTITY_HEIGHT;
	}
	var text = Text_GetString(CGame._textBubbleText);
	var spr = CGame.spriteArray[DSpriteID.HINT];
	var time = CGame._textBubbleTime++;
	var animPopOut = DAnimID.HINT_DIALOG_POP_OUT;
	var animDisplay = DAnimID.HINT_DIALOG_DISPLAY;
	var animPopin = DAnimID.HINT_DIALOG_POP_IN;
	if (CGame._textBubbleX > camX + DEF.VIEW_W_D2_FLOAT / 2 && CGame._textBubbleX < camX + DEF.VIEW_W_D2_FLOAT + DEF.VIEW_W_D2_FLOAT / 2) {
		animPopOut = DAnimID.HINT_DIALOG_POP_OUT_3;
		animDisplay = DAnimID.HINT_DIALOG_DISPLAY_3;
		animPopin = DAnimID.HINT_DIALOG_POP_IN_3;
		if (isMiniMap) {
			animPopOut = DAnimID.HINT_DIALOG_POP_OUT_2;
			animDisplay = DAnimID.HINT_DIALOG_DISPLAY_2;
			animPopin = DAnimID.HINT_DIALOG_POP_IN_2;

		}
	}
	if (CGame._textBubbleBigOne) {
		if (CGame._textBubbleState < CGame.TEXT_BUBBLE_TEXT) {
			CGame._textBubbleState = CGame.TEXT_BUBBLE_TEXT;
		} else if (CGame._textBubbleState == CGame.TEXT_BUBBLE_CLOSE) {
			CGame.CloseTextBubble();
			return true;
		}
		animDisplay = DAnimID.HINT_DIALOG_POP;
	}
	switch (CGame._textBubbleState) {
	case CGame.TEXT_BUBBLE_OPEN:
		spr.PaintAFrame(g, animPopOut, time, x, y, flags);
		if (spr.GetAFrames(animPopOut) == time) {
			CGame._textBubbleState = CGame.TEXT_BUBBLE_TEXT;
		}
	break;
	case CGame.TEXT_BUBBLE_TEXT:
		spr.PaintAFrame(g, animDisplay, 0, x, y, flags);
		var rect = LowAPI.Gen_Array([4], 0);//new int[4];
		spr.GetAFrameRect(animDisplay, 0, 0, rect, flags);
		CGame.txtSetFont(fontSprSmall);
		var lineInterval = 0;
		// only text bubble use cursor
		var currentCursor = CGame._multiLineTextCurrentCursor;
		CGame._multiLineTextCurrentCursor = CGame._textBubbleCurrentCursor;
		var over = CGame.DrawMultiLineText(g, text, x   + rect[DEF.BOX_LEFT] , y + rect[DEF.BOX_TOP] , GRPH.LEFT_TOP, 1, rect[2], CGame._textBubbleCurrentLine, lineCount, lineInterval);
		CGame._textBubbleCurrentCursor = CGame._multiLineTextCurrentCursor;
		CGame._multiLineTextCurrentCursor = currentCursor;
		
		CGame.txtSetFont(fontSprBig);
//@#if not RemoveInterface
//@#if not TOUCH_SCREEN			
//@			CGame._interface.PaintAFrame(g, DAnimID.INTERFACE_CURSOR, s_game_currentFrameNB / 2 % CGame._interface.GetAFrames(DAnimID.INTERFACE_CURSOR), x + rect[DEF.BOX_LEFT]+ rect[2], y + rect[DEF.BOX_TOP] + rect[3], 0);
//@#else
		_touchInterface.PaintAFrame(g, DAnimID.TOUCHINTERFACE_PRESS_5_PEN, Math.floor(s_game_currentFrameNB / 3) % _touchInterface.GetAFrames(DAnimID.TOUCHINTERFACE_PRESS_5_PEN), x + rect[DEF.BOX_LEFT]+ rect[2], y + rect[DEF.BOX_TOP] + rect[3], 0);
//@#endif			
//@#endif		
		if (!CGame.bIsPaused && /*GLLib.*/ WasKeyPressed(GLKey.k_fire)) {
			if (CGame._textBubbleCurrentCursor != -1) {
				CGame._textBubbleCurrentCursor = -1;
			} else if (over) {
				CGame._textBubbleState = CGame.TEXT_BUBBLE_CLOSE;
				CGame._textBubbleTime = 0;
			} else {
				CGame._textBubbleCurrentLine += lineCount;
				CGame._textBubbleCurrentCursor = 0;
			}
		}
	break;
	case CGame.TEXT_BUBBLE_CLOSE:
		spr.PaintAFrame(g, animPopin, time, x, y, flags);
		if (spr.GetAFrames(animPopin) - 1 == time) {
			CGame.CloseTextBubble();
			return true;
		}
	break;
	}
	return false;
}

CGame.CloseTextBubble = function() {
	if (DEF.dbgEnable) Dbg("CloseTextBubble -----------------------------");
	if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
		return;
	}
	CGame._textBubbleState = CGame.TEXT_BUBBLE_OVER;
	CGame._textBubbleTime = 0;
	CGame._textBubbleBigOne = false;
	if (CGame._textBubbleCinematicID >= 0) {
		CGame._cinematicsFrameTime[CGame._textBubbleCinematicID] = -CGame._cinematicsFrameTime[CGame._textBubbleCinematicID];
	}
	CGame._textBubbleCurrentCursor = -1;
}
  CGame._multiLineTextIndex = LowAPI.Gen_Array([400], 0);//new short[400];
  CGame._multiLineTextIndexCount = 0;
  CGame._multiLineCurrentStr = null;
CGame._multiLineLineOff = null;
CGame._multiLineWordOff = LowAPI.Gen_Array([100], 0);//new int[100];
CGame._multiLineTextCurrentCursor = -1;
CGame._needSpecialProcess = false;
CGame.DrawMultiLineText  = function( g, str, x, y, align, palette,
		   lineWidth, startLine, lineCount, lineInterval) {
   if (str == null) {
	   return true;
   }
   var rawPalette = palette;
   CGame.InitMultiLineText(str, lineWidth, fontSpr);

   if (CGame._multiLineTextIndexCount <= 0) {
	   return true;
   }

   var lineHeight = fontSpr.GetLineHeight() + fontSpr.GetLineSpacing();
   if ((align & Graphics.VCENTER) != 0) {
	   var h = (lineHeight) * CGame._multiLineTextIndexCount / 2;
	   y -= h / 2;
   }
   else if ((align & Graphics.BOTTOM) != 0) {
	   var h = (lineHeight) * CGame._multiLineTextIndexCount / 2;
	   y -= h;
   }

   var startLineIndex = CGame._multiLineTextIndex[startLine << 1];
   var endLine = Math.min((startLine + lineCount - 1) << 1, CGame._multiLineTextIndexCount - 2);
   var overAtCursor = false;
   var lineIndexForHelpPage2 = 0;
   for (var lineCnt = startLine << 1; lineCnt <= endLine; lineCnt += 2) {
	   var endIndex = CGame._multiLineTextIndex[lineCnt + 1];
	   // Dbg("_______________ CGame._multiLineTextIndex[lineCnt + 1]: " + CGame._multiLineTextIndex[lineCnt + 1]);
	   if (CGame._multiLineTextCurrentCursor >= 0 && endIndex - startLineIndex > CGame._multiLineTextCurrentCursor) 
	   {
		   endIndex = startLineIndex + CGame._multiLineTextCurrentCursor;
		   overAtCursor = true;
	   }
	   // Dbg("________________ endIndex: " + endIndex);
	   var startIndex = CGame._multiLineTextIndex[lineCnt];
	   if ( /* CGame._needSpecialProcess && */ startIndex <= endIndex) {	
		   //char headCharOfCurrentLine = str.charAt(startIndex);
//@#if TOUCH_SCREEN    		   
		   var headOfTextInTheBracket = LowAPI.Gen_Array([2], 0);//new int [2];
		   var endOfTextInTheBracket = LowAPI.Gen_Array([2], 0);//new int [2];
//@#else
//@	    	   int headOfTextInTheBracket = 0;
//@	    	   int endOfTextInTheBracket = 0;
//@#endif	    	   
		   var LenghtOfCurrentLine = 0;
		   
		   // if (endIndex < str.length)
		   // {
				// Dbg("____________ endIndex: " + endIndex);
				// Dbg("____________ endIndex char: " + Integer.toHexString(str.charAt(endIndex)));
			// }
		   var currentLine = str.substring(startIndex, endIndex);
		   var textChars = currentLine.split('');//currentLine.toCharArray();
		   //boolean textInTheBracket = true;
		   var needChangePalete = false;
		   for ( var i = 0; i < textChars.length; i++) {
			   if (textChars[i] == '<' || textChars[i] == '(') {
//@#if TOUCH_SCREEN	    			   
				   headOfTextInTheBracket[headOfTextInTheBracket[0] == 0? 0:1] = i+1;
//@#else
//@	    			   headOfTextInTheBracket = i+1;
//@#endif	    			   
				   textChars[i] = '^';
				   //textInTheBracket = true;
				   if (currentLine.charAt(i) == '<') {
					   needChangePalete = true;
				   } else {
					   _eachLinePosY[lineIndexForHelpPage2++%3] = y - 7;
				   }
			   } else if (currentLine.charAt(i) == '>' || textChars[i] == ')') {
//@#if TOUCH_SCREEN
				   endOfTextInTheBracket[endOfTextInTheBracket[0] == 0? 0:1] = i-1;
//@#else
//@	    			   endOfTextInTheBracket = i-1;
//@#endif	    			   
				   textChars[i] = '^';
				   //textInTheBracket = false;
			   } else if (textChars[i] != '\n'){
				   LenghtOfCurrentLine += fontSpr.getCharSize(currentLine.charAt(i));
			   }
			   if (LenghtOfCurrentLine > lineWidth && textChars[i] == ' ') {
				   textChars[i] = '\n';
			   }
		   }
		   
		   var paletteForTextInTheBracket = 0;
		   var startPos_X_eachLine = 0;
//@#if TOUCH_SCREEN
		   if (_currentPage_Help == 2)
//@#else	    	   
//@	    	   if (_currentPage_Help == 1)
//@#endif	    		   
		   {
			   startPos_X_eachLine = _iconInHelpPosX + DGUI.INTERACE_TEXT_START_OFFSET_X;
		   } else {
			   // startPos_X_eachLine = x - DEF.VIEW_W_D2 + (DEF.VIEW_W - LenghtOfCurrentLine)/2;
				if(lineCount <= 3)
				startPos_X_eachLine = x;// - DEF.VIEW_W_D2 + (DEF.VIEW_W - LenghtOfCurrentLine)/2;
					else
				startPos_X_eachLine = x - DEF.VIEW_W_D2 + (DEF.VIEW_W - LenghtOfCurrentLine)/2;
		   }
		   for (var i = 0; i < textChars.length; i++) {
			   if(needChangePalete) {
//@#if TOUCH_SCREEN	    			   
					if ((i >= headOfTextInTheBracket[0] && i <= endOfTextInTheBracket[0]||
							i >= headOfTextInTheBracket[1] && i <= endOfTextInTheBracket[1])
							&& i > 0)
//@#else
//@						if (i >= headOfTextInTheBracket && i <= endOfTextInTheBracket) 
//@#endif							
					{
						fontSpr.SetCurrentPalette(paletteForTextInTheBracket);
					} else {
						fontSpr.SetCurrentPalette(palette);
					}		
			   } else {
				   fontSpr.SetCurrentPalette(palette);
			   }
			   if (textChars[i] == '^') {
				   continue;
			   }
			   fontSpr.SetSubString(i, i + 1);//ASprite.SetSubString(i, i+1);	
			   fontSpr.DrawStringOrChars(g, null, textChars, startPos_X_eachLine, y, 2, true);				
			   fontSpr.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
			   startPos_X_eachLine += fontSpr.getCharSize(textChars[i]);
		   }
	   } else {
		   CGame.txtDraw(palette, str, x, y, align, startIndex, endIndex);
	   }
	   if (overAtCursor) {
		   break;
	   }
	   y += lineHeight + lineInterval;
   }
   if (!CGame.bIsPaused && CGame._multiLineTextCurrentCursor >= 0 ) {
	   if (overAtCursor) {
		   CGame._multiLineTextCurrentCursor++;
	   } else {
		   CGame._multiLineTextCurrentCursor = -1;
	   }
   }
   fontSpr.SetSubString(-1, -1);//ASprite.SetSubString(-1, -1);
   return (startLine + lineCount) >= (CGame._multiLineTextIndexCount / 2);
   }
   
   CGame.prototype.StringTokenize = function( s, index1, index2,  token,  indices)
{
	var lines  = 0;
	indices[0] = index1 - 1;
	var tokenLen = token.length;

	for( var i = index1; i < index2; i++)
	{
		for(var j = tokenLen - 1; j>=0; j--) {
			if (s.charAt(i) == token[j]) {
				indices[++lines] = i;
				break;
			}
		}
	}

	indices[++lines] = index2;
	return lines;
}
   CGame.InitMultiLineText  = function( str, lineWidth, fontSpr)
{ 
	   if (CGame._multiLineCurrentStr == str || str == null) {
		   return;
	   }

	   CGame._multiLineCurrentStr = str;
	   str = str.trim().toUpperCase();
	CGame._multiLineLineOff = fontSpr.WraptextB(str, lineWidth, GLLibConfig.screenHeight);
	var len = CGame._multiLineLineOff.length;
	
	// for (int j = 1; j < len; j += 2)
	// {
		// Dbg("___________ CGame._multiLineLineOff: " + CGame._multiLineLineOff[j]);
	// }
	CGame._multiLineTextIndex[0] = 0;
	CGame._multiLineTextIndex[1] = CGame._multiLineLineOff[1];
	for (var i = 3; i < len; i += 2)
	{
		CGame._multiLineTextIndex[i - 1] = CGame._multiLineLineOff[i - 2];
		CGame._multiLineTextIndex[i] = CGame._multiLineLineOff[i];
	}
	CGame._multiLineTextIndexCount = CGame._multiLineLineOff[0] << 1;
   }
CGame.prototype.GetStringWidth  = function(text, begin, end) {
	fontSpr.SetSubString(begin, end);//ASprite.SetSubString(begin, end);
		fontSpr.UpdateStringOrCharsSize(text, null);
		return ASprite._text_w;
}

CGame.INTERFACE_DRAW_CRYSTAL = 0;
CGame.INTERFACE_DRAW_1UP = 1;
CGame.INTERFACE_DRAW_GOLDEN_COIN = 2;
CGame.INTERFACE_DRAW_STAR = 3;

CGame._drawInterface = 0;
CGame.interfaceShowTime = LowAPI.Gen_Array([8], 0);//new int[8];
CGame.interfaceOffset = LowAPI.Gen_Array([8], 0);//new int[8];
CGame.OFFSET_MAX = 30;
CGame.ShowInterfaceElement = function( id) {
	if (id < CGame.interfaceShowTime.length) {
		CGame.interfaceOffset[id] = 0;
		CGame.interfaceShowTime[id] = GLLibConfig.FPSLimiter * 2;

		if (id == DValueList.BONUS_TYPE_CAKE) {
			CGame.interfaceShowTime[id] = CGame.spriteArray[DSpriteID.EFFECT].GetAFrames(DAnimID.EFFECT_RANDOM_MAGIC);
		} else if (id == DValueList.BONUS_TYPE_STAR) {
			CGame.interfaceShowTime[id] = GLLibConfig.FPSLimiter << 2;
		} else if (id == DValueList.BONUS_TYPE_GOLD_COIN) {
			CGame.interfaceShowTime[id] = GLLibConfig.FPSLimiter << 2;
		}
	}
}
//@#if not RemoveInterface
CGame.prototype.DrawInterface = function() {
//@#if not Use_Motion_Sensor
	var drawMorphEnergy = CEntity.AI_Hero_CheckMorph(DAI.HERO_MORPH_FAT);
//@#else
//@		boolean drawMorphEnergy = (CEntity._HeroPoweredBullet || CEntity.AI_Hero_CheckMorph(DAI.HERO_MORPH_FAT));
//@#endif
	var drawMorph = !CEntity.AI_Hero_CheckMorph(DAI.HERO_MORPH_NONE); 
	var drawHP = !drawMorphEnergy;
	if (drawMorph) {
		drawHP = !drawMorphEnergy;
		// draw life
		var interfaceOff = CEntity.AI_Hero_GetMorph() - DAI.HERO_MORPH_FAT;
		if(CEntity.AI_Hero_GetMorph() == DAI.HERO_MORPH_SWORD_FISH_ATTACK) {
			interfaceOff --;
		}
		CGame._interface.PaintFrame(g,
				DAnimID.INTERFACE_FRAME_PORTRAIT_FAT + interfaceOff, DGUI.INTERFACE_MARGIN_HORIZONTAL, DGUI.INTERFACE_MARGIN_VERTICAL, 0);
	} else {
		// draw life
		CGame._interface.PaintFrame(g,
				DAnimID.INTERFACE_FRAME_PORTRAIT, DGUI.INTERFACE_MARGIN_HORIZONTAL, DGUI.INTERFACE_MARGIN_VERTICAL, 0);
	}
	CGame._interface.PaintFrame(g,
			DAnimID.INTERFACE_FRAME_X, DGUI.INTERFACE_LIFE_OFFSET_X, DGUI.INTERFACE_MARGIN_VERTICAL_FORK, 0);

	CGame.DrawInterfaceNumber(CEntity._HeroParams[DAI.HPI_LIVES], DGUI.INTERFACE_LIFE_NUM_OFFSET_X, DGUI.INTERFACE_MARGIN_VERTICAL_NUM, 1, 0);

	if (drawMorphEnergy) {
		CGame._interface.PaintFrame(g,
				DAnimID.INTERFACE_FRAME_FAT_FRAME, DGUI.INTERFACE_MARGIN_ENERGY_HORIZONTAL, DGUI.INTERFACE_MARGIN_ENERGY_HEIGHT, 0);
		g.setClip(DGUI.INTERFACE_MARGIN_ENERGY_HORIZONTAL + DGUI.INTERFACE_FAT_FILL_OFFSET_X, DGUI.INTERFACE_MARGIN_ENERGY_HEIGHT, CEntity._HeroMorphEnergy * DGUI.INTERFACE_FAT_FILL_WIDTH / 100, DGUI.INTERFACE_BOTTOM_HEIGHT);
		CGame._interface.PaintFrame(g,
				DAnimID.INTERFACE_FRAME_FAT_FILL, DGUI.INTERFACE_MARGIN_ENERGY_HORIZONTAL, DGUI.INTERFACE_MARGIN_ENERGY_HEIGHT, 0);
		g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
	}

	CGame._interface.PaintAFrame(	g,
							DAnimID.INTERFACE_DIAMOND,
							s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.INTERFACE_DIAMOND),
							DGUI.INTERFACE_CRYSTAL_OFFSET_X, DGUI.INTERFACE_CRYSTAL_OFFSET_Y, 0);
	
	CGame._interface.PaintFrame(	g,
							DAnimID.INTERFACE_FRAME_X, 
							DGUI.INTERFACE_CRYSTAL_NUM_OFFSET_X, DGUI.INTERFACE_MARGIN_VERTICAL_FORK, 0);
	//CGame.DrawInterfaceNumber(CEntity._HeroParams[DAI.HPI_CRYSTAL_COUNT], DGUI.INTERFACE_CRYSTAL_NUM_OFFSET_X + DGUI.INTERFACE_X_WIDTH, DGUI.INTERFACE_CRYSTAL_NUM_OFFSET_Y, 2);
	//CEntity._hero._hp = 10;
	CGame.DrawInterfaceNumber(	CEntity._hero._hp, 
							DGUI.INTERFACE_CRYSTAL_NUM_OFFSET_X + DGUI.INTERFACE_X_WIDTH + DGUI.INTERFACE_X_WIDTH_MARGIN, 
							DGUI.INTERFACE_MARGIN_VERTICAL_NUM, 1, 0);

	//draw the left soft key

	if (CGame.interfaceShowTime[DValueList.BONUS_TYPE_1UP] > 0) {
		CGame.interfaceShowTime[DValueList.BONUS_TYPE_1UP]--;
		//CGame.spriteArray[DSpriteID.BONUS].PaintFrame(g, DAnimID.BONUS_FRAME_1UP1, DGUI.INTERFACE_1UP_OFFSET_X, DGUI.INTERFACE_1UP_OFFSET_Y, 0);
	}

	if (CGame.interfaceShowTime[DValueList.BONUS_TYPE_GOLD_COIN] > 0) {
		CGame.interfaceShowTime[DValueList.BONUS_TYPE_GOLD_COIN]--;
		var frame = s_game_currentFrameNB %CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_GOLDEN_COIN);
		var x, y;
		x = DGUI.INTERFACE_STAR_OFFSET_X;
		y = DGUI.INTERFACE_STAR_OFFSET_Y -  18 * DScreen.RATIO; //bugID 9736143
		CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_GOLDEN_COIN, frame, x, y, 0);
		x += 20 * DScreen.RATIO;
		y += - 14 * DScreen.RATIO;
		CGame._interface.PaintFrame(g,
				DAnimID.INTERFACE_FRAME_X, x, y, 0);
		x += 20 * DScreen.RATIO;
		y += -5 * DScreen.RATIO;
		if(CEntity._HeroParams[DAI.HPI_GOLDCOIN_COUNT] <= 0) {
			CGame._interface.SetCurrentPalette(1);
		}
		CGame.DrawInterfaceNumber(CEntity._HeroParams[DAI.HPI_GOLDCOIN_COUNT], x, y, 1, 0);
		CGame._interface.SetCurrentPalette(0);
	}

	if (CGame.interfaceShowTime[DValueList.BONUS_TYPE_STAR] > 0) {
		CGame.interfaceShowTime[DValueList.BONUS_TYPE_STAR]--;
		var frame = s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_STAR);
		var x, y;
		x = DGUI.INTERFACE_STAR_OFFSET_X;
		y = DGUI.INTERFACE_STAR_OFFSET_Y - 18 * DScreen.RATIO;
		CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(g, DAnimID.BONUS_STAR, frame, x, y, 0);
		x += 20 * DScreen.RATIO;
		y += - DGUI.BONUS_STAR_OFFSETY;
		CGame._interface.PaintFrame(g, DAnimID.INTERFACE_FRAME_X, x, y, 0);
		x += 20 * DScreen.RATIO;
		y += -4 * DScreen.RATIO;
		CGame.DrawInterfaceNumber(DAI.MAX_STAR_NUM - CGame._levelStarInfo[CGame._tempLevelId*DAI.STAR_INFO_SIZE], x, y, 1, 0);
	}

	if (CGame.interfaceShowTime[DValueList.BONUS_TYPE_CAKE] > 0) {
		var frame = CGame.spriteArray[DSpriteID.EFFECT].GetAnimFrame(DAnimID.EFFECT_RANDOM_MAGIC, CGame.spriteArray[DSpriteID.EFFECT].GetAFrames(DAnimID.EFFECT_RANDOM_MAGIC) - CGame.interfaceShowTime[DValueList.BONUS_TYPE_CAKE]);
		CGame.spriteArray[DSpriteID.EFFECT].PaintFrame(g,
				frame, DGUI.INTERFACE_MORPH_EFFECT_OFFSET_X, DGUI.INTERAFCE_HERO_CHANGE_EFFECT_Y, 0);

		CGame.spriteArray[DSpriteID.EFFECT].PaintFrame(g,
				frame, DGUI.INTERFACE_MORPH_EFFECT_OFFSET_X_2, DGUI.INTERAFCE_HERO_CHANGE_EFFECT_Y, 0);

		CGame.spriteArray[DSpriteID.EFFECT].PaintFrame(g,
				frame, DGUI.INTERFACE_MORPH_EFFECT_OFFSET_X_3, DGUI.INTERAFCE_HERO_CHANGE_EFFECT_Y, 0);
		CGame.interfaceShowTime[DValueList.BONUS_TYPE_CAKE]--;
	}
}
CGame._itoa_buffer = LowAPI.Gen_Array([16], 0);//new int [16];
CGame.DrawInterfaceNumber = function( num, x, y, minDigit, flags) {
	var t = num;
	var digit = -1;
	
	//auto increase when num length > minDigit
	while (t > 0){
		digit++;			
		t = Math.floor(t/10);//t /= 10;
	}
	if (digit < minDigit )
		digit = minDigit - 1;
	else
		minDigit = digit +1;
		
	
	for (var i = 0; i < minDigit; i++) {
		CGame._itoa_buffer[i] = 0;
	}
	t = num;
	if (num < 0) {
		// CGame._itoa_buffer[count++] = '-';
//			t = -num;
		t = 0;
	}
	do {
		CGame._itoa_buffer[digit--] = t % 10;
		t = Math.floor(t/10);//t /= 10;
	} while (t > 0 && digit >= 0);
	if ((flags & GRPH.VCENTER) != 0) {
		y -= CGame._interface.GetFrameModuleHeight(DAnimID.INTERFACE_FRAME_0, 0) >> 1;
	}
	if ((flags & GRPH.HCENTER) != 0) {
		var w = 0;
		for (var i = 0; i < minDigit; i++) {
			var frame = DAnimID.INTERFACE_FRAME_0 + CGame._itoa_buffer[i];
			w += CGame._interface.GetFrameModuleWidth(frame, 0);
		}
		x -= w >> 1;
	}
	for (var i = 0; i < minDigit; i++) {
		var frame = DAnimID.INTERFACE_FRAME_0 + CGame._itoa_buffer[i];
		CGame._interface.PaintFrame(g, frame, x, y, 0);
		x += CGame._interface.GetFrameModuleWidth(frame, 0);
	}
}

//@#endif
// Update action phase logic
CGame.prototype.gameUpdate = function() //throws Exception
{
	// try {
	if (_pauseType != DPauseType.NONE) {
		if (this.PauseUpdate()) {
			return;
		}
	}

	// update all entity
	CEntity.UpdateAll(-1);
	//CEntity._gli = null;		
	if (CEntity._checkDropToGound) {
		CEntity._hero._vY = DAI.GRAVITY;
		CEntity.UpdateAll(-1);
		CEntity._checkDropToGound = false;
		CGame.SetPause(DPauseType.FADE_IN, DPauseType.FADE_EFFECT_CIRCLE);
		CEntity._hero.StateMachineChangeState(DState.STATE_ONGROUND, DState.SS_GO_OUTDOOR, 0);
	}
	CGame.UpdateCinematic();

	_keycode = WasAnyKeyReleased();
	if (_keycode >= 0)
	{
		// update key
		if (_keycode == GLKey.k_menuOK || (s_game_interruptNotify && !CGame.bIsPaused))
		{
			CGame.initIngameMenu(STATE.MENU_INGAME);
		}
		//gb code added for online part ..
		if (_keycode == GLKey.k_menuBack)
		{
			if (CGame.InCinemitic()) {
				CGame.SkipCinemitic();
				CEntity.CheckActive();
				CEntity.UpdateAll(-1);
			}
//				} else if (Build.useXplayer) {  // removed by ltl , for glive
//				 	Dbg("creating xplayer....");
//				 	interactiv = new XPlayer(s_application);
//					s_game_state = STATE.MENU_GAMELOFT_LIVE;
//					_onlineState = DOnlineState.INIT;
//				}
		}
	}
	// } catch ( e) {
		// Dbg("gameUpdate()");
		// e.printStackTrace();
	// }
}

CGame.initIngameMenu = function( state) {
	CGame.bIsPaused = true;
	CGame.bIsMiniMap = s_game_state == STATE.MENU_MAP;
	s_game_state = state;
	menuSelection = LowAPI.Gen_Array([MENU.MAX_DEPTH], 0);//new int[MENU.MAX_DEPTH];
	currentMenu = LowAPI.Gen_Array([MENU.MAX_DEPTH], 0);//new int[MENU.MAX_DEPTH];
	currentMenuDepth = 0;
	currentMenu[currentMenuDepth] = MENU_INGAME_INDEX;
	CGame.redrawAll = true;
	if(state == STATE.MENU_INGAME)
		CGame.PauseSoundBGM();
}

CGame.prototype.PauseUpdate = function() {
	var pauseOver = false;
	if (_pauseType == DPauseType.FADE_OUT || _pauseType == DPauseType.FADE_IN) {
		switch (_pauseParam) {
		case DPauseType.FADE_EFFECT_BLACK:
			if (_pauseType == DPauseType.FADE_OUT) {
				_fade_effect_alpha += Math_FixedPointToInt(/*GLLib.*/Math_FixedPoint_Multiply(DAI.EFFECT_FADE_VELOCITY, CGame._velocityRate));
				if (_fade_effect_alpha >= 0xFF) {
					_fade_effect_alpha = 0xFF;
					pauseOver = true;
				}
			} else if (_pauseType == DPauseType.FADE_IN) {
				_fade_effect_alpha -= Math_FixedPointToInt(/*GLLib.*/Math_FixedPoint_Multiply(DAI.EFFECT_FADE_VELOCITY, CGame._velocityRate));
				if (_fade_effect_alpha <= 0) {
					_fade_effect_alpha = 0;
					pauseOver = true;
				}
			}
			break;
		case DPauseType.FADE_EFFECT_CIRCLE:
			if (_pauseType == DPauseType.FADE_OUT) {
				if (_pauseTick > -DEF.TILE_W << 1) {
					_pauseTick -= DEF.TILE_W << 1;
				} else {
					pauseOver = true;
				}
			} else if (_pauseType == DPauseType.FADE_IN) {
				if (_pauseTick < DEF.SCR_H_D2 + (DEF.SCR_H_D2 >> 1)) {
					_pauseTick += DEF.TILE_W << 1;
				} else {
					pauseOver = true;
				}
			}
			break;
			
		case DPauseType.FADE_EFFECT_SCANLINE:
			if (_pauseType == DPauseType.FADE_OUT) {
				if (_pauseTick > 0) {
					_pauseTick -= 10 * DScreen.RATIO;
					if(_pauseTick<0)
						_pauseTick = 0;
				} else {
					pauseOver = true;
				}
			} else if (_pauseType == DPauseType.FADE_IN) {
				if (_pauseTick < DEF.SCR_W) {
					_pauseTick += 10 * DScreen.RATIO;
					if(_pauseTick>DEF.SCR_W)
						_pauseTick = DEF.SCR_W;
				} else {
					pauseOver = true;
				}
			}
		}
	}
	if (pauseOver) {
		CGame.SetPause(DPauseType.NONE , 0);
		return false;
	}
	return true;
}

CGame.SetPause = function( type, param) {
	_pauseType = type;
	_pauseParam = param;
	_pauseTick = 0;
	if (type == DPauseType.FADE_OUT) {
		if (param == DPauseType.FADE_EFFECT_CIRCLE) {
			_pauseTick = DEF.SCR_H_D2 + (DEF.SCR_H_D2 >> 1);
		}
	}
}

CGame.prototype.DrawFadeEffect = function() {
	if (_pauseType == DPauseType.FADE_IN || _pauseType == DPauseType.FADE_OUT) {
		switch (_pauseParam) {
		case DPauseType.FADE_EFFECT_BLACK:
			if (_fade_effect_alpha > 0) {
				CGame.FillArgbRect(0, 0, DEF.SCR_W, DEF.SCR_H, (_fade_effect_alpha << 24) | _fade_effect_rgb);
			}
			break;
		case DPauseType.FADE_EFFECT_CIRCLE:
			var x,y;
			var focus = CEntity._hero;
			if (focus != null) {
				x = Math_FixedPointToInt(focus._posX - CEntity._camX);
				y = Math_FixedPointToInt(focus._posY + focus._boundingBox[DEF.BOX_TOP] - CEntity._camY);
			} else {
				x = _fade_circle_centerX;
				y = _fade_circle_centerY;
			}
			CGame.DrawFadeCircle(g, x, y, _pauseTick);
			break;
			
		case DPauseType.FADE_EFFECT_SCANLINE:
			this.DrawFadeScanLine(g, 1 * DScreen.RATIO, _pauseTick);
			break;
		}
	}
}
CGame.prototype.DrawWeatherEffect = function() {
//@#if not RemoveWeather
//@		if (_weather == WEATHER_RAIN) {
//@			DrawRain(g);
//@			DrawLightningFlash(g);
//@		} else if (_weather == WEATHER_SNOW) {
//@			DrawSnow(g, 0xFFFFFF);
//@		}
//@#endif
}

CGame.prototype.DrawFadeScanLine = function( g, lineH, dt)
{
	if(lineH<=0)
		return;
	g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
	g.setColor(0);
	for(var i = 0; i < Math.floor(DEF.SCR_H / lineH) + 1; i++) {
		if(i % 2 == 0) {
			g.fillRect(_pauseTick - DEF.SCR_W, i * lineH, DEF.SCR_W, lineH);
		} else {
			g.fillRect(DEF.SCR_W - _pauseTick, i * lineH, DEF.SCR_W, lineH);
		}
	}
}

CGame.DrawFadeCircle  = function( g, x, y, r) {
	// Dbg("WARNING : Ignore drawArc right now , will update later.");
 	r = Math.max(r, 0);
	var d = ((512 - 362) * r) >> 8; //2 * 256 = 512; 1.414 * 256 = 362
	// g.setColor(0xFF000000);
	SetColor(0xFF000000);
	// var radius = (r * 277) >> 8;
	// DrawArc(x - r, y - r, 2*r, 2*r, 0, 360);
	// DrawArc(x - radius, y - radius, 2*radius, 2*radius, 0, 360);
/*	for (var R = r; R < (r * 277) >> 8; ++R) {
		// g.drawArc(x-R, y-R, 2*R, 2*R, 0, 360);
		DrawArc(x-R, y-R, 2*R, 2*R, 0, 360);
	}
 	for (var R = r; R <= (r * 277) >> 8; ++R) {
		// g.drawArc(x-R-1, y-R, 2*R, 2*R, 0, 360);
		DrawArc(x-R-1, y-R, 2*R, 2*R, 0, 360);
	}
	for (var R = r; R <= (r * 277) >> 8; ++R) {
		// g.drawArc(x-R+1, y-R, 2*R, 2*R, 0, 360);
		DrawArc(x-R+1, y-R, 2*R, 2*R, 0, 360);
	} */
//@#if BREW_FillTriangle
//@    	g.fillTriangle(x-r-d, y-r, x-r, y-r, x-r, y-r+d);
//@    	g.fillTriangle(x+r-d, y+r, x+r, y+r, x+r, y+r-d);
//@    	g.fillTriangle(x-r+d, y+r, x-r, y+r, x-r, y+r-d);
//@    	g.fillTriangle(x+r+d, y-r, x+r, y-r, x+r, y-r+d);
//@#else // BREW_FillTriangle
	g.fillTriangle(x+r-d, y-r, x+r, y-r, x+r, y-r+d);
	g.fillTriangle(x+r-d, y+r, x+r, y+r, x+r, y+r-d);
	g.fillTriangle(x-r+d, y+r, x-r, y+r, x-r, y+r-d);
	g.fillTriangle(x-r+d, y-r, x-r, y-r, x-r, y-r+d);
	
	// var dt = Math.floor(d/2);
	// g.fillTriangle(x-r+dt, y-r+dt, x, y-r, x-r+d, y-r);
	// g.fillTriangle(x+r-dt, y-r+dt, x, y-r, x+r-d, y-r);
	// g.fillTriangle(x+r-dt, y-r+dt, x+r, y-r+d, x+r, y);
	// g.fillTriangle(x+r-dt, y+r-dt, x+r, y, x+r, y+r-d);
	// g.fillTriangle(x+r-dt, y+r-dt, x, y+r, x+r-d, y+r);
	// g.fillTriangle(x-r+dt, y+r-dt, x, y+r, x-r+d, y+r);
	// g.fillTriangle(x-r+dt, y+r-dt, x-r, y, x-r, y+r-d);
	// g.fillTriangle(x-r+dt, y-r+dt, x-r, y, x-r, y-r+d);
//@#endif // BREW_FillTriangle
	if (y - r > 0)
		g.fillRect(0, 0, DEF.SCR_W, y - r);
	if (x - r > 0)
		g.fillRect(0, 0, x - r, DEF.SCR_H);
	if (DEF.SCR_W - x + r > 0)
		g.fillRect(x + r, 0, DEF.SCR_W - x + r, DEF.SCR_H);
	if (DEF.SCR_H - y + r > 0)
		g.fillRect(0, y + r, DEF.SCR_W, DEF.SCR_H - y + r);
}

//@#if not RemoveWeather
//@    // draw the snow effect
//@	var _weather = 0;
//@
//@	var WEATHER_RAIN = 1;
//@	var WEATHER_SNOW = 2;
//@    // draw the snow effect
//@	private var WEATHER_SNOW_OBJECT_NUMBER = 80;
//@	private var WEATHER_RAIN_OBJECT_NUMBER = 20;
//@	private var WEATHER_SNOW_WIND_BASE_DURATION = 80;
//@	private var WEATHER_RAIN_ANGLE = /*GLLib.*/Math_DegreeToFixedPointAngle(20);
//@	private var WEATHER_BLOCK_TEST_LENGTH = DEF.VIEW_W + DEF.VIEW_H;
//@	private var WEATHER_RAIN_LENGTH = 14;
//@	private var WEATHER_RAIN_UNIT_X = 121;
//@	private var WEATHER_RAIN_UNIT_Y = -225;
//@
//@	private var _weatherX = new int[WEATHER_SNOW_OBJECT_NUMBER];
//@	private var _weatherY = new int[WEATHER_SNOW_OBJECT_NUMBER];
//@	private var _weatherVX = new int[WEATHER_SNOW_OBJECT_NUMBER];
//@	private var _weatherVY = new int[WEATHER_SNOW_OBJECT_NUMBER];
//@	private var _weatherVolume = new byte[WEATHER_SNOW_OBJECT_NUMBER];
//@	private var _weatherSnowWindDirection; // wind direction
//@	private var _weatherSnowWindTick; // wind direction duration
//@	static private boolean _weatherIsSnowInit = false; // whether snow pixel has been inited
//@	static private boolean _weatherIsRainInit = false; // whether rain pixel has been inited
//@	/**
//@	* the method draw the snow effect
//@	* @param g Graphics
//@	*/
//@	private static void DrawSnow(Graphics g, int color) {
//@		Random r = new Random();
//@		int i;
//@		int camX = Math_FixedPointToInt(CEntity._camX);
//@		int camY = Math_FixedPointToInt(CEntity._camY);
//@		if (!_weatherIsSnowInit) {
//@			for (i = 0; i < WEATHER_SNOW_OBJECT_NUMBER; i++) {
//@				_weatherX[i] = /*GLLib.*/Math_Rand(0, DEF.VIEW_W) + camX;
//@				_weatherY[i] = /*GLLib.*/Math_Rand(0, DEF.VIEW_H) + camY;
//@				_weatherVX[i] =  (r.nextInt() % 2);
//@				if (/*GLLib.*/Math_Rand(0, 6) == 0) {
//@					_weatherVolume[i] = 2;
//@				} else if (/*GLLib.*/Math_Rand(0, 3) == 0) {
//@					_weatherVolume[i] = 1;
//@				} else {
//@					_weatherVolume[i] = 0;
//@				}
//@			}
//@			_weatherIsRainInit = false;
//@			_weatherIsSnowInit = true;
//@		}
//@		g.setColor(color);
//@
//@		if (_pauseType == DPauseType.NONE) {
//@			if (_weatherSnowWindTick > 1) {
//@				--_weatherSnowWindTick;
//@			} else {
//@				if (_weatherSnowWindDirection != 0) {
//@					_weatherSnowWindDirection -= _weatherSnowWindDirection > 0 ? 1 : -1;
//@					_weatherSnowWindTick = 3;
//@					if (_weatherSnowWindDirection == 0)
//@						_weatherSnowWindTick = WEATHER_SNOW_WIND_BASE_DURATION +  (r.nextInt() % 30);
//@				}
//@				else {
//@					_weatherSnowWindTick = WEATHER_SNOW_WIND_BASE_DURATION +  (r.nextInt() % 30);
//@					_weatherSnowWindDirection = /*GLLib.*/Math_Rand(-7, 8);
//@				}
//@			}
//@		}
//@
//@		for (i = 0; i < WEATHER_SNOW_OBJECT_NUMBER; i++) {
//@			if (_pauseType == DPauseType.NONE) {
//@				_weatherX[i] += _weatherVX[i] + _weatherSnowWindDirection;
//@
//@				_weatherY[i]++;
//@				if (_weatherVolume[i] == 0) {
//@					_weatherY[i]++;	
//@				}
//@
//@				_weatherX[i] = ((_weatherX[i] - camX) + DEF.VIEW_W) % DEF.VIEW_W + camX;
//@				_weatherY[i] = ((_weatherY[i] - camY) + DEF.VIEW_H) % DEF.VIEW_H + camY;
//@
//@			}
//@			if (_weatherVolume[i] != 0) {
//@				g.drawRect(_weatherX[i] - camX, _weatherY[i] - camY, 0, 0);
//@			} else {
//@				g.drawRect(_weatherX[i] - camX, _weatherY[i] - camY, 1, 1);
//@			}
//@		}
//@	}
//@
//@	/**
//@	 * draw rain effect
//@	 * @param g graphics
//@	 */
//@	private static void DrawRain(Graphics g) {
//@	    int camX = Math_FixedPointToInt(CEntity._camX);
//@		int camY = Math_FixedPointToInt(CEntity._camY);
//@		int i;
//@		if (!_weatherIsRainInit) {
//@			for (i = 0; i < WEATHER_RAIN_OBJECT_NUMBER; i++) {
//@				_weatherX[i] = i * 8;
//@				_weatherY[i] = /*GLLib.*/Math_Rand(0, DEF.VIEW_H);
//@				_weatherVX[i] = /*GLLib.*/Math_Rand(0, DEF.VIEW_W);
//@				_weatherVY[i] = /*GLLib.*/Math_Rand(0, DEF.VIEW_H);
//@				_weatherVolume[i] =  (WEATHER_RAIN_LENGTH + /*GLLib.*/Math_Rand(-6, 6));
//@			}
//@			_weatherIsSnowInit = false;
//@			_weatherIsRainInit = true;
//@		}
//@		g.setColor(0xCFCFCFCF);
//@
//@		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
//@		int changeId = s_game_currentFrameNB % 3;
//@		for (i = 0; i < WEATHER_RAIN_OBJECT_NUMBER; i++) {
//@			if (_pauseType == DPauseType.NONE) {
//@				if (_weatherVolume[i] == 0) {
//@					_weatherX[i] -= 18;
//@					_weatherY[i] += 45;
//@				} else {
//@					_weatherX[i] -= 18;
//@					_weatherY[i] += 47;
//@				}
//@				_weatherX[i] = ((_weatherX[i] - camX) + DEF.VIEW_W) % DEF.VIEW_W + camX;
//@				_weatherY[i] = ((_weatherY[i] - camY) + DEF.VIEW_H) % DEF.VIEW_H + camY;
//@				boolean result = CEntity.CheckRainBlock(Math_IntToFixedPoint(_weatherX[i]), Math_IntToFixedPoint(_weatherY[i]), 
//@						Math_IntToFixedPoint(/*GLLib.*/Math_FixedPoint_Multiply(WEATHER_RAIN_UNIT_X, WEATHER_BLOCK_TEST_LENGTH)), 
//@						Math_IntToFixedPoint(/*GLLib.*/Math_FixedPoint_Multiply(WEATHER_RAIN_UNIT_Y, WEATHER_BLOCK_TEST_LENGTH)));
//@				if (result) {
//@					_weatherVolume[i] = 0;
//@					_weatherVX[i] = Math_FixedPointToInt(/*GLLib.*/s_Math_intersectX) - camX;  
//@					_weatherVY[i] = Math_FixedPointToInt(/*GLLib.*/s_Math_intersectY) - camY;  
//@				} else {
//@					_weatherVolume[i] = 1;
//@				}
//@			}
//@			if (_weatherVolume[i] == 0) {
//@				if ((i % 2) == 0) {
//@					CGame.spriteArray[DSpriteID.WEATHER].PaintAFrame(g, DAnimID.WEATHER_YU, s_game_currentFrameNB % 3, _weatherVX[i], _weatherVY[i], 0, 0, 0);
//@				}
//@              // g.drawRect(snowX[i]-s_cameraX,snowY[i]-m_cameraY,0,0);
//@              // g.drawLine(s_snowX[i] - s_cameraX, s_snowY[i] - s_cameraY,
//@				// s_snowX[i] - s_cameraX - 1, s_snowY[i] - s_cameraY + 1);
//@			} else {
//@				g.drawLine(_weatherX[i] - camX, _weatherY[i] - camY, _weatherX[i] - camX + /*GLLib.*/Math_FixedPoint_Multiply(WEATHER_RAIN_UNIT_X, WEATHER_RAIN_LENGTH), _weatherY[i] - camY + /*GLLib.*/Math_FixedPoint_Multiply(WEATHER_RAIN_UNIT_Y, WEATHER_RAIN_LENGTH));
//@			}
//@		}
//@	}	
//@  
//@  	private var _lightningFlashTick;
//@    private static void DrawLightningFlash (Graphics g) {
//@    	if (_lightningFlashTick > 0) {
//@    		int c = _lightningFlashTick > 1 ? 0xCFFFFFFF : 0x6FFFFFFF;
//@    		CGame.FillArgbRect(0, 0, DEF.VIEW_W, DEF.VIEW_H, c);
//@
//@    		++_lightningFlashTick;
//@    		if (_lightningFlashTick >= /*GLLib.*/Math_Rand(2, 4)) {
//@    			_lightningFlashTick = 0;
//@    		}
//@    	} else {
//@    		if (/*GLLib.*/Math_Rand(0, 200) < 1) {
//@    			_lightningFlashTick = 1;
//@    		}
//@    	}
//@    }
//@#endif
CGame.InitLevel = function()
{
	CGame._entitiesRowData = LowAPI.Gen_Array([4000],null);//new short[4000][];
	CGame._entitiesRowTable.clear();
	CGame._entityMap.clear();
	CGame._entityRowDataCount = 0;
	CGame._sprites_load_mask = DSpriteID.DEFAULT_SPRITES_LOAD_MASK;
//@#if not RemoveWeather
//@		_weather = 0;
//@		if (CGame._worldId == DAI.WORLD_ID_PIRATE && (CGame._tempLevelId == 5 || CGame._tempLevelId == 7)) {
//@			_weather = WEATHER_RAIN;
//@		}
//@#if not RemoveIceLevel		
//@		if (CGame._worldId == DAI.WORLD_ID_ICE) {
//@			_weather = WEATHER_SNOW;
//@		}
//@#endif		
//@		if (_weather != 0) {
//@			CGame._sprites_load_mask |= CEntity.GetSpriteLoadMask(DSpriteID.WEATHER);
//@		}
//@#endif
}

CGame.ReleaseLevel = function( heroDie) {
	CEntity._camFocus = null;
	CEntity._camFocusA = null;
	CEntity._camFocusB = null;
	if (!heroDie && (CEntity._hero != null)) {
		CEntity._HeroParams[DAI.HPI_LIVES] = CGame._playerInfo[DAI.HPI_LIVES];
		CEntity._hero._hp = CGame._playerInfo[DAI.HPI_HP_MAX];
	}
	CEntity._hero = null;
	CEntity._boss = null;
	CEntity._camera = null;
	CEntity._cameraDefault = null;
	CEntity._camOffsetY = 0;
	CEntity._bullet = null;
	CEntity._HeroIce = null;
	CEntity._ThiefSoundBubbleLeft = null;
	CEntity._ThiefSoundBubbleRight = null;
	CEntity._TentacleSide = -1;
	CEntity._HurtByTentacle = false;
	CEntity._HeroKickableEntity = null;
	CEntity._HeroRelateEntity = null;
	CEntity._HeroMorphEnergy = 0;
	CEntity._arrowShakeNum = 0;
//		CEntity._HeroLiftEntity = null;
	CGame._entitiesRowTable.clear();
	CGame._entityMap.clear();
	CGame._entitiesRowData = null;
	CGame._entityRowDataCount = 0;
	CEntity.s_levelRenderCount = 0;
	CEntity._HeroInElectric = 0;
	CEntity._HeroBeAttackByInkbomb = false;
	CEntity._HeroShowInkTime = 0;
	CEntity._BossOctopusHurt = false;
	CEntity._BossOctopusHurtBySit = false;
	CEntity._inMiniGame = false;
	CGame._textBubbleState = CGame.TEXT_BUBBLE_OVER;
	CGame._textBubbleTime = 0;
	initialPosForChars = null;
	CGame._firstEnterIntoThisFunction = true;
	CGame._inCinematicBlackScreen = false;
	CEntity._monsterchestHP = null;
	CGame._popUpEnded = false;
	CEntity._camCircularScroll = false;
	CEntity._miniGameTriger = null;
	for (var i = 0; i < CGame.interfaceShowTime.length; i++) {
		CGame.interfaceShowTime[i] = 0;
	}
}
CGame.prototype.UnInit = function()
{
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//super.UnInit();
	// Dbg("Checking for IGP browser launching...");
	// if(Build.useIGP && GLLibConfig.platformRequestOnExit && IGP.URLPlatformRequest != null)
	// {
	// 	Dbg("Launching browser for IGP on Uninit...");
	// 	PlatformRequest(IGP.URLPlatformRequest);
	// 	IGP.URLPlatformRequest = null;
	// }
}

//-----------------------------------------------------------------------------------------------------------------------------------------
// cinematic

// cinematic data
CGame._cinematics = null;
CGame._cinematicsId = null;
CGame._cinematicsFrameTime = null;
CGame._cinematicsFrameTotal = null;
CGame._cinematicsStatus = null;
CGame._cinematicsSkipping = false;
CGame.DEFAULT_SPRITES_LOAD_MASK	= (1 << DSpriteID.HERO);

CGame._sprites_load_mask = CGame.DEFAULT_SPRITES_LOAD_MASK;

//-----------------------------------------------------------------------------------------------------------------------------------------


CGame.LoadCinematics = function( data) {
	var index = 0;
	var number_of_cinematics = data[index++];

	CGame._cinematics = LowAPI.Gen_Array([number_of_cinematics], null);//new byte[number_of_cinematics][][];
	CGame._cinematicsId = LowAPI.Gen_Array([number_of_cinematics], 0);//new short[number_of_cinematics];
	CGame._cinematicsFrameTotal = LowAPI.Gen_Array([number_of_cinematics], 0);//new short[number_of_cinematics];
	CGame._cinematicsFrameTime = LowAPI.Gen_Array([number_of_cinematics], 0);//new short[number_of_cinematics];
	CGame._cinematicsStatus = LowAPI.Gen_Array([number_of_cinematics], 0);//new byte[number_of_cinematics];

	var len = CGame._cinematicsFrameTime.length;
	for (var i = 0; i < len; ++i) {
		CGame._cinematicsFrameTime[i] = -1;
	}

	for (var i = 0; i < number_of_cinematics; ++i) {
		var frame_total = 0;
		var cinematic_id = Mem_GetShort(data, index);
		index += 2;
		CGame._cinematicsId[i] = cinematic_id;
		var number_of_tracks = data[index++];
		index += 2;
		CGame._cinematics[i] = LowAPI.Gen_Array([number_of_tracks], null);//new byte[number_of_tracks][];
		for (var j = 0; j < number_of_tracks; ++j) {
			var track_start = index;
			var track_type = data[index++];
			++index;
			switch (track_type) {
				case DCinematic.CTRACK_OBJ_LAYER: {
					var track_object_layer_id = Mem_GetShort(data, index);
					index += 2;
				}
				break;
				case DCinematic.CTRACK_SI: {
					var track_sprite_id = Mem_GetShort(data, index);
					index += 2;
					CGame._sprites_load_mask |= CEntity.GetSpriteLoadMask(track_sprite_id);
				}
				break;
			}
			var track_number_of_key_frames = Mem_GetShort(data, index);
			index += 2;
			for (var k = 0; k < track_number_of_key_frames; ++k) {
				var key_frame_time = Mem_GetShort(data, index);
				index += 2;
				if (key_frame_time > frame_total)
					frame_total = key_frame_time;
				var key_frame_number_of_commands = data[index++];
				for (var l = 0; l < key_frame_number_of_commands; ++l) {
					var key_frame_cmd_type = data[index++] & 0xff;
					switch (key_frame_cmd_type) {
						case DCinematic.CCMD_CAMERA_SET_POS:
						case DCinematic.CCMD_CAMERA_CENTER_TO:
						case DCinematic.CCMD_OBJ_LAYER_SET_POS:
						case DCinematic.CCMD_BASIC_SET_POS:
						case DCinematic.CCMD_SI_SET_POS:
							//short key_frame_cmd_x = ReadShort(data, index);
							index += 2;
							//short key_frame_cmd_y = ReadShort(data, index);
							index += 2;
							break;
						case DCinematic.CCMD_OBJ_LAYER_SET_ANIM:
						case DCinematic.CCMD_SI_SET_ANIM:
							//byte key_frame_cmd_anim = data[index];
							++index;
							break;
						case DCinematic.CCMD_BASIC_SET_ACTION:
							//short key_frame_cmd_acion = ReadShort(data, index);
							index += 2;
							break;
						case DCinematic.CCMD_OBJ_LAYER_ADD_FLAGS:
						case DCinematic.CCMD_OBJ_LAYER_REMOVE_FLAGS:
						case DCinematic.CCMD_SI_ADD_FLAGS:
						case DCinematic.CCMD_SI_REMOVE_FLAGS:
							//int key_frame_cmd_flags = ReadInt(data, index);
							index += 4;
							break;
						case DCinematic.CCMD_BASIC_SEND_EVENT_3:
							//int key_frame_cmd_param3 = ReadShort(data, index);
							index += 2;
						case DCinematic.CCMD_BASIC_SEND_EVENT_2:
						case DCinematic.CCMD_NEW_OBJECT_SETPOSREF:
							//int key_frame_cmd_param2 = ReadShort(data, index);
							index += 2;
							//int key_frame_cmd_param1 = ReadShort(data, index);
							index += 2;
							break;

						case DCinematic.CCMD_NEW_BASIC_ACTIVE_OBJECT:
						case DCinematic.CCMD_NEW_BASIC_INACTIVE_OBJECT:
						case DCinematic.CCMD_NEW_BASIC_PLAY_SOUND:
						case DCinematic.CCMD_NEW_BASIC_TEXT_BUBBLE:
						case DCinematic.CCMD_NEW_OBJECT_TEXT_BUBBLE:
						case DCinematic.CCMD_NEW_SI_SET_PALETTE:
						case DCinematic.CCMD_NEW_OBJECT_SET_PALETTE:
						case DCinematic.CCMD_NEW_BASIC_CAMERA_QUAKE:
						case DCinematic.CCMD_NEW_OBJECT_SET_ZORDER:
						case DCinematic.CCMD_NEW_OBJECT_DIE:
							index += 2;
							break;


						case DCinematic.CCMD_NEW_BASIC_STOP_SOUND:
						case DCinematic.CCMD_NEW_OBJECT_INACTIVE:
						case DCinematic.CCMD_NEW_OBJECT_ACTIVE:
						case DCinematic.CCMD_NEW_OBJECT_KEEP_CURRENT_POS:
						case DCinematic.CCMD_NEW_OBJECT_ESCAPE_FROM_CINEMATIC:
						case DCinematic.CCMD_NEW_BASIC_LEVEL_PASSED:
						case DCinematic.CCMD_NEW_BASIC_OPEN_BLACK_SCREEN:
						case DCinematic.CCMD_NEW_BASIC_BLACK_SCREEN:
							break;
						case DCinematic.CCMD_BASIC_SEND_OBJ_EVENT_3:
						case DCinematic.CCMD_BASIC_SEND_OBJ_EVENT_2:
						case DCinematic.CCMD_BASIC_SEND_OBJ_EVENT_1:
						case DCinematic.CCMD_BASIC_SEND_EVENT_1:
						default:
							if (DEF.dbgErr) {
								Dbg("not code this type in cenimatic now.");
							}
							break;
					}
				}
			}
			var track_length = index - track_start; // keep one short at the end to store the current played position
			CGame._cinematics[i][j] = LowAPI.Gen_Array([track_length + 2], 0);//new byte[track_length + 2];
			System.arraycopy(data, track_start, CGame._cinematics[i][j], 0, track_length);
		}
		CGame._cinematicsFrameTotal[i] = frame_total;
	}
}

CGame.GetCinematicIndex  = function( id) {
	var len = CGame._cinematicsId.length;
	for (var i = 0; i < len; ++i) {
		if (CGame._cinematicsId[i] == id) {
			return i;
		}
	}
	return -1;
}

CGame.InCinemitic = function() {
	var len = CGame._cinematicsId.length;
	for (var i = 0; i < len; ++i) {
		if ((CGame._cinematicsStatus[i] & DCinematic.STATUS_PLAYING) != 0 && (CGame._cinematicsStatus[i] & DCinematic.STATUS_CIRCLE) == 0) {
			return true;
		}
	}
	return false;
}
CGame.StartCinemitic  = function( index) {
	// Dbg("StartCinemitic -------------------------");
	if (CEntity._hero._hp < 0) {
		return;
	}
	var currentCinematic = CGame._cinematics[index];
	CGame._cinematicsFrameTime[index] = 0;
	CGame._cinematicsStatus[index] |= DCinematic.STATUS_PLAYING;
	var len = currentCinematic.length;
	for (var j = 0; j < len; ++j) {
		var data = currentCinematic[j];
		var track_type = data[0];
		var obj = null;
		var start_pos = 4;
		switch (track_type) {
			case DCinematic.CTRACK_BASIC:
//							if ((CGame._cinematicsStatus[index] & CINEMATIC_CIRCLE) == 0) {
//								WriteShort(data, 2,
//									 ACommonObject.AllocDynamicObject(DClassID.DIALOG,
//									-1).m_id);
//							}
				break;
			case DCinematic.CTRACK_CAMERA:
				CEntity._camera.SetFlag(DFlags.CENIMATIC);
				break;
			case DCinematic.CTRACK_OBJ_LAYER: {
				var track_object_layer_id = Mem_GetShort(data, 2);
				start_pos += 2;
				if (CEntity._hero != null && track_object_layer_id == CEntity._hero._id) {
					CEntity._hero.SetFlag(DFlags.CENIMATIC);
					CEntity._hero.StateMachineChangeState(DState.STATE_ONGROUND, DState.SS_IDLE, 0);
				}
//					obj = CEntity.GetEntityByID(track_object_layer_id, true);
//					if (obj != null) {
//						obj.SetFlag(DFlags.CENIMATIC);
//					}
			}
			break;
			case DCinematic.CTRACK_SI: {
				var track_sprite_id = Mem_GetShort(data, 2);
				if ((CGame._cinematicsStatus[index] & DCinematic.STATUS_CIRCLE) == 0) {
					var params = LowAPI.Gen_Array([DParamIndex.DECOR_PALETTE + 1], 0);//new short[DParamIndex.DECOR_PALETTE + 1];
					params[DParamIndex.DECOR_SPRITE] = Mem_GetShort(data, 2);
					params[DParamIndex.DECOR_Z_ORDER] = Z.DEFAULT;
					obj = CEntity.CreateDynamicEntity(params, DClassID.DECOR, 0, 0, 0, 0);
					Mem_SetShort(data, 2, obj._id);
					obj.SetFlag(DFlags.CENIMATIC);
				}
				start_pos += 2;
			}
			break;
		}
//					short track_number_of_key_frames = ReadShort(data, 4);
		Mem_SetShort(data, data.length - 2, start_pos);
	}
}

CGame.SkipCinemitic = function() {
	if (DEF.dbgEnable) Dbg("SkipCinemitic -------------------");
	CGame._cinematicsSkipping = true;
	CGame.CloseTextBubble();
	var len = CGame._cinematicsId.length;
	while (CGame.InCinemitic()) {
		CGame.UpdateCinematic();
	}
	CGame._cinematicsSkipping = false;
}
CGame.EndCinemitic  = function( index) {
	if (DEF.dbgEnable) Dbg("EndCinemitic -------------------");
	if (CGame._cinematicsFrameTime[index] < 0)
		return;
	if(playsoud_cutscene_story)
	{
		CGame.PlaySoundBGM();
	}
	var currentCinematic = CGame._cinematics[index];
	CGame._cinematicsFrameTime[index] = -2;
	CGame._cinematicsStatus[index] |= DCinematic.STATUS_PLAYED;
	CGame._cinematicsStatus[index] &= ~DCinematic.STATUS_PLAYING;
	var len = currentCinematic.length;
	for (var j = 0; j < len; ++j) {
		var data = currentCinematic[j];
		var track_type = data[0];
		var obj = null;
		switch (track_type) {
			case DCinematic.CTRACK_CAMERA:
				if (CEntity._camera != null) {
					CEntity._camera.ClearFlag(DFlags.CENIMATIC);
				}
				break;
			case DCinematic.CTRACK_OBJ_LAYER: {
				var track_object_layer_id = Mem_GetShort(data, 2);
				obj = CEntity.GetEntityByID(track_object_layer_id, false);
				if (obj != null) {
					obj.ClearFlag(DFlags.CENIMATIC);
				}
			}
			break;
			case DCinematic.CTRACK_SI: {
				var track_object_layer_id = Mem_GetShort(data, 2);
				if ((CGame._cinematicsStatus[index] & DCinematic.STATUS_CIRCLE) == 0) {
					obj = CEntity.GetEntityByID(track_object_layer_id, true);
					if (obj != null) {
						Mem_SetShort(data, 2, obj._params[DParamIndex.DECOR_SPRITE]);
						obj.SetInactived(true);
					}
				}
			}
			break;
		}
//					short track_number_of_key_frames = ReadShort(data, 4);
	}
}

CGame.UpdateCinematic = function() {
	var count = 0;
//		_cinematicCameraCount = 0;
	var len = CGame._cinematicsId.length;
	for (var i = 0; i < len; ++i) {
		if (CGame._cinematicsFrameTime[i] >= 0) {
			if ((CGame._cinematicsStatus[i] & DCinematic.STATUS_CIRCLE) == 0)
				++count;
			var cinematicEnd = true;
			var currentCinematic = CGame._cinematics[i];
			var current_frame_time = CGame._cinematicsFrameTime[i]++;
			var curLen = currentCinematic.length;
			
				if ((CGame._tempLevelId == CGame._finalLevelIndex) && (CGame._levelFinalInfo1 == 1)) {
					CGame._cinematicsFrameTime[i] = -2;
				CGame._cinematicsStatus[i] |= DCinematic.STATUS_PLAYED;
				CGame._cinematicsStatus[i] &= ~DCinematic.STATUS_PLAYING;
				if (CEntity._camera != null) {
					CEntity._camera.ClearFlag(DFlags.CENIMATIC);
				}
				if (CEntity._hero != null && CEntity._hero.CheckFlag(DFlags.CENIMATIC)) {
					CEntity._hero.ClearFlag(DFlags.CENIMATIC);
				}
				break;
			}
			
			for (var j = 0; j < curLen; ++j) {
				var data = currentCinematic[j];
				var off = 0;
				var track_type = data[off];
				++off;
				//byte track_flags = data[pos];
				++off;
				var obj = null;
				var track_object_layer_id = -1;
				switch (track_type) {
					case DCinematic.CTRACK_SI:
					case DCinematic.CTRACK_OBJ_LAYER: {
						track_object_layer_id = Mem_GetShort(data, off);
						off += 2;
						obj = CEntity.GetEntityByID(track_object_layer_id, true);
						obj.SetFlag(DFlags.CENIMATIC);
						if (obj == null) {
							continue;
						}
					}
					break;
				}
				//short track_number_of_key_frames = ReadShort(data, pos);
				off = Mem_GetShort(data, data.length - 2);
				var end = data.length - 2;
				var nextPosX = 0, nextPosY = 0, nextPosFrameTime = -1;
				var key_frame_cmd_flags;
				var key_frame_cmd_param;
				var lastRotate = 0;
				var lastAngle = 0;

				for (; off < end; ) {
					var key_frame_time = Mem_GetShort(data, off);
					if (current_frame_time < key_frame_time) {
						cinematicEnd = false;
						if (current_frame_time + 1 == key_frame_time) {
							Mem_SetShort(data, data.length - 2,  off);
						}
						if (obj != null) {
							obj.SetFlag(DFlags.CENIMATIC);
						}
					}
					off += 2;
					var key_frame_number_of_commands = data[off++];
					var needBreak = false;
					for (var l = 0; l < key_frame_number_of_commands; ++l) {
						var key_frame_cmd_type = data[off++] & 0xff;						
						var isKeyFrame = key_frame_time == current_frame_time;
						var isNextKeyFrame = key_frame_time >= current_frame_time;
						switch (key_frame_cmd_type) {

							case DCinematic.CCMD_CAMERA_SET_POS:
							case DCinematic.CCMD_CAMERA_CENTER_TO:
							case DCinematic.CCMD_OBJ_LAYER_SET_POS:
							case DCinematic.CCMD_BASIC_SET_POS:
							case DCinematic.CCMD_SI_SET_POS:
								var key_frame_cmd_x = Mem_GetShort(data, off);
								off += 2;
								var key_frame_cmd_y = Mem_GetShort(data, off);
								off += 2;
								if (isNextKeyFrame) {
									nextPosX = key_frame_cmd_x;
									nextPosY = key_frame_cmd_y;
									if (key_frame_cmd_type == DCinematic.CCMD_CAMERA_CENTER_TO) {
										nextPosX -= DEF.VIEW_W_D2;
										nextPosY -= DEF.VIEW_H_D2;
									}
									nextPosFrameTime = key_frame_time;
									needBreak = true;
								}
								break;
							case DCinematic.CCMD_NEW_OBJECT_ESCAPE_FROM_CINEMATIC:
								if (isNextKeyFrame) {
									obj.ClearFlag(DFlags.CENIMATIC);
									needBreak = true;
								}
								break;
							case DCinematic.CCMD_NEW_OBJECT_SETPOSREF:
								{
									var ref_x = Mem_GetShort(data, off);
									off += 2;
									var ref_y = Mem_GetShort(data, off);
									off += 2;
									if (isNextKeyFrame) {
										nextPosX = (obj._posX >> DEF.SHIFT) + ref_x;
										nextPosY = (obj._posY >> DEF.SHIFT) + ref_y;
										nextPosFrameTime = key_frame_time;
										needBreak = true;
									}
								}
								break;
							case DCinematic.CCMD_OBJ_LAYER_SET_ANIM:
							case DCinematic.CCMD_SI_SET_ANIM:
								var key_frame_cmd_anim = data[off++]&0xFF;
								if (isKeyFrame) {
									if (obj != null) {
										obj.SetAnim(key_frame_cmd_anim, CEntity.SETANIM_FORCE);
									}
								}
								break;
							case DCinematic.CCMD_BASIC_SET_ACTION:
								//short key_frame_cmd_action = ReadShort(data, pos);
								off += 2;
								break;
							case DCinematic.CCMD_BASIC_SEND_EVENT_2: {
								var key_frame_cmd_param1 = Mem_GetShort(data, off);
								off += 2;
								var key_frame_cmd_param2 = Mem_GetShort(data, off);
								off += 2;
							}
							break;
							case DCinematic.CCMD_BASIC_SEND_EVENT_3: {
								var key_frame_cmd_param1 = Mem_GetShort(data, off);
								off += 2;
								var key_frame_cmd_param2 = Mem_GetShort(data, off);
								off += 2;
								var key_frame_cmd_param3 = Mem_GetShort(data, off);
								off += 2;
							}
							break;
							case DCinematic.CCMD_OBJ_LAYER_ADD_FLAGS:
							case DCinematic.CCMD_SI_ADD_FLAGS:
								key_frame_cmd_flags = Mem_GetInt(data, off);
								off += 4;
								if (isKeyFrame) {
									if ((key_frame_cmd_flags & 0x800000) != 0) {
										key_frame_cmd_flags &= ~0x800000;
										key_frame_cmd_flags |= DFlags.INVISIBLE;
									}
									if (obj != null) {
										obj._flags |= key_frame_cmd_flags;
									}
								}
								break;
							case DCinematic.CCMD_OBJ_LAYER_REMOVE_FLAGS:
							case DCinematic.CCMD_SI_REMOVE_FLAGS:
								key_frame_cmd_flags = Mem_GetInt(data, off);
								off += 4;
								if (isKeyFrame) {
									if ((key_frame_cmd_flags & 0x800000) != 0) {
										key_frame_cmd_flags &= ~0x800000;
										key_frame_cmd_flags |= DFlags.INVISIBLE;
									}
									obj._flags &= ~key_frame_cmd_flags;
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_CAMERA_QUAKE:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									CEntity.AI_CameraQuake(Math_IntToFixedPoint(key_frame_cmd_param));
								}
								if (current_frame_time > key_frame_time) {
									CEntity.AI_CameraQuakeUpdate();
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_BLACK_SCREEN:
								if (isKeyFrame) {
									CGame._inCinematicBlackScreen = true;
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_OPEN_BLACK_SCREEN:
								if (isKeyFrame) {
									CGame._inCinematicBlackScreen = false;
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_INACTIVE_OBJECT:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									InactiveEntityOrCinematic(key_frame_cmd_param, true);
								}
								break;
							case DCinematic.CCMD_NEW_OBJECT_INACTIVE:
								if (isKeyFrame) {
									if (obj != null) {
										obj._params[DParamIndex.FLAGS] |= DFlags.CENIMATIC;
										obj.SetInactived(true);
									}
								}
								break;

							case DCinematic.CCMD_NEW_OBJECT_NOTIFY:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame)
									obj.NotifyEvent(null, DEvent.BE_TRIGGERED_BY_CINEMATIC, key_frame_cmd_param, 0, 0);
								break;
							case DCinematic.CCMD_NEW_OBJECT_KEEP_CURRENT_POS:
								if (isNextKeyFrame) {
									if (track_type == DCinematic.CTRACK_CAMERA) {
										nextPosX = Math_FixedPointToInt(CEntity._camX);
										nextPosY = Math_FixedPointToInt(CEntity._camY);
									}
									else {
										nextPosX = Math_FixedPointToInt(obj._posX);
										nextPosY = Math_FixedPointToInt(obj._posY);
									}
									nextPosFrameTime = key_frame_time;
									needBreak = true;
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_TEXT_BUBBLE:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame && !CGame._cinematicsSkipping) {
									CGame._textBubbleBigOne = true;
									CGame.StartTextBubble(i, -1, -1, key_frame_cmd_param);
									CGame._cinematicsFrameTime[i] = -CGame._cinematicsFrameTime[i];
								}
								break;
							case DCinematic.CCMD_NEW_OBJECT_TEXT_BUBBLE:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame && !CGame._cinematicsSkipping) { // keep waitting
									CGame.StartTextBubble(i, obj._posX, obj._posY, key_frame_cmd_param);
									CGame._cinematicsFrameTime[i] = -CGame._cinematicsFrameTime[i];
								}
								break;
							case DCinematic.CCMD_NEW_BASIC_PLAY_SOUND: {
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									CGame.PlaySound(DSound_Channel.SFX, key_frame_cmd_param);
								}
							}
							break;
							case DCinematic.CCMD_NEW_BASIC_STOP_SOUND: {
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									CGame.StopSound(key_frame_cmd_param);
								}
							}
							break;
							case DCinematic.CCMD_NEW_OBJECT_SET_PALETTE:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									obj._tempParams[DTempParamIndex.CINEMATIC_PALETTE] = key_frame_cmd_param;
								}
							break;
							case DCinematic.CCMD_NEW_OBJECT_SET_ZORDER:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									obj._zOrder = key_frame_cmd_param;
									CEntity.UpdateDrawList(obj);
								}
								break;
							case DCinematic.CCMD_NEW_SI_SET_PALETTE: {
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									if (obj != null && obj._classID == DClassID.DECOR) {
										obj._params[DParamIndex.DECOR_PALETTE] = key_frame_cmd_param;
									}
								}
							}
							break;
							case DCinematic.CCMD_NEW_OBJECT_DIE:
								key_frame_cmd_param = Mem_GetShort(data, off);
								off += 2;
								if (isKeyFrame) {
									if (obj != null) {
										obj._tempParams[DTempParamIndex.BOSS_DEAD_EFFECT_FADE_DIRECTION] = key_frame_cmd_param;
//@#if BOSS_SIMPLE_DIE
//@#if not RemoveIceLevel
//@											if (obj._classID == DClassID.BOSS_SNOWMAN) {
//@												if (key_frame_cmd_param == 0) {
//@													obj.StateMachineChangeState(DState.STATE_SIMPLE, DState.SS_DISAPPEAR, 0);
//@												} else {
//@													obj.StateMachineChangeState(DState.STATE_SIMPLE, DState.SS_DIE, 0);
//@												}
//@											} else
//@#endif
//@#endif
										{
											obj.StateMachineChangeState(DState.STATE_SIMPLE, DState.SS_DISAPPEAR, 0);
										}
									}
								}
							break;
							case DCinematic.CCMD_NEW_BASIC_LEVEL_PASSED:
								if (isKeyFrame) {
									CGame.GotoNextLevel(true);
								}
							break;
						}
					}
					if (needBreak) {
						if (current_frame_time == key_frame_time && off < end) {
							cinematicEnd = false;
							key_frame_time = Mem_GetShort(data, off);
							if (current_frame_time + 1 == key_frame_time) {
								Mem_SetShort(data, data.length - 2,  off);
							}
							off += 2;
						}
						break;
					}
				}
				var rowData = null;
				if (track_type != DCinematic.CTRACK_CAMERA && obj == null) {
					rowData = CEntity.GetRowDataByID(track_object_layer_id);
				}

				if (nextPosFrameTime < 0) {
					continue;
				}
				if (track_type != DCinematic.CTRACK_CAMERA && obj == null && rowData == null) {
					continue;
				}
				var posX = 0;
				var posY = 0;
				if (track_type == DCinematic.CTRACK_CAMERA) {
//						++_cinematicCameraCount;
					CEntity._camera.SetFlag(DFlags.CENIMATIC);
					posX = CEntity._camera._posX;
					posY = CEntity._camera._posY;
					//obj = _camera;
				} else if (obj != null) {
					posX = obj._posX;
					posY = obj._posY;
				} else {
					posX = Math_IntToFixedPoint(rowData[DParamIndex.POSX]);
					posY = Math_IntToFixedPoint(rowData[DParamIndex.POSY]);
				}
				if (nextPosFrameTime >= 0) {
					var vx;
					var vy;
					nextPosX <<= DEF.SHIFT;
					nextPosY <<= DEF.SHIFT;
					if (nextPosFrameTime == current_frame_time) {
						vx = nextPosX - posX;
						vy = nextPosY - posY;
						posX = nextPosX;
						posY = nextPosY;
					} else {
						var dt = nextPosFrameTime - current_frame_time + 1;
						dt *= DEF.ANIMATION_FRAME_TICK;
						vx = (nextPosX - posX) * 1000 / (dt);
						vy = (nextPosY - posY) * 1000 / (dt);
						vx = Math_FixedPoint_Multiply(vx, CGame._velocityRate);
						vy = Math_FixedPoint_Multiply(vy, CGame._velocityRate);
						posX += vx;
						posY += vy;
					}
					if (track_type == DCinematic.CTRACK_CAMERA) {
						CEntity._camera._posX = posX;
						CEntity._camera._posY = posY;
						CEntity.SetCameraPos(posX + CEntity._camOffsetX, posY + CEntity._camOffsetY);
					} else if (obj != null) {
						obj._posX = posX;
						obj._posY = posY;
					} else if (rowData != null) {
						rowData[DParamIndex.POSX] = Math_FixedPointToInt(posX);
						rowData[DParamIndex.POSY] = Math_FixedPointToInt(posY);
					}
				}
			}
			if (cinematicEnd) {
				CGame.EndCinemitic(i);
				if ((CGame._cinematicsStatus[i] & DCinematic.STATUS_CIRCLE) != 0) {
					CGame.StartCinemitic(i);
				}
					
					if ((CGame._tempLevelId == CGame._finalLevelIndex) && (CGame._levelFinalInfo1 != 1)) {
						CGame._levelFinalInfo1 = 1;
						CGame.RMS_Save();
				}
			}
		}
	}
	return count;
}

CGame.ActiveEntityOrCinematic  = function( id) {
	if (id > 0) {
		var data = CEntity.GetRowDataByID(id);
		if (data != null) {
			var ent = CEntity.GetEntityByID(id, true);
			if (ent != null && !ent.CheckFlag(DFlags.DYNAMIC_CREATE)) {
				return ent;
			}
		} else {
			var cinematic_index = CGame.GetCinematicIndex(id);
			if (cinematic_index >= 0) {
				if (CGame._cinematicsFrameTime[cinematic_index] < 0) {
					CGame.StartCinemitic(cinematic_index);
				}
				else {
					CGame._cinematicsStatus[cinematic_index] |= DCinematic.STATUS_CIRCLE;
				}
			} else {
				if (DEF.dbgErr) {
					Dbg("Could not find object: id = " + id);
				}
			}
		}		
	}
	return null;
}

CGame.InactiveEntityOrCinematic  = function (id, destory) {
	if (id > 0) {
		var data = CEntity.GetRowDataByID(id);
		if (data != null) {
			var ent = CEntity.GetEntityByID(id, false);
			if (ent != null && !ent.CheckFlag(DFlags.DYNAMIC_CREATE)) {
				ent.SetInactived(true);
				return ent;
			}
		} else {
			var cinematic_index = CGame.GetCinematicIndex(id);
			if (cinematic_index >= 0)
				CGame._cinematicsStatus[cinematic_index] &= ~DCinematic.STATUS_CIRCLE;
			else {
				if (DEF.dbgErr) {
					System.out.print("error id: " + id);
				}
			}
		}			
	}
	return null;
}

CGame._checkPointData = null;
CGame.CHECK_POINT_MAX_SIZE = 20;
CGame.SaveCheckPoint = function( checkPointId, saveEntityId, x, y) {
	if (CGame._checkPointData == null) {
		CGame._checkPointData = LowAPI.Gen_Array([CGame.CHECK_POINT_MAX_SIZE], 0);//new int[CGame.CHECK_POINT_MAX_SIZE];
	}
	var index = 0;
	if (checkPointId == CGame._checkPointData[0]) {
		return;
	}
	CGame._checkPointData[index++] = checkPointId;
	if (CEntity._hero == null) {
		CGame._checkPointData[index++] = -1;
	} else {
		CGame._checkPointData[index++] = CEntity._hero._id;
		if (CEntity._hero.CheckFlag(DFlags.FLIP_Y)) {
			CGame._checkPointData[index++] = Math_FixedPointToInt(CEntity._hero._posX);
			CGame._checkPointData[index++] = Math_FixedPointToInt(y + CEntity._hero._boundingBox[DEF.BOX_BOTTOM]);
		} else {
			CGame._checkPointData[index++] = Math_FixedPointToInt(CEntity._hero._posX);
			CGame._checkPointData[index++] = Math_FixedPointToInt(y);
		}
		CGame._checkPointData[index++] = CEntity._HeroInElectric;
	}
	if (CEntity._camera == null) {
		CGame._checkPointData[index++] = -1;
	} else {
		CGame._checkPointData[index++] = CEntity._camera._id;
		CGame._checkPointData[index++] = CEntity._camera._curTrace;
		if (CEntity._camera._curTrace > 0) {
			CGame._checkPointData[index++] = Math_FixedPointToInt(CEntity._hero._posX - DEF.VIEW_W_D2_FLOAT);
		} else {
			CGame._checkPointData[index++] = Math_FixedPointToInt(CEntity._camera._posX);
		}
		CGame._checkPointData[index++] = Math_FixedPointToInt(CEntity._camera._posY);
	}
	if (CEntity._boss == null) {
		CGame._checkPointData[index++] = -1;
	} else {
		CGame._checkPointData[index++] = CEntity._boss._id;
//@#if not RemoveIceLevel			
//@			if(CEntity._boss._classID == DClassID.BOSS_SNOWMAN) {
//@				CGame._checkPointData[index++] = DClassID.BOSS_SNOWMAN;
//@				CGame._checkPointData[index++] = CEntity._boss._tempParams[DTempParamIndex.BOSS_SNOWMAN_FIGHT_STEP];
//@			} else
//@#endif				
		{
			CGame._checkPointData[index++] = -1;
			CGame._checkPointData[index++] = 0;
		}
	}
	var ent = CEntity.GetEntityByID(saveEntityId, false);
	if (ent == null) {
		CGame._checkPointData[index++] = -1;
	} else {
		CGame._checkPointData[index++] = saveEntityId;
		CGame._checkPointData[index++] = ent._curTrace;
		CGame._checkPointData[index++] = Math_FixedPointToInt(ent._posX);
		CGame._checkPointData[index++] = Math_FixedPointToInt(ent._posY);			
	}
}

CGame.LoadCheckPoint = function() {
	if (CGame._checkPointData != null) {
		var index = 0;
		var checkPointId = CGame._checkPointData[index++];
		var heroParams = CEntity.GetRowDataByID(CGame._checkPointData[index++]);
		if (heroParams != null) {
			heroParams[DParamIndex.POSX] = CGame._checkPointData[index++];
			heroParams[DParamIndex.POSY] = CGame._checkPointData[index++];
			CEntity._HeroInElectric = CGame._checkPointData[index++];
			CEntity._hero = CEntity.GetEntityByID(heroParams[DParamIndex.ID], true);
			if (CEntity._hero != null) {
				CEntity._hero.SetPos(Math_IntToFixedPoint(heroParams[DParamIndex.POSX]), Math_IntToFixedPoint(heroParams[DParamIndex.POSY]));
				CEntity.SetCameraFocus(CEntity._hero, true);
			}
		}
		var camId = CGame._checkPointData[index++];
		var cameraParams = CEntity.GetRowDataByID(camId);
		if (camId != -1) {
			var curTrace = CGame._checkPointData[index++];
			var posX = Math_IntToFixedPoint(CGame._checkPointData[index++]);
			var posY = Math_IntToFixedPoint(CGame._checkPointData[index++]);
			if (CEntity._camera == null) {
				CEntity._camera = CEntity.GetDefaultCamera();
			}
			if (CEntity._camera != null) {
				if (curTrace != -1) {
					cameraParams[DParamIndex.CAMERA_TRACE] = curTrace;
					cameraParams[DParamIndex.POSX] = Math_FixedPointToInt(posX);
					cameraParams[DParamIndex.POSY] = Math_FixedPointToInt(posY);
					CEntity._camera = CEntity.GetEntityByID(cameraParams[DParamIndex.ID], true);
				}
				CEntity._camera._curTrace = curTrace;
				CEntity.SetCameraFocus(CEntity._hero, true);
				CEntity._camera.SetPos(posX, posY);
				CEntity._camera.AI_CameraDest();
			}
		}
		var bossId = CGame._checkPointData[index++];
		var bossParams = CEntity.GetRowDataByID(bossId);
		if (bossId != -1) {
			var bossClassID = CGame._checkPointData[index++];
//@#if not RemoveIceLevel
//@				if(bossClassID == DClassID.BOSS_SNOWMAN) {
//@					if(CEntity._boss == null) {
//@						CEntity._boss = CEntity.GetEntityByID(bossId, true);
//@					}
//@					int curStep = CGame._checkPointData[index++] - 1;
//@					if(CEntity._boss != null)
//@						CEntity._boss._tempParams[DTempParamIndex.BOSS_SNOWMAN_FIGHT_STEP] = curStep + 1;
//@				}
//@#endif				
		}
		var entId = CGame._checkPointData[index++];
		var entParams = CEntity.GetRowDataByID(entId);
		if (entId != -1) {
			var curTrace = CGame._checkPointData[index++];
			var posX = Math_IntToFixedPoint(CGame._checkPointData[index++]);
			var posY = Math_IntToFixedPoint(CGame._checkPointData[index++]);
			var ent = CEntity.GetEntityByID(entId, true);
			if (ent != null) {
				ent._curTrace = curTrace;
				ent.SetPos(posX, posY);
			}
		}
	}
}

CGame.DrawLine_FixedPoint = function( x1, y1, x2, y2) {
	/*GLLib.*/DrawLine(Math_FixedPointToInt(x1 - CEntity._camX), Math_FixedPointToInt(y1 - CEntity._camY), Math_FixedPointToInt(x2 - CEntity._camX), Math_FixedPointToInt(y2 - CEntity._camY));
}

CGame.DrawRect_FixedPoint = function( x,  y,  w, h) {
	/*GLLib.*/DrawRect(Math_FixedPointToInt(x - CEntity._camX), Math_FixedPointToInt(y - CEntity._camY), Math_FixedPointToInt(w), Math_FixedPointToInt(h));
}

CGame.DrawString_FixedPoint = function(str, x, y, anchor) {
	/*GLLib.*/DrawString(str, Math_FixedPointToInt(x - CEntity._camX), Math_FixedPointToInt(y - CEntity._camY), anchor);
}

CGame.DrawAFrame_FixedPoint = function(spriteId, anim, frame, posx, posy, flag) {
	CGame.spriteArray[spriteId].PaintAFrame(g, anim, frame, Math_FixedPointToInt(posx - CEntity._camX), Math_FixedPointToInt(posy - CEntity._camY), flag & DFlags.SPRITE_FLAG_MASK);
}
CGame.DrawAnimation = function(spriteId, anim, posx, posy, flag) {
	var time = CGame.spriteArray[spriteId].GetAFrameTime(anim, 0);
	var aframe = Math.floor(s_game_currentFrameNB / time) % CGame.spriteArray[spriteId].GetAFrames(anim);
	CGame.spriteArray[spriteId].PaintAFrame(g, anim, aframe, posx, posy, flag & DFlags.SPRITE_FLAG_MASK);
}
//--------------------------------------------------------------------------------------------------------------------
/// Tell if 2 segment intersect themselves.
/// @param (x1,y1)(x2,y2) Coordinate of first segment.
/// @param (x3,y3)(x4,y4) Coordinate of second segment.
/// @return \li MATH_SEGMENTINTERSECT_DO_INTERSECT if intersect.
/// 		\li MATH_SEGMENTINTERSECT_DONT_INTERSECT if no intersection.
/// 		\li MATH_SEGMENTINTERSECT_COLLINEAR if two segment are colinear (full or no intersection).
/// @note Coordinates of intersection point are saved in (s_Math_intersectX, s_Math_intersectY).
/// @warning	This function can generate some Overflows if large value are used. Be carefull when
/// 			using this code with FixedPoint values, the boundaries can change with the value of
///				GLLibConfig.math_fixedPointBase.
//--------------------------------------------------------------------------------------------------------------------
/* CGame.Math_FixedPoint_SegmentIntersect  = function( x1, y1, x2, y2, x3, y3, x4, y4)
{
  var Ax, Bx, Cx, Ay, By, Cy, d, e, f, num, offset;
  var x1lo, x1hi, y1lo, y1hi;

  Ax = x2 - x1;
  Bx = x3 - x4;

  // X bound box tes
  if (Ax < 0)
  {
		x1lo = x2; x1hi = x1;
	}
	else
	{
		x1hi = x2; x1lo = x1;
	}

  if (Bx > 0)
  {
		if ((x1hi < x4) || (x3 < x1lo))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}
	else
	{
		if ((x1hi < x3) || (x4 < x1lo))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}

  Ay = y2 - y1;
  By = y3 - y4;

  // Y bound box test
  if (Ay < 0)
  {
		y1lo = y2; y1hi = y1;
	}
	else
	{
		y1hi = y2; y1lo = y1;
	}

  if (By > 0)
  {
		if((y1hi < y4) || (y3 < y1lo))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}
	else
	{
		if ((y1hi < y3) || (y4 < y1lo))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}

  Cx = x1 - x3;
  Cy = y1 - y3;

  d = (By * Cx) - (Bx * Cy);	// alpha numerator
  f = (Ay * Bx) - (Ax * By);	// both denominator

  if (f > 0) 			// alpha tests
	{
		if ((d < 0) || (d > f))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}
	else
	{
		if ((d > 0) || (d < f))
		{
			return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
		}
	}

  e = (Ax * Cy) - (Ay * Cx);	// beta numerator

  if (f > 0) 			// beta tests
  {
	  if ((e < 0) || (e > f))
	  {
		  return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
	  }
  }
  else
  {
	  if ((e > 0) || (e < f))
	  {
		  return MATH_SEGMENTINTERSECT_DONT_INTERSECT;
	  }
  }

  //compute intersection coordinates
  if (f == 0)
  {
	  return MATH_SEGMENTINTERSECT_COLLINEAR;
  }

  num 	= d * Ax;									// numerator
  offset 	= Math_SameSign(num,f) ? (f>>1) : (-f>>1);	// round direction

  s_Math_intersectX = (x1 + (num+offset) / f);			// intersection x

  num 	= d * Ay;
  offset 	= Math_SameSign(num,f) ? (f>>1) : (-f>>1);

  s_Math_intersectY = (y1 + (num+offset) / f);			// intersection y

  return MATH_SEGMENTINTERSECT_DO_INTERSECT;
} */

//--------------------------------------------------------------------------------------------------------------------
/// Test 2 numbers to see if they are both of the same sign.
/// @param a,b Numbers to compare.
/// @return True if both numbers are positive.
/// @return True if both numbers are negative.
/// @return False Otherwise.
//--------------------------------------------------------------------------------------------------------------------
/* CGame.prototype.Math_SameSign  = function(a, b)
{
//return ((a * b) > 0);
return ((a ^ b) >= 0);
} */

CGame.prototype.BuildCacheImages = function( spr, pal) {
	if (spr._module_image_imageAA == null) {
		spr._module_image_imageAA = LowAPI.Gen_Array([spr._palettes], null);//new Image[spr._palettes][];
	}
	if (spr._module_image_imageAA[pal] == null)
	{
		spr._module_image_imageAA[pal] = LowAPI.Gen_Array([spr._nModules], null);//new Image[spr._nModules];
	}
	for (var i = 0; i < spr._nModules; i++) {
		if (spr._module_types[ i ] == ASprite.MD_IMAGE) {
			var startIndex = 0;
			if( GLLibConfig.sprite_useModuleDataOffAsShort )
				startIndex = spr._modules_data_off_short[ i ] & 0xFFFF;
			else
				startIndex = spr._modules_data_off_int  [ i ];

			spr._module_image_imageAA[pal][i] = createRGBImageCache(spr, spr._modules_data, pal, startIndex,
							   spr.GetModuleWidth( i ), spr.GetModuleHeight( i ));
		}
	}

}
// only support ENCODE_FORMAT_I256 and ENCODE_FORMAT_I127RLE
CGame.prototype.createRGBImageCache = function( spr, image, pal, si, sizeX, sizeY) {
	var di = 0;
	var ds = sizeX * sizeY;
	var 	_4444 	= 0;// dummy init
	var _alpha = false;
	var pal_short = spr._pal_short[0][pal];
	var temp_int = LowAPI.Gen_Array([sizeX * sizeY], 0);//new int[sizeX * sizeY];
	if (spr._data_format == ASprite.ENCODE_FORMAT_I256) {
		while (di < ds)
		{
			_4444 = pal_short[image[si++]&0xFF];

			if ((_4444 & 0xF000) != 0xF000) {
				_alpha = true;
			}
			temp_int[di++] = converColorShortToInt(_4444);
		}
	} else if (spr._data_format == ASprite.ENCODE_FORMAT_I127RLE) {
		// RLE compression, max 127 colors...
		while (di < ds)
		{
			var c = image[si++]&0xFF;

			if (c > 127)
			{
				var c2 = image[si++]&0xFF;
				//T_TMP clr = MAP_COLOR(c2);
				_4444 = pal_short[c2];
				c -= 128;
				while (c-- > 0)
				{
					temp_int[di++] = converColorShortToInt(_4444);
				}
			}
			else
			{
				temp_int[di++] = converColorShortToInt(pal_short[c]);
			}
		}
	}
	return Image.createRGBImage(temp_int, sizeX, sizeY, true);
}

CGame.prototype.converColorShortToInt = function(_4444) {
	return  (
			((_4444 & 0xF000) << 16) | ((_4444 & 0xF000) << 12) |	// A
			((_4444 & 0x0F00) << 12) | ((_4444 & 0x0F00) << 8) |	// R
			((_4444 & 0x00F0) << 8) | ((_4444 & 0x00F0) << 4) |	// G
			((_4444 & 0x000F) << 4) | ((_4444 & 0x000F)));	// B
}

//@#if not RemoveBlendEffect
////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.s_rewindEffectFrame = 0;

CGame.k_gradientYellow		= 0;
CGame.k_gradientRed			= 1;
CGame.k_gradientWhite			= 2;
CGame.k_gradientLBlur			= 3;
CGame.k_gradientRBlur			= 4;
CGame.k_gradientLRewind		= 5;
CGame.k_gradientRRewind		= 6;

CGame.paintVideoRewindEffect = function( g)
{
	CGame.s_rewindEffectFrame++;

	var even = (CGame.s_rewindEffectFrame & 1) == 0;

	paintVerticalGradientEffect(g, 0, 60,  DEF.VIEW_W, 24, even ? 60 : 110, CGame.k_gradientLRewind);
	paintVerticalGradientEffect(g, 0, 80,  DEF.VIEW_W, 15, even ? 110 : 80, CGame.k_gradientLRewind);
	paintVerticalGradientEffect(g, 0, 120, DEF.VIEW_W, 20, even ? 60 : 110, CGame.k_gradientRRewind);
	paintVerticalGradientEffect(g, 0, 125, DEF.VIEW_W, 27, even ? 110 : 80, CGame.k_gradientLRewind);
	paintVerticalGradientEffect(g, 0, 210, DEF.VIEW_W, 15, even ? 60 : 110, CGame.k_gradientRRewind);
	paintVerticalGradientEffect(g, 0, 245, DEF.VIEW_W, 18,  even ? 80 : 120, CGame.k_gradientLRewind);
	paintVerticalGradientEffect(g, 0, 260, DEF.VIEW_W, 10, even ? 60 : 90,  CGame.k_gradientRRewind);
	paintVerticalGradientEffect(g, 0, 263, DEF.VIEW_W, 15, even ? 110 : 80, CGame.k_gradientLRewind);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.desaturateBlock = function( size, buf, desAmount)
{
	for (var k = 0; k < size; k++)
	{
		var c = buf[k];

		var rr = (c) & 0xFF0000;
		var gg = (c) & 0xFF00;
		var bb = (c) & 0xFF;

		//the desaturated components
		var lum = ((rr >> 16) + (gg >> 8) + bb + 16) >> 2; //the desaturated col (luminosity)
		var desR = (lum << 16);
		var desG = (lum << 8);
		var desB = (lum);

		desR = rr + ((desR - rr) * desAmount >> 7);
		desG = gg + ((desG - gg) * desAmount >> 7);
		desB = bb + ((desB - bb) * desAmount >> 7);

		var color = (desR & 0xFF0000) | (desG & 0xFF00) | desB;
		buf[k] = color;
	}
}

CGame.paintDesaturatedEffect = function( g, x, y, width, height, desAmount)
{
	try
	{
		var buf = ASprite.transform_int;

		//dg.getPixels(tempShort, 0, width, 0, 0, width, height, format);

		var maxBlock = GLLibConfig.TMP_BUFFER_SIZE / width;
		var block = 80;

		var yy = 0;
		var done = false;

		while (!done)
		{
			block = height - yy;
			if (block > maxBlock)
				block = maxBlock - 1;
			else
				done = true;

			var size = width * block;

//@#if SupportNokiaAPI
//@                dg.getPixels(buf, 0, width, x, y + yy, width, block, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//@#endif

			//desaturate
			desaturateBlock(size, buf, desAmount);

//	                com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics( g );
//	                dg.drawPixels(buf, false, 0, width, x, y + yy, width, block, 0, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
			g.drawRGB(buf, 0, width, x, y + yy, width, block, false);

			yy += block;
		}
	}
	catch ( e)
	{
		if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.blurDesaturateBlock = function( size, buf, blurAmount, desAmount)
{
	var r1 = 0;
	var b1 = 0;
	var r1b1 = 0;
	var g1 = 0;

	//blur in both sides
	//right to left
	for (var k = size - 1; k >= 0; k--)
	{
		var c2 = buf[k];

		var r2b2 = (c2) & 0xFF00FF;
		var g2 = (c2) & 0xFF00;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * blurAmount >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * blurAmount >> 7)) & 0x00FF00;

		var color = r1b1 | g1;
		buf[k] = color;
	}

	//left to right, AND desaturate
	for (var k = 0; k < size; k++)
	{
		var c2 = buf[k];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		r1 = r2 + ((r1 - r2) * blurAmount >> 7);
		g1 = g2 + ((g1 - g2) * blurAmount >> 7);
		b1 = b2 + ((b1 - b2) * blurAmount >> 7);

		//the desaturated components
		var lum = ((r1 >> 16) + (g1 >> 8) + b1 + 16) >> 2; //the desaturated col (luminosity)
		var desR = (lum << 16);
		var desG = (lum << 8);
		var desB = (lum);

		desR = r1 + ((desR - r1) * desAmount >> 7);
		desG = g1 + ((desG - g1) * desAmount >> 7);
		desB = b1 + ((desB - b1) * desAmount >> 7);

		var color = (desR & 0xFF0000) | (desG & 0xFF00) | desB;
		buf[k] = color;
	}
}

CGame.paintIGMBlurEffect = function(g, x, y, width, height, blurAmount, desAmount)
{
	try
	{
		var buf = ASprite.transform_int;

		//dg.getPixels(tempShort, 0, width, 0, 0, width, height, format);

		var d = blurAmount % 128;

		var maxBlock = GLLibConfig.TMP_BUFFER_SIZE / width;
		var block = 80;

		var yy = 0;
		var done = false;

		while (!done)
		{
			block = height - yy;
			if (block > maxBlock)
				block = maxBlock - 1;
			else
				done = true;

			var size = width * block;

//@#if SupportNokiaAPI
//@                dg.getPixels(buf, 0, width, x, y + yy, width, block, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//@#endif

			blurDesaturateBlock(size, buf, d, desAmount);

//	            if (PLATFORM.m_useDrawPixelsInsteadOfDrawRGB)
//	            {
//	                com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics( g );
//	                dg.drawPixels(buf, false, 0, width, x, y + yy, width, block, 0, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//	            }
//	            else
				g.drawRGB(buf, 0, width, x, y + yy, width, block, false);

			yy += block;
		}
	}
	catch ( e) {if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.blurRBlock = function( size, buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	for (var k = size - 1; k >= 0; k--)
	{
		var c2 = buf[k];

		var r2b2 = (c2) & 0xFF00FF;
		var g2 = (c2) & 0x00FF00;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[k] = color;
	}
}

CGame.blurLBlock = function( size, buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	for (var k = 0; k < size; k++)
	{
		var c2 = buf[k];

		var r2b2 = (c2) & 0xFF00FF;
		var g2 = (c2) & 0x00FF00;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[k] = color;
	}
}

CGame.paintBlurEffect = function( g, x, y, width, height, type, amount)
{
	try
	{
		var buf = ASprite.transform_int;

		//dg.getPixels(tempShort, 0, width, 0, 0, width, height, format);

		var d = amount % 128;

		var maxBlock = GLLibConfig.TMP_BUFFER_SIZE / width;
		var block = 80;

		var yy = 0;
		var done = false;

		while (!done)
		{
			block = height - yy;
			if (block > maxBlock)
				block = maxBlock - 1;
			else
				done = true;

			var size = width * block;

//@#if SupportNokiaAPI
//@                dg.getPixels(buf, 0, width, x, y + yy, width, block, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//@#endif

			if (type == 0)
				blurRBlock(size, buf, d);
			else
				blurLBlock(size, buf, d);

//	            if (PLATFORM.m_useDrawPixelsInsteadOfDrawRGB)
//	            {
//	                com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics( g );
//	                dg.drawPixels(buf, false, 0, width, x, y + yy, width, block, 0, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//	            }
//	            else
				g.drawRGB(buf, 0, width, x, y + yy, width, block, false);

			yy += block;
		}
	}
	catch ( e) {if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);}
}

// Blur effect used in Boxing 2d.
// It is cuverd to the right or to the left (depending on the type: 0, 1)
// Amount could take values from 0 to 127 (0:no distorsion to 127:maximun distorsion)
CGame.paintBlurEffectCurved = function( g, x, y, width, height, type, amount)
{
	try
	{

		if(x + width > DEF.SCR_W)
		{
			width = DEF.SCR_W - x;
		}

		if(y + height > DEF.SCR_H)
		{
			height = DEF.SCR_H - y;
		}

		if(x < 0)
		{
			width += x;
			x = 0;
		}

		if(y < 0)
		{
			height += y;
			y = 0;
		}

		if (width <= 0 || height <= 0) return;

		var buf = ASprite.transform_int;

		//dg.getPixels(tempShort, 0, width, 0, 0, width, height, format);

		var d = amount;
		if (d > 127)
		{
			d = 127;
		}
		if (d < 0)
		{
			d = 0;
		}

		var maxBlock = GLLibConfig.TMP_BUFFER_SIZE / width;
		var block = 80;

		var r1b1 = 0;
		var g1 = 0;

		var dRow = 0;
		var dColumn = 0;

		var yy = 0;
		var done = false;

		var row = 0;
		var column = 0;

		var gradient = 0;

		while (!done)
		{
			block = height - yy;
			if (block > maxBlock)
				block = maxBlock - 1;
			else
				done = true;

			var size = width * block;

//@#if SupportNokiaAPI
//@                dg.getPixels(buf, 0, width, x, y + yy, width, block, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//@#endif

			if (type == 0)
			{
				for (var k = size - 1; k >= 0; k--)
				{
					var c2 = buf[k];

					var r2b2 = (c2) & 0xFF00FF;
					var g2 = (c2) & 0x00FF00;

					r1b1 = (r2b2 + ((r1b1 - r2b2) * (d) >> 7)) & 0xFF00FF;
					g1 = (g2 + ((g1 - g2) * (d) >> 7)) & 0x00FF00;
					var color = r1b1 | g1;

					buf[k] = color;
				}
			}
			else if(type == 1)
			{
				for (var k = 0; k < size; k++)
				{
					var c2 = buf[k];

					var r2b2 = (c2) & 0xFF00FF;
					var g2 = (c2) & 0x00FF00;

					column++;
					if(column > width)
					{
						column = 1;
						if(gradient == 0)
						{
							row ++;
							if(row > height >> 1)
							{
								gradient = 1;
							}
						}
						else
						{
							row --;
						}

						r1b1 = r2b2;
						g1 = g2;

						dRow =  (d * row) / (height >> 1);
						if(dRow > 100)
						{
							dRow = 100;
						}
					}

					r1b1 = (r2b2 + ((r1b1 - r2b2) * (dRow) >> 7)) & 0xFF00FF;
					g1 = (g2 + ((g1 - g2) * (dRow) >> 7)) & 0x00FF00;
					var color = r1b1 | g1;
					buf[k] = color;
				}
			}
			else if(type == 2)
			{
				for (var k = size - 1; k >= 0; k--)
				{
					var c2 = buf[k];

					var r2b2 = (c2) & 0xFF00FF;
					var g2 = (c2) & 0x00FF00;

					column++;
					if(column > width)
					{
						column = 1;
						if(gradient == 0)
						{
							row ++;
							if(row > height >> 1)
							{
								gradient = 1;
							}
						}
						else
						{
							row --;
						}

						r1b1 = r2b2;
						g1 = g2;
						dRow =  (d * row) / (height >> 1);
						if(dRow > 100)
						{
							dRow = 100;
						}
					}


					r1b1 = (r2b2 + ((r1b1 - r2b2) * (dRow) >> 7)) & 0xFF00FF;
					g1 = (g2 + ((g1 - g2) * (dRow) >> 7)) & 0x00FF00;
					var color = r1b1 | g1;
					buf[k] = color;
				}
			}

//	            if (PLATFORM.m_useDrawPixelsInsteadOfDrawRGB)
//	            {
//	                com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics( g );
//	                dg.drawPixels(buf, false, 0, width, x, y + yy, width, block, 0, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//	            }
//	            else
				g.drawRGB(buf, 0, width, x, y + yy, width, block, false);

			yy += block;
		}
	}
	catch( e)
	{
		Dbg("ERROR: ----------------- "+e.message);
	}
}

CGame.CLAMP_R = function( rr) {
	return (((rr << 7) >> 31) | rr) & 0xFF0000;
}

CGame.CLAMP_G = function( gg) {
	return (((gg << 15) >> 31) | gg) & 0xFF00;
}

CGame.CLAMP_B = function( bb) {
	return (((bb << 23) >> 31) | bb) & 0xFF;
}
////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.gradientRedLine = function( width, pos,  buf, amount)
{
	var amount16 = amount << 16;
	amount += 128;

	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		var rr = r2 + amount16;
		rr = CLAMP_R(rr);

		var gg = g2 * amount >> 7;
		gg = CLAMP_G(gg);

		var bb = b2 * amount >> 7;
		bb = CLAMP_B(bb);

		var color = rr | gg | bb;
		buf[pos] = color;
		pos++;
	}

	return pos;
}

CGame.gradientYellowLine = function( width, pos, buf, amount)
{
	var amount16 = amount << 16;
	var amount8 = amount << 8;
	amount += 128;

	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		var rr = r2 + amount16;
		//rr = (((rr << 7) >> 31) | rr) & 0xFF0000;
		rr = CLAMP_R(rr);

		var gg = g2 + amount8;
		//gg = (((gg << 15) >> 31) | gg) & 0xFF00;
		gg = CLAMP_G(gg);

		var bb = (b2 * amount) >> 7;
		//bb = (((bb << 23) >> 31) | bb) & 0xFF;
		bb = CLAMP_B(bb);

		var color = rr | gg | bb;
		buf[pos] = color;
		pos++;
	}

	return pos;
}

CGame.gradientWhiteLine = function( width, pos, buf, amount)
{
	amount += 128;

	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		//int rr = r2 + (r2 * amount >> 7);
		var rr = r2 * amount >> 7;
		//rr = (((rr << 7) >> 31) | rr) & 0xFF0000;
		rr = CLAMP_R(rr);

		var gg = g2 * amount >> 7;
		//gg = (((gg << 15) >> 31) | gg) & 0xFF00;
		gg = CLAMP_G(gg);

		var bb = b2 * amount >> 7;
		//bb = (((bb << 23) >> 31) | bb) & 0xFF;
		bb = CLAMP_B(bb);

		var color = rr | gg | bb;
		buf[pos] = color;
		pos++;
	}

	return pos;
}

CGame.gradientRBlurLine = function( width,  pos,  buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2b2 = (c2) & 0xFF00FF;
		var g2 = (c2) & 0x00FF00;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[pos] = color;
		pos++;
	}

	return pos;
}

CGame.gradientLBlurLine = function( width, pos, buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	pos += width - 1;
	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2b2 = (c2) & 0xFF00FF;
		var g2 = (c2) & 0x00FF00;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[pos] = color;
		pos--;
	}
	pos += width;

	return pos;
}

//(color) = (((m_fogCurrentColor - (color)) * ((fog) >> 16) >> 5) + (color)) & a; \

CGame.gradientRRewindLine = function(width, pos, buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	var amount128 = amount + 128;

	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		r2 = r2 * amount128 >> 7;
		r2 = CLAMP_R(r2);

		g2 = g2 * amount128 >> 7;
		g2 = CLAMP_G(g2);

		b2 = b2 * amount128 >> 7;
		b2 = CLAMP_B(b2);

		var r2b2 = r2 | b2;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[pos] = color;
		pos++;
	}

	return pos;
}

CGame.gradientLRewindLine = function( width, pos, buf, amount)
{
	var r1b1 = 0;
	var g1 = 0;

	var amount128 = amount + 128;

	pos += width - 1;
	for (var i = width - 1; i >= 0; i--)
	{
		var c2 = buf[pos];

		var r2 = (c2) & 0xFF0000;
		var g2 = (c2) & 0xFF00;
		var b2 = (c2) & 0xFF;

		r2 = r2 * amount128 >> 7;
		r2 = CLAMP_R(r2);

		g2 = g2 * amount128 >> 7;
		g2 = CLAMP_G(g2);

		b2 = b2 * amount128 >> 7;
		b2 = CLAMP_B(b2);

		var r2b2 = r2 | b2;

		r1b1 = (r2b2 + ((r1b1 - r2b2) * (amount) >> 7)) & 0xFF00FF;
		g1 = (g2 + ((g1 - g2) * (amount) >> 7)) & 0x00FF00;
		var color = r1b1 | g1;

		buf[pos] = color;
		pos--;
	}
	pos += width;

	return pos;
}



CGame.paintVerticalGradientEffect = function( g, x, y, width, height, amount, type)
{
	this.paintVerticalGradientEffect(g, x, y, width, height, amount, type, 0, height);
}

CGame.paintVerticalGradientEffect = function( g, x, y, width, height, amount, type, gradientOffset, gradientMax)
{
	try
	{
		var buf = ASprite.transform_int;

		//dg.getPixels(tempShort, 0, width, 0, 0, width, height, format);

		var maxBlock = ((GLLibConfig.TMP_BUFFER_SIZE / width) & (~0x1)); //make it even
		var block = 80;

		var r1 = 0;
		var g1 = 0;
		var b1 = 0;

		var yStep = 2;
		if (type == CGame.k_gradientLBlur || type == CGame.k_gradientRBlur)
			yStep = 1;

		var yy = 0;
		var done = false;
		while (!done)
		{
			block = height - yy;
			if (block > maxBlock)
				block = maxBlock;
			else
				done = true;

			//_DBG(" " + width + " " + x + " " + (y + yy) + " " + block);

			var pos = 0;
			var yStart = -1;
			var yStop = 0;
			for (var j = 0; j < block; j+=yStep)
			{
				var d = /*GLLib.*/Math_FixedPoint_Multiply(amount, /*GLLib.*/Math_Sin((yy + j + gradientOffset) * /*GLLib.*/Math_Angle180 / gradientMax));
				d = Math.abs(d);
				d = d & (~7);	//reduce precision a bit

				if ((d >> 4) == 0)
				{
					pos += width*yStep; //skip zero values
					continue;
				}
				else
				{
					if (yStart < 0)
					{
						yStart = j;
//@#if SupportNokiaAPI
//@                            dg.getPixels(buf, yStart * width, width, x, y + yy + yStart, width, block - yStart, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//@#endif
					}

					yStop = j;
				}

				if (type == CGame.k_gradientRed)
				{
					pos = gradientRedLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientYellow)
				{
					pos = gradientYellowLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientWhite)
				{
					pos = gradientWhiteLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientRBlur)
				{
					pos = gradientRBlurLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientLBlur)
				{
					pos = gradientLBlurLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientRRewind)
				{
					pos = gradientRRewindLine(width, pos, buf, d);
				}
				else if (type == CGame.k_gradientLRewind)
				{
					pos = gradientLRewindLine(width, pos, buf, d);
				}

				if (yStep > 1)
					pos += width;
			}

			//dg.drawPixels(buffer, false, 0, width, x, y + yy, width, block, 0, format);
			if (yStart >= 0)
			{
//	                if (PLATFORM.m_useDrawPixelsInsteadOfDrawRGB)
//	                {
//	                    com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics( g );
//	                    dg.drawPixels(buf, false, yStart * width, width, x, y + yy + yStart, width, yStop - yStart + 1, 0, com.nokia.mid.ui.DirectGraphics.TYPE_INT_888_RGB);
//	                }
//	                else
					g.drawRGB(buf, yStart * width, width, x, y + yy + yStart, width, yStop - yStart + 1, false);
			}

			yy += block;

			//if (yStep > 1)
			//	yy++;
		}

		//go back to the default
	}
	catch ( e) {if(DEF.dbgEnable) Dbg("-------------------- error : "+  e.message);}
}

CGame.s_swarmSprite = null;
CGame.s_splashSprite = null;
CGame.s_bloodSprite = null;
CGame.s_rainSprite = null;

CGame.s_swarmFrame = 0;
CGame.s_swarmDir = 0;
CGame.s_swarmStrength = 0;
CGame.s_swarmBoxer = 0;

CGame.s_useBlood = false;
CGame.s_bloodAnim = 0;
CGame.s_bloodScreenX = 0;
CGame.s_bloodScreenY = 0;

CGame.s_dustFrame = 0;
CGame.s_dustDummyId = 0;
CGame.s_dustSprite = null;
CGame.s_dustBoxer = 0;

CGame.k_dust1					= 0;

CGame.s_flashType = 0;
CGame.s_flashFrame = 0;
CGame.s_flashDummyId = 0;
CGame.s_flashBoxer = 0;
CGame.s_flashInForeground = false;



CGame.k_effectShockwave		= 0;
CGame.k_effectColorShockwave	= 1;

CGame.s_effectSprite = null;
CGame.s_effectAnim = 0;
CGame.s_effectType = 0;
CGame.s_effectFrame = 0;
CGame.s_effectDummyId = 0;
CGame.s_effectBoxer = 0;
CGame.s_effectInForeground = false;


CGame.s_hitMarks = null;
CGame.s_hitMarkPalette = 0;
CGame.s_hitMarkX = 0;
CGame.s_hitMarkY = 0;
CGame.s_hitMarkZ = 0;
CGame.s_hitMarkAnim = 0;
CGame.s_hitMarkFrame = 0;


CGame.k_fadeIn    = 0;
CGame.k_fadeOut   = 1;

CGame.s_fadeType = 0;
CGame.s_fadeDuration = 0;
CGame.s_fadeTime = 0;

CGame.k_cinematicBarsHeight = 45;

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.initDustEffect = function( boxer, dummyId)
{
	s_dustFrame		= 0;
	s_dustDummyId	= dummyId;
	s_dustBoxer		= boxer;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.initSwarmEffect = function( dir, strength, swarmboxer)
{
	s_swarmFrame = 0;

	s_swarmDir = dir;
	s_swarmStrength = strength;
	s_swarmBoxer = swarmboxer;

	CGame.s_useBlood = false;
	if (false)
	{
		s_swarmSprite.SetCurrentPalette(1);//blood
		CGame.s_useBlood = true;
	}
	else
		s_swarmSprite.SetCurrentPalette(0);//sweat

	s_bloodAnim = /*GLLib.*/Math_Rand(0, s_bloodSprite._anims_naf.length);
	s_bloodScreenX = /*GLLib.*/Math_Rand(0, 0 + DEF.VIEW_W);
	s_bloodScreenY = /*GLLib.*/Math_Rand(0, DEF.VIEW_H);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.initFlashEffect = function( type, foreground, boxer, dummyId)
{
	s_flashFrame = 0;
	s_flashType = type;
	s_flashBoxer = boxer;
	s_flashDummyId = dummyId;
	CGame.s_flashInForeground = foreground;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.initEffect = function(type, anim, foreground, boxer, dummyId)
{
	s_effectFrame = 0;
	s_effectAnim = anim;
	s_effectType = type;
	s_effectBoxer = boxer;
	s_effectDummyId = dummyId;
	CGame.s_effectInForeground = foreground;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.updateEffects = function()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.s_cinematicFrame = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.k_directionLeft = 0;
CGame.k_directionRight = 1;
CGame.k_directionFwd = 2;
CGame.k_strengthStrong = 3;

//
//paint the swarm effect
//
CGame.paintSwarmEffect = function( g, foreground, x, y)
{
	//
	//the sweat
	//

	var anim = 0;
	var effect = 0;

	if (s_swarmFrame >= 0 && s_swarmFrame < 100 && foreground == true)
	{
		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);

		if (s_swarmDir == CGame.k_directionLeft)
			anim = 0;
		else if (s_swarmDir == CGame.k_directionRight)
			anim = 1;
		else if (s_swarmDir == CGame.k_directionFwd)
			anim = 2;

		if (s_swarmStrength == CGame.k_strengthStrong)
			anim += 3;

		var frameCount = s_swarmSprite.GetAFrames(anim);
		if (s_swarmFrame < frameCount)
		{
			s_swarmSprite.PaintAFrame(g, anim, s_swarmFrame, x, y, 0);
		}
		else if (true)
		{
			if (CGame.s_useBlood)
			{
				var frame = s_swarmFrame - frameCount;
				if (frame >= 0 && frame < s_bloodSprite.GetAFrames(s_bloodAnim))
					s_bloodSprite.PaintAFrame(g, s_bloodAnim, frame, s_bloodScreenX, s_bloodScreenY, 0);
				else
					s_swarmFrame = 100;
			}
			else
			{
				var frame = s_swarmFrame - frameCount;
				if (frame >= 0 && frame < s_splashSprite.GetAFrames(0))
					s_splashSprite.PaintAFrame(g, 0, frame, 0, 0, 0);
				else
					s_swarmFrame = 100;
			}
		}
		else
			s_swarmFrame = 100;

		s_swarmFrame++;

		resetClip(g);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

//
//paint the dust effect
//
CGame.paintDustEffect = function( g, foreground, x, y)
{
	//
	//the sweat
	//

	if (s_dustFrame >= 0 && s_dustFrame < 100 && foreground == true)
	{
		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);

		var frameCount = s_dustSprite.GetAFrames(CGame.k_dust1);

		if (s_dustFrame < frameCount)
		{
			s_dustSprite.PaintAFrame(g, CGame.k_dust1, s_dustFrame, x, y, 0);
		}
		else
		{
			s_dustFrame = 100;
		}

		resetClip(g);
		s_dustFrame++;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

//
//paint the flash effect
//
CGame.paintFlashEffect = function(g, foreground, x, y)
{
	//
	//the sweat
	//

	if (false)
	{
		s_flashFrame = 100;
		return;
	}

	if (CGame.s_flashInForeground == foreground)
	{
		if (s_flashFrame >= 0 && s_flashFrame < 7)
		{
			g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);

			var height = DEF.SCR_H / 3;
			var yy = y - height / 2;

			paintVerticalGradientEffect(g, 0, yy, DEF.VIEW_W, height, (15 - s_flashFrame*2) << 3, s_flashType);

			s_flashFrame++;

			resetClip(g);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

//
//the effects - SHOCKWAVE and COLOR SHOCKWAVE
//
//
CGame.paintShockwaveEffect = function( g, foreground, x, y)
{
	//
	//the sweat
	//
	var effect = 0;

	if (CGame.s_effectInForeground == foreground)
	{
		if (s_effectType == CGame.k_effectShockwave)
		{
			effect = CBlendSprite.BLEND_DISPLACEMENT;
		}
		else if (s_effectType == CGame.k_effectColorShockwave)
		{
			effect = CBlendSprite.BLEND_COLOR_DISPLACEMENT;
		}

		var frameCount = s_effectSprite.GetAFrames(s_effectAnim);
		if (s_effectFrame >= 0 && s_effectFrame < frameCount)
		{
			g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);
			s_effectSprite._blend = effect;
			s_effectSprite.PaintAFrame(g, s_effectAnim, s_effectFrame, x, y, 0);

			s_effectFrame++;
			resetClip(g);
		}
		else
			s_effectFrame = 100;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

//
//the effects - SHOCKWAVE and COLOR SHOCKWAVE
//
//
CGame.paintHitMarkEffect = function( g, foreground, x, y)
{
	if (foreground == true && CGame.s_hitMarkAnim >= 0)
	{
		g.setClip(0, 0, DEF.VIEW_W, DEF.VIEW_H);

		s_hitMarks.SetCurrentPalette(CGame.s_hitMarkPalette);
		s_hitMarks.PaintAFrame(g, CGame.s_hitMarkAnim, CGame.s_hitMarkFrame, x, y, 0);

		CGame.s_hitMarkFrame += 2;
		if (CGame.s_hitMarkFrame >= s_hitMarks.GetAFrames(CGame.s_hitMarkAnim))
			CGame.s_hitMarkAnim = -1;

		resetClip(g);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

//
//paint the cinematic effect
//
CGame.paintCinematicEffects = function( g, foreground)
{
	if (foreground == true)
	{
		//cinematic effect
		if (false)
			CGame.s_cinematicFrame += 5;
		else
			CGame.s_cinematicFrame -= 5;

		if (CGame.s_cinematicFrame > CGame.k_cinematicBarsHeight)
			CGame.s_cinematicFrame = CGame.k_cinematicBarsHeight;
		if (CGame.s_cinematicFrame < 0)
			CGame.s_cinematicFrame = 0;

		if (CGame.s_cinematicFrame > 0)
		{
			resetClip(g);
			g.setColor(0);
			g.fillRect(0, 0/*VIEWPORT_Y*/, DEF.VIEW_W, CGame.s_cinematicFrame);
			g.fillRect(0, DEF.SCR_H/*VIEWPORT_Y + DEF.VIEW_H*/ - CGame.s_cinematicFrame, DEF.VIEW_W, CGame.s_cinematicFrame);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

CGame.paintEffects = function( g, foreground)
{
	// Paint swarm effect
//		if ((s_game_currentFrameNB % 50) == 0)
//			initSwarmEffect(CGame.k_directionLeft, 0, 0);
	//paintSwarmEffect(g, foreground, 100, 100);

	// Paint dust effect
	if ((s_game_currentFrameNB % 60) == 0) {
		initDustEffect(0, 0);
	}
	//paintDustEffect(g, foreground, 120, 120);

	// Paint flash effect
	if ((s_game_currentFrameNB % 20) == 0) {
		initFlashEffect(1, true, 0, 0);
	}
	//paintFlashEffect(g, foreground, 40, 40);

	// Paint shockwave effect
	if ((s_game_currentFrameNB % 80) == 0) {
		initEffect(CGame.k_effectShockwave, 0, true, 0, 0);
	}
	//paintShockwaveEffect(g, foreground, 160, 60);
	// Paint hitmark effect
	if ((s_game_currentFrameNB % 20) == 0) {
		CGame.s_hitMarkAnim = /*GLLib.*/Math_Rand(0, 4);
		CGame.s_hitMarkFrame = 0;
	}
	//paintHitMarkEffect(g, foreground, 80, 80);

	//paintBlurEffectCurved(g, 0, 0, DEF.SCR_W, 50, 0, s_game_currentFrameNB % 128);
	//paintBlurEffect(g, 0, 0, DEF.SCR_W, 50, 1, s_game_currentFrameNB % 256);
	//paintIGMBlurEffect(g, 0, 0, DEF.SCR_W, 50, s_game_currentFrameNB % 256, s_game_currentFrameNB % 500);
	//paintDesaturatedEffect(g, 0, 0, DEF.SCR_W, 50, s_game_currentFrameNB % 500);
	//paintVideoRewindEffect(g);
	// Paint cinematic effect
	paintCinematicEffects(g, foreground);
}
//@#endif
CGame.speed1 = 1;
CGame.s1 = 24;
CGame.speed2 = 3;//5;
CGame.s2 = 42;
CGame.speed3 = 1;//3;
CGame.s3 = 90;
CGame.speed4 = 4;//8;
CGame.s4 = 50;

CGame._shine_pos = [
	[CGame.s1+0*CGame.speed1, CGame.s1+1*CGame.speed1, -1, CGame.s1+3*CGame.speed1, CGame.s1+4*CGame.speed1, CGame.s1+5*CGame.speed1, -1, CGame.s1+7*CGame.speed1, -1, CGame.s1+7*CGame.speed1, CGame.s1+6*CGame.speed1, CGame.s1+5*CGame.speed1, -1, CGame.s1+3*CGame.speed1, CGame.s1+2*CGame.speed1, -1],
	[CGame.s2-0*CGame.speed2, CGame.s2-1*CGame.speed2, CGame.s2-2*CGame.speed2, CGame.s2-3*CGame.speed2, CGame.s2-4*CGame.speed2, CGame.s2-5*CGame.speed2, CGame.s2-6*CGame.speed2, CGame.s2-7*CGame.speed2, CGame.s2-8*CGame.speed2, CGame.s2-7*CGame.speed2, CGame.s2-6*CGame.speed2, CGame.s2-5*CGame.speed2, CGame.s2-4*CGame.speed2, CGame.s2-3*CGame.speed2, CGame.s2-2*CGame.speed2, CGame.s2-1*CGame.speed2, CGame.s2-0*CGame.speed2, CGame.s2+1*CGame.speed2, CGame.s2+2*CGame.speed2, CGame.s2+1*CGame.speed2],
	[CGame.s3-0*CGame.speed3, CGame.s3-1*CGame.speed3, CGame.s3-2*CGame.speed3, CGame.s3-3*CGame.speed3, CGame.s3-4*CGame.speed3, CGame.s3-5*CGame.speed3, CGame.s3-6*CGame.speed3, CGame.s3-7*CGame.speed3, CGame.s3-8*CGame.speed3, CGame.s3-7*CGame.speed3, CGame.s3-6*CGame.speed3, CGame.s3-5*CGame.speed3, CGame.s3-4*CGame.speed3, CGame.s3-3*CGame.speed3, CGame.s3-2*CGame.speed3, CGame.s3-1*CGame.speed3, CGame.s3-0*CGame.speed3, CGame.s3+1*CGame.speed3],
	[CGame.s4+0*CGame.speed4, CGame.s4+1*CGame.speed4, CGame.s4+2*CGame.speed4, CGame.s4+3*CGame.speed4, CGame.s4+4*CGame.speed4, CGame.s4+5*CGame.speed4, CGame.s4+4*CGame.speed4, CGame.s4+3*CGame.speed4, CGame.s4+3*CGame.speed4, CGame.s4+1*CGame.speed4, CGame.s4+0*CGame.speed4, CGame.s4-1*CGame.speed4, CGame.s4-2*CGame.speed4, CGame.s4-3*CGame.speed4, CGame.s4-4*CGame.speed4, CGame.s4-5*CGame.speed4, CGame.s4-6*CGame.speed4, CGame.s4-7*CGame.speed4, CGame.s4-8*CGame.speed4, CGame.s4-7*CGame.speed4, CGame.s4-6*CGame.speed4, CGame.s4-5*CGame.speed4, CGame.s4-4*CGame.speed4, CGame.s4-3*CGame.speed4, CGame.s4-2*CGame.speed4, CGame.s4-1*CGame.speed4]
]; 

CGame._shineImgs = null;
//@#if BREW_Alpha
//@	var[] _shineImgs_brewdata;
//@	var _shineImgs_brewdata_WH;
//@#endif // BREW_Alpha
CGame.USE_EFFECT_IMAGE = true;


CGame._shine_4444 = null;
CGame._shine_area = [[44, 107, 68, 107, 26], [34, 93, 52, 93, 26]];

CGame.DrawShine = function( dx, dy) {
	for (var i = 0; i < _shine_pos.length; ++i) {
		var index = s_game_currentFrameNB % (_shine_pos[i].length);
		var y = _shine_pos[i][index];
		if (y >= 0) {
			if (CGame.USE_EFFECT_IMAGE) {
//@#if BREW_Alpha
//@					g.drawRGB(_shineImgs_brewdata[i], 0, _shineImgs_brewdata_WH[i * 2], dx, y + dy, _shineImgs_brewdata_WH[i * 2], _shineImgs_brewdata_WH[i * 2 + 1], true);
//@#else // BREW_Alpha
				g.drawImage(_shineImgs[i], dx, y + dy, 0);
//@#endif // BREW_Alpha
			}
			else {
//@#if SupportNokiaAPI
//@					dg.drawPixels(_shine_4444[i], true, 0, _shine_area[0][i], dx, y + dy, _shine_area[0][i], _shine_area[1][i], 0, DirectGraphics.TYPE_USHORT_4444_ARGB);
//@#endif
			}
		}
	}
	_shine_pos[3][0] += 1;
	if (_shine_pos[3][0] > 90) {
		_shine_pos[3][0] = -50;
	}
}


CGame.InitShineEffect = function()
{
//@#if BREW_Alpha
//@		_shineImgs_brewdata_WH = new int[12];
//@#else // BREW_Alpha
	_shine_4444 = LowAPI.Gen_Array([4], null);//new short[4][];
//@#endif // BREW_Alpha
	if (CGame.USE_EFFECT_IMAGE) {
//@#if BREW_Alpha
//@    		_shineImgs_brewdata = new int[6][];
//@#else // BREW_Alpha
		_shineImgs = new Image[6];
//@#endif // BREW_Alpha
		var _shine_8888;
		{
			_shine_8888= LowAPI.Gen_Array([44*34], 0);//new int[44*34];
			Bresenham_Line_8888(0, 0, 44, 24, 180, 0, 10, _shine_8888, 44);//44*34
//@#if BREW_Alpha
//@				_shineImgs_brewdata[0] = _shine_8888;
//@				_shineImgs_brewdata_WH[0] = 44;
//@				_shineImgs_brewdata_WH[1] = 34;
//@#else // BREW_Alpha
			_shineImgs[0] = Image.createRGBImage(_shine_8888, 44, 34, true);
//@#endif // BREW_Alpha
			_shine_8888 = LowAPI.Gen_Array([107*93], 0);//new int [107*93];
			Bresenham_Line_8888(0, 0, 107, 53, 85, 0, 40, _shine_8888, 107);//107*93
//@#if BREW_Alpha
//@				_shineImgs_brewdata[1] = _shine_8888;
//@				_shineImgs_brewdata_WH[2] = 107;
//@				_shineImgs_brewdata_WH[3] = 93;
//@#else // BREW_Alpha
			_shineImgs[1] = Image.createRGBImage(_shine_8888, 107, 93, true);
//@#endif // BREW_Alpha
			_shine_8888 = LowAPI.Gen_Array([68*52], 0);//new int [68*52];
			Bresenham_Line_8888(0, 0, 68, 32, 120, 0, 20, _shine_8888, 68);//68*52
//@#if BREW_Alpha
//@				_shineImgs_brewdata[2] = _shine_8888;
//@				_shineImgs_brewdata_WH[4] = 68;
//@				_shineImgs_brewdata_WH[5] = 52;
//@#else // BREW_Alpha
			_shineImgs[2] = Image.createRGBImage(_shine_8888, 68, 52, true);
//@#endif // BREW_Alpha
//@#if BREW_Alpha
//@				_shineImgs_brewdata[3] = _shineImgs_brewdata[1];
//@				_shineImgs_brewdata_WH[6] = _shineImgs_brewdata_WH[2];
//@				_shineImgs_brewdata_WH[7] = _shineImgs_brewdata_WH[3];
//@#else // BREW_Alpha
			_shineImgs[3] = _shineImgs[1];
//@#endif // BREW_Alpha
		}
		_shine_8888 = LowAPI.Gen_Array([26*26], 0);//new int [26*26];
		Bresenham_Line_8888(0, 0, 26, 26, 0, 250, 1, _shine_8888, 26);//26*26
//@#if BREW_Alpha
//@			_shineImgs_brewdata[4] = _shine_8888;
//@			_shineImgs_brewdata_WH[8] = 26;
//@			_shineImgs_brewdata_WH[9] = 26;
//@#else // BREW_Alpha
		_shineImgs[4] = Image.createRGBImage(_shine_8888, 26, 26, true);
//@#endif // BREW_Alpha

		_shine_8888 = LowAPI.Gen_Array([24*72], 0);//new int [24*72];
		Bresenham_Line_8888(0, 0, 0, 71, 0, 250, 24, _shine_8888, 24);//24*72
//@#if BREW_Alpha
//@			_shineImgs_brewdata[5] = _shine_8888;
//@			_shineImgs_brewdata_WH[10] = 24;
//@			_shineImgs_brewdata_WH[11] = 72;
//@#else // BREW_Alpha
		_shineImgs[5] = Image.createRGBImage(_shine_8888, 24, 72, true);
//@#endif // BREW_Alpha
		_shine_8888 = null;
	}
	else {
		_shine_4444[0] = LowAPI.Gen_Array([44*34], 0);//new short [44*34];
		Bresenham_Line_4444(0, 0, 44, 24, 180, 0, 10, _shine_4444[0], 44);//44*34
		_shine_4444[1] = LowAPI.Gen_Array([107*93], 0);//new short [107*93];
		Bresenham_Line_4444(0, 0, 107, 53, 85, 0, 40, _shine_4444[1], 107);//107*93
		_shine_4444[2] = LowAPI.Gen_Array([68*52], 0);//new short [68*52];
		Bresenham_Line_4444(0, 0, 68, 32, 120, 0, 20, _shine_4444[2], 68);//68*52
		_shine_4444[3] = _shine_4444[1];
	}
}

CGame.Bresenham_Line_4444 = function( x0, y0, x1, y1, alpha0, alpha1, width, dest, scan_line){
	var dx = x1 - x0;
	var dy = y1 - y0;
		var e = dx > 0 ? -dx : dx;
		var step = dx > 0 ? 1 : -1;
		var x = x0;
		var y = y0;
		var index = y0 * scan_line + x0;
		alpha0 <<= 8;
		alpha1 <<= 8;
		var a = (alpha1 - alpha0) / dx;
		for(var i = 0; i < dx; i++){
			var pos = index;
			var c = ((alpha0) | 0x0FFA);
			var k = 0;
			for (; k < width; ++k) {
				   dest[pos] = c;
				pos += scan_line;
			}
			alpha0 += a;
			x += step;
			index += step;
			e += dy<<1;
			if(e >= 0){
				y ++;
				index += scan_line;
				e -= dx<<1;
			}
		}
} 

CGame.Bresenham_Line_8888 = function( x0, y0, x1, y1, alpha0, alpha1, width, dest, scan_line){
	var dx = x1 - x0;
	var dy = y1 - y0;
	if(dx == 0){
		var index = y0 * scan_line + x0;
		alpha0 <<= 8;
		alpha1 <<= 8;
		var a = (alpha1 - alpha0) / dy;
		for(var i = 0; i < dy; i++){
			var pos = index;
			var k = 0;
			var c;
			for (; k < 4; ++k) {
				c = ((((alpha0/5*(k + 1)) & 0xFF00)<<16) | 0x00fffc4c);
				   dest[pos] = c;
				++pos;
			}
			c = (((alpha0 & 0xFF00)<<16) | 0x00fffc4c);
			for (; k < width - 4; ++k) {
				   dest[pos] = c;
				++pos;
			}
			for (; k < width; ++k) {
				c = (((((alpha0/5*(width - k))) & 0xFF00)<<16) | 0x00fffc4c);
				   dest[pos] = c;
				++pos;
			}    			
			alpha0 += a;
			index += scan_line;
		}    		
	} 
	else {
		var e = dx > 0 ? -dx : dx;
		var step = dx > 0 ? 1 : -1;
		var x = x0;
		var y = y0;
		var index = y0 * scan_line + x0;
		alpha0 <<= 8;
		alpha1 <<= 8;
		var a = (alpha1 - alpha0) / dx;
		for(var i = 0; i < dx; i++){
			var pos = index;
			var c = ((alpha0<<16) | 0x00dbdab2);
			var k = 0;
			for (; k < width; ++k) {
				   dest[pos] = c;
				pos += scan_line;
			}
			alpha0 += a;
			x += step;
			index += step;
			e += dy<<1;
			if(e >= 0){
				y ++;
				index += scan_line;
				e -= dx<<1;
			}
		}
	}
}     

CGame.resetClip = function( g) {
	g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
}

//------------------------------------------------------------------------------
/// CreateTransparentImage
//------------------------------------------------------------------------------
//@#if not SupportNokiaAPI
//@#if not FillArgbUseCreateImage
//@	var CGame._rbg_buffer_data;
//@	var CGame._rgb_buffer_last_color;
//@	var CGame.RGB_BUFFER_SIZE = 64;
//@#endif	
//@#endif
//@#if FillArgbUseCreateImage  
CGame._rbg_buffer_data = null;
CGame._rgb_buffer_last_color = 0;
CGame.RGB_BUFFER_SIZE = 64;
CGame._rgb_buffer_img = null;
//@#endif  	
CGame.FillArgbRect = function( x, y, width, height, color) 
{
	// Dbg("WARING : !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Use fillrect instead of .........................................................................");
	FillArgbRect(x, y, width, height, color);
// @#if FillArgbUseCreateImage
	// if (CGame._rbg_buffer_data == null) {
		// CGame._rbg_buffer_data = LowAPI.Gen_Array([CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE], 0);//new int[CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE];
	// }
	// if (color != CGame._rgb_buffer_last_color) {
		// for (var i = 0; i < CGame._rbg_buffer_data.length; i++) {
			// CGame._rbg_buffer_data[i] = color;
		// }
		// CGame._rgb_buffer_last_color = color;
		// CGame._rgb_buffer_img = Image.createRGBImage(CGame._rbg_buffer_data, CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, true);
	// }
	// var _oldClip = LowAPI.Gen_Array([4], 0);//new int[4];
	// _oldClip[0] = g.getClipX();
	// _oldClip[1] = g.getClipY();
	// _oldClip[2] = g.getClipWidth();
	// _oldClip[3] = g.getClipHeight();
	// var nbWidth = width / CGame.RGB_BUFFER_SIZE;
	// var nbHeight = height / CGame.RGB_BUFFER_SIZE;
	// for (var i = 0; i < nbWidth; i++) {
		// for (var j = 0; j < nbHeight; j++) {
			// DrawImage(CGame._rgb_buffer_img, x + i * CGame.RGB_BUFFER_SIZE, y + j * CGame.RGB_BUFFER_SIZE, TOP|LEFT);
		// }
	// }
	// if (nbWidth * CGame.RGB_BUFFER_SIZE < width) {
		// for (var j = 0; j < nbHeight; j++) {
			// SetClip(x + nbWidth * CGame.RGB_BUFFER_SIZE, y + j * CGame.RGB_BUFFER_SIZE, width - nbWidth * CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE);
			// DrawImage(CGame._rgb_buffer_img, x + nbWidth * CGame.RGB_BUFFER_SIZE, y + j * CGame.RGB_BUFFER_SIZE, TOP|LEFT);
		// }
	// }
	// if (nbHeight * CGame.RGB_BUFFER_SIZE < height) {
		// for (var i = 0; i < nbWidth; i++) {
			// SetClip(x + i * CGame.RGB_BUFFER_SIZE,  y + nbHeight * CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, height - nbHeight * CGame.RGB_BUFFER_SIZE);
			// DrawImage(CGame._rgb_buffer_img, x + i * CGame.RGB_BUFFER_SIZE, y + nbHeight * CGame.RGB_BUFFER_SIZE, TOP|LEFT);
		// }
	// }
	// if (nbWidth * CGame.RGB_BUFFER_SIZE < width && nbHeight * CGame.RGB_BUFFER_SIZE < height) {
		// SetClip(x + nbWidth * CGame.RGB_BUFFER_SIZE, y + nbHeight * CGame.RGB_BUFFER_SIZE, width - nbWidth * CGame.RGB_BUFFER_SIZE, height - nbHeight * CGame.RGB_BUFFER_SIZE);
		// DrawImage(CGame._rgb_buffer_img, x + nbWidth * CGame.RGB_BUFFER_SIZE, y + nbHeight * CGame.RGB_BUFFER_SIZE, TOP|LEFT);
	// }
	// SetClip(_oldClip[0], _oldClip[1], _oldClip[2], _oldClip[3]);	

//@#else //FillArgbUseCreateImage		
//@#if SupportNokiaAPI		
//@		dg.setARGBColor(color);
//@		g.fillRect(x, y, width, height);
//@#else
//@		if (CGame._rbg_buffer_data == null) {
//@			CGame._rbg_buffer_data = new int[CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE];
//@		}
//@		if (color != CGame._rgb_buffer_last_color) {
//@			for (int i = 0; i < CGame._rbg_buffer_data.length; i++) {
//@				CGame._rbg_buffer_data[i] = color;
//@			}
//@			CGame._rgb_buffer_last_color = color;
//@		}
//@		
//@		int nbWidth = width / CGame.RGB_BUFFER_SIZE;
//@		int nbHeight = height / CGame.RGB_BUFFER_SIZE;
//@		for (int i = 0; i < nbWidth; i++) {
//@			for (int j = 0; j < nbHeight; j++) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, x + i * CGame.RGB_BUFFER_SIZE, y + j * CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, true);
//@			}
//@		}
//@		if (nbWidth * CGame.RGB_BUFFER_SIZE < width) {
//@			for (int j = 0; j < nbHeight; j++) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, x + nbWidth * CGame.RGB_BUFFER_SIZE, y + j * CGame.RGB_BUFFER_SIZE, width - nbWidth * CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, true);
//@			}
//@		}
//@		if (nbHeight * CGame.RGB_BUFFER_SIZE < height) {
//@			for (int i = 0; i < nbWidth; i++) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, x + i * CGame.RGB_BUFFER_SIZE, y + nbHeight * CGame.RGB_BUFFER_SIZE, CGame.RGB_BUFFER_SIZE, height - nbHeight * CGame.RGB_BUFFER_SIZE, true);
//@			}
//@		}
//@		
//@		if (nbWidth * CGame.RGB_BUFFER_SIZE < width && nbHeight * CGame.RGB_BUFFER_SIZE < height) {
//@			DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, x + nbWidth * CGame.RGB_BUFFER_SIZE, y + nbHeight * CGame.RGB_BUFFER_SIZE, width - nbWidth * CGame.RGB_BUFFER_SIZE, height - nbHeight * CGame.RGB_BUFFER_SIZE, true);
//@		}
//@#endif//SupportNokiaAPI
//@#endif//FillArgbUseCreateImage
}

CGame.DrawArgbLine = function( x1, y1, x2, y2, color) {
//@#if FillArgbUseCreateImage
	// if (CGame._rbg_buffer_data == null) {
		// CGame._rbg_buffer_data = LowAPI.Gen_Array([CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE], 0);//new int[CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE];
	// }
	var _oldClip = LowAPI.Gen_Array([4], 0);//new int[4];
	_oldClip[0] = g.getClipX();
	_oldClip[1] = g.getClipY();
	_oldClip[2] = g.getClipWidth();
	_oldClip[3] = g.getClipHeight();
	/*if (x1 == x2) {
		for (var i = 0; i <  CGame.RGB_BUFFER_SIZE; i++) {
			CGame._rbg_buffer_data[i] = color;
		}
		if (CGame._rgb_buffer_last_color != color)
		{
			// CGame._rgb_buffer_img = Image.createRGBImage(CGame._rbg_buffer_data, 1, CGame.RGB_BUFFER_SIZE, true);
			CGame._rgb_buffer_last_color = color;
		}
		var min = Math.min(y1, y2);
		var max = Math.max(y1, y2);
		var nbHeight = Math.floor((max - min) / CGame.RGB_BUFFER_SIZE);
		// for (var i = 0; i < nbHeight; i++) {
			// SetClip(x1, min + i * CGame.RGB_BUFFER_SIZE, 1, CGame.RGB_BUFFER_SIZE);
			// DrawImage(CGame._rgb_buffer_img, x1, min + i * CGame.RGB_BUFFER_SIZE, LEFT|TOP);
		// }
		SetClip( x1, min, 1, nbHeight*CGame.RGB_BUFFER_SIZE);
		FillArgbRect( x1, min, 1, nbHeight*CGame.RGB_BUFFER_SIZE, color);
		if (nbHeight * CGame.RGB_BUFFER_SIZE < max - min) {
			SetClip(x1, min + nbHeight * CGame.RGB_BUFFER_SIZE, 1, (max - min) - nbHeight * CGame.RGB_BUFFER_SIZE);
			// DrawImage(CGame._rgb_buffer_img, x1, min + nbHeight * CGame.RGB_BUFFER_SIZE, LEFT|TOP);
			FillArgbRect(x1, min + nbHeight * CGame.RGB_BUFFER_SIZE, 1, (max - min) - nbHeight * CGame.RGB_BUFFER_SIZE, color);
		}
	}else if (y1 == y2) {
		var min = Math.min(x1, x2);
		var max = Math.max(x1, x2);
		for (var i = 0; i < CGame.RGB_BUFFER_SIZE; i++) {
			CGame._rbg_buffer_data[i] = color;
		}
		if (CGame._rgb_buffer_last_color != color)
		{
			// CGame._rgb_buffer_img = Image.createRGBImage(CGame._rbg_buffer_data, CGame.RGB_BUFFER_SIZE, 1, true);
			CGame._rgb_buffer_last_color = color;
		}
		var nbWidth = Math.floor((max - min) / CGame.RGB_BUFFER_SIZE);
		// for (var i = 0; i < nbWidth; i++) {
			// SetClip(min + i * CGame.RGB_BUFFER_SIZE, y1, CGame.RGB_BUFFER_SIZE, 1);
			// DrawImage(CGame._rgb_buffer_img, min + i * CGame.RGB_BUFFER_SIZE, y1, LEFT|TOP);
		// }
		SetClip(min , y1, nbWidth*CGame.RGB_BUFFER_SIZE, 1);
		FillArgbRect(min , y1, nbWidth*CGame.RGB_BUFFER_SIZE, 1, color);
		if (nbWidth * CGame.RGB_BUFFER_SIZE < max - min) {
			SetClip(min + nbWidth * CGame.RGB_BUFFER_SIZE, y1, (max - min) - nbWidth * CGame.RGB_BUFFER_SIZE, 1);
			// DrawImage(CGame._rgb_buffer_img, min + nbWidth * CGame.RGB_BUFFER_SIZE, y1, LEFT|TOP);
			FillArgbRect(min + nbWidth * CGame.RGB_BUFFER_SIZE, y1, (max - min) - nbWidth * CGame.RGB_BUFFER_SIZE, 1, color);
		}			
	} else */{
		g.setColor(color);
		g.drawLine(x1, y1, x2, y2);
	}
	SetClip(_oldClip[0], _oldClip[1], _oldClip[2], _oldClip[3]);	

//@#else		
//@#if SupportNokiaAPI		
//@		dg.setARGBColor(color);
//@		g.drawLine(x1, y1, x2, y2);
//@#else
//@		if (CGame._rbg_buffer_data == null) {
//@			CGame._rbg_buffer_data = new int[CGame.RGB_BUFFER_SIZE * CGame.RGB_BUFFER_SIZE];
//@		}
//@
//@		if (x1 == x2) {
//@			for (int i = 0; i < CGame.RGB_BUFFER_SIZE; i++) {
//@				CGame._rbg_buffer_data[i] = color;
//@			}
//@			int min = Math.min(y1, y2);
//@			int max = Math.max(y1, y2);
//@			int nbHeight = (max - min) / CGame.RGB_BUFFER_SIZE;
//@			for (int i = 0; i < nbHeight; i++) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, 1, x1, min + i * CGame.RGB_BUFFER_SIZE, 1, CGame.RGB_BUFFER_SIZE, true);
//@			}
//@			if (nbHeight * CGame.RGB_BUFFER_SIZE < max - min) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, 1, x1, min + nbHeight * CGame.RGB_BUFFER_SIZE, 1, (max - min) - nbHeight * CGame.RGB_BUFFER_SIZE, true);
//@			}
//@			for (int i = 0; i < CGame.RGB_BUFFER_SIZE; i++) {
//@				CGame._rbg_buffer_data[i] = CGame._rgb_buffer_last_color;
//@			}
//@		} else if (y1 == y2) {
//@			int min = Math.min(x1, x2);
//@			int max = Math.max(x1, x2);
//@			for (int i = 0; i < CGame.RGB_BUFFER_SIZE; i++) {
//@				CGame._rbg_buffer_data[i] = color;
//@			}
//@			int nbWidth = (max - min) / CGame.RGB_BUFFER_SIZE;
//@			for (int i = 0; i < nbWidth; i++) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, min + i * CGame.RGB_BUFFER_SIZE, y1, CGame.RGB_BUFFER_SIZE, 1, true);
//@			}
//@			if (nbWidth * CGame.RGB_BUFFER_SIZE < max - min) {
//@				DrawRGB(CGame._rbg_buffer_data, 0, CGame.RGB_BUFFER_SIZE, min + nbWidth * CGame.RGB_BUFFER_SIZE, y1, (max - min) - nbWidth * CGame.RGB_BUFFER_SIZE, 1, true);
//@			}			
//@			for (int i = 0; i < CGame.RGB_BUFFER_SIZE; i++) {
//@				CGame._rbg_buffer_data[i] = CGame._rgb_buffer_last_color;
//@			}
//@		} else {
//@			g.setColor(color);
//@			g.drawLine(x1, y1, x2, y2);
//@		}
//@#endif
//@#endif		
}

CGame.DrawBresenhamLine = function( rgbData, width, height, x1, y1, x2, y2, color) {
	var dx = x2 - x1;
	var dy = y2 - y1;
	var e = -Math.abs(dx);
	var step = dx > 0 ? 1 : -1;
	var x = x1;
	var y = y1;
	var index = y1 * width + x1;
	for(var i = 0; i < dx; i++) {
		var pos = index;
		var k = 0;
		for (; k < width; ++k) {
			rgbData[pos] = color;
			pos += width;
		}
		x += step;
		index += step;
		e += dy << 1;
		if(e >= 0) {
			y ++;
			index += width;
			e -= dx << 1;
		}
	}
}
CGame.RotateImage = function( srcMap, srcW, srcH, cx, cy, rotaryAngle, dd)
{

	var dstW = srcW + srcH;
	var dstH = dstW;
	var dr = dstW / 2;
	var destMap = LowAPI.Gen_Array([dstW * dstH], 0);//new int[dstW * dstH];

	var sinA,cosA;
	sinA = /*GLLib.*/Math_Sin(rotaryAngle);
	cosA = /*GLLib.*/Math_Cos(rotaryAngle);
	var Ax_16= cosA << 8;
	var Ay_16= sinA << 8;
	var Bx_16= -sinA << 8;
	var By_16= cosA << 8;
	var rx0 = cx;
	var ry0 = cy;
	var movex0 = srcH / 2;
	var movey0 = dr;
	var Cx_16 = ((-(rx0 + movex0)* cosA + (ry0 + movey0) * sinA) << 8) + (rx0 << 16);
	var Cy_16 = ((-(rx0 + movex0) * sinA - (ry0 + movey0) * cosA) << 8) + (ry0 << 16);


	var srcx0_16 = (Cx_16);
	var srcy0_16 = (Cy_16);
	var destOffset = 0;
	for (var y = 0; y < dstH; ++y) {
		var srcx_16 = srcx0_16;
		var srcy_16 = srcy0_16;
		for (var x = 0; x < dstW; ++x) {
			var srcx = (srcx_16 >> 16);
			var srcy = (srcy_16 >> 16);
			var pixelsIsInPic = (srcx >= 0) && (srcx < srcW) && (srcy >= 0) && (srcy < srcH);
			if (pixelsIsInPic) {
				destMap[destOffset] = srcMap[srcy * srcW + srcx];
			}
			destOffset++;
			srcx_16 += Ax_16;
			srcy_16 += Ay_16;
		}
		srcx0_16 += Bx_16;
		srcy0_16 += By_16;
	}
	dd[0] = cx - dr;
	dd[1] = cy - dr;
	dd[2] = dstW;
	dd[3] = dstH;
	return destMap;
}
//@#if IncludeMap3d
//@	var _map3d;
//@	static GLLibPlayer[] _map3d_players;
//@
//@	GLLibPlayer[] _map3d_BG_players;
//@	var MINI_MAP_CLOUD = 0;
//@	var MINI_MAP_WAVE1 = 1;
//@	var MINI_MAP_WAVE2 = 2;
//@	var MINI_MAP_WAVE3 = 3;
//@	var MINI_MAP_LAND = 4;
//@	var MINI_MAP_SURF = 5;
//@	var MINI_MAP_SKY_HEIGHT = 120;
//@	var MINI_MAP_LAND_HEIGHT = 200;
//@	int[][] _map3d_data;
//@
//@	private void LoadMap3d() {
//@		_map = new ASprite();
//@		Pack_Open(DATA.PACK_SPRITE);
//@//		_map.Load(Pack_ReadData(DATA.SPRITE_MINI_MAP), 0);
//@		Pack_Close();
//@//		Pack_Open(DATA.PACK_MISC);
//@//		_map3d = Pack_ReadData(DATA.MISC_MAP3D);
//@		Pack_Close();
//@		int offset = 0;
//@		int count = Mem_GetShort(_map3d, offset);		offset += 2;
//@
//@		_map3d_BG_players = new GLLibPlayer[6];
//@		_map3d_BG_players[MINI_MAP_CLOUD] = new GLLibPlayer(_map, DEF.SCR_W_D2, 0);
//@		_map3d_BG_players[MINI_MAP_CLOUD].SetAnim(DAnimID.MINI_MAP_CLOUD, -1);
//@		_map3d_BG_players[MINI_MAP_WAVE1] = new GLLibPlayer(_map, DEF.SCR_W_D2, MINI_MAP_SKY_HEIGHT);
//@		_map3d_BG_players[MINI_MAP_WAVE1].SetAnim(DAnimID.MINI_MAP_WAVE1, -1);
//@		_map3d_BG_players[MINI_MAP_WAVE2] = new GLLibPlayer(_map, DEF.SCR_W_D2, MINI_MAP_SKY_HEIGHT);
//@		_map3d_BG_players[MINI_MAP_WAVE2].SetAnim(DAnimID.MINI_MAP_WAVE2, -1);
//@		_map3d_BG_players[MINI_MAP_WAVE3] = new GLLibPlayer(_map, DEF.SCR_W_D2, MINI_MAP_SKY_HEIGHT);
//@		_map3d_BG_players[MINI_MAP_WAVE3].SetAnim(DAnimID.MINI_MAP_WAVE3, -1);
//@		_map3d_BG_players[MINI_MAP_LAND] = new GLLibPlayer(_map, DEF.SCR_W_D2, MINI_MAP_LAND_HEIGHT);
//@		_map3d_BG_players[MINI_MAP_LAND].SetAnim(DAnimID.MINI_MAP_LAND, -1);
//@		_map3d_BG_players[MINI_MAP_SURF] = new GLLibPlayer(_map, DEF.SCR_W_D2, MINI_MAP_LAND_HEIGHT);
//@		_map3d_BG_players[MINI_MAP_SURF].SetAnim(DAnimID.MINI_MAP_SURF, -1);
//@
//@		_map3d_players = new GLLibPlayer[count];
//@		_map3d_data = new int[count][3];
//@		for (int i = 0; i < count; i++) {
//@			int anim = Mem_GetShort(_map3d, offset);		offset += 2;
//@			int x = Mem_GetShort(_map3d, offset);		offset += 2;
//@			int y = Mem_GetShort(_map3d, offset);		offset += 2;
//@			_map3d_players[i] = new GLLibPlayer(_map, DEF.SCR_W_D2 + x, MINI_MAP_LAND_HEIGHT + y * 2);
//@			_map3d_players[i].SetAnim(anim, -1);
//@			_map3d_data[i][0] = anim;
//@			_map3d_data[i][1] = x;
//@			_map3d_data[i][2] = y * 2;
//@		}
//@	}
//@	private void DrawMap3d() throws IOException {
//@		g.setColor(0x7adef5);
//@		g.fillRect(0, 0, DEF.SCR_W, MINI_MAP_SKY_HEIGHT);
//@		g.setColor(0x184098);
//@		g.fillRect(0, MINI_MAP_SKY_HEIGHT, DEF.SCR_W, DEF.SCR_H - MINI_MAP_SKY_HEIGHT);
//@		if (_map3d == null) {
//@			LoadMap3d();
//@		}
//@		theta -= 2 << DEF.SHIFT;
//@		//theta &= Math_AngleMUL - 1;
//@		for (int i = 0; i < _map3d_BG_players.length; i++) {
//@			if (_map3d_BG_players[i] != null) {
//@				_map3d_BG_players[i].Update(s_game_frameDT);
//@				if (i == MINI_MAP_CLOUD) {
//@					int x = _map3d_BG_players[i].posX + 4;
//@					int y = _map3d_BG_players[i].posY;
//@					_map3d_BG_players[i].SetPos(x - DEF.SCR_W, y);
//@					if (x > DEF.SCR_W + DEF.SCR_W_D2) {
//@						x = DEF.SCR_W_D2;
//@					}
//@					_map3d_BG_players[i].Render();
//@					_map3d_BG_players[i].SetPos(x, y);
//@				}
//@				_map3d_BG_players[i].Render();
//@			}
//@		}
//@//		Image imageFG = Image.createImage(this.getClass().getResourceAsStream("/fg.png"));
//@//
//@//		int[] offset = new int[2];
//@//		theta += 1;
//@//		//imageBG = rotate(imageBG, imageBG.getWidth() / 2, imageBG.getHeight() / 2, theta, offset);
//@//		double[] destPts = new double[map3d.length];
//@		Map3dRotate(_map3d_data, _map3d_players, 0, 0, theta);
//@		Map3dSortByY(_map3d_players);
//@		for (int i = 0; i < _map3d_players.length; i++) {
//@			if (_map3d_players[i].GetAnim() != DAnimID.MINI_MAP_LAND && _map3d_players[i].GetAnim() != DAnimID.MINI_MAP_SURF) {
//@				_map3d_players[i].Update(s_game_frameDT);
//@				_map3d_players[i].SetPos(DEF.SCR_W_D2 + _map3d_players[i].posX, MINI_MAP_LAND_HEIGHT + _map3d_players[i].posY);
//@				_map3d_players[i].Render();
//@			}
//@		}
//@	}
//@	/**
//@	 * @param pts
//@	 * @param cx
//@	 * @param cy
//@	 * @param theta
//@	 * @return
//@	 */
//@	void Map3dRotate(int[][] srcPts, GLLibPlayer[] destPlayers, int cx, int cy, int theta) {
//@		int length = srcPts.length;
//@		for (int i = 0; i < length; i++) {
//@			int anim = srcPts[i][0];
//@			int x = srcPts[i][1];
//@			int y = srcPts[i][2];
//@			destPlayers[i].SetAnim(anim, -1);
//@			destPlayers[i].posX = cx + Math_FixedPointToInt((x - cx) * /*GLLib.*/Math_Cos(theta) + (y - cy) * /*GLLib.*/Math_Sin(theta));
//@			destPlayers[i].posY = cy + Math_FixedPointToInt((y - cy) * /*GLLib.*/Math_Cos(theta) - (x - cx) * /*GLLib.*/Math_Sin(theta));
//@			destPlayers[i].posY /= 2;
//@		}
//@	}
//@
//@	void Map3dSortByY(GLLibPlayer[] players) {
//@		int length = players.length;
//@		for (int i = 0; i < length; i++) {
//@			for (int j = i + 1; j < length; j++) {
//@				int y = players[j].posY;
//@				if (y < players[i].posY) {
//@					GLLibPlayer temp = players[j];
//@					players[j] = players[i];
//@					players[i] = temp;
//@				}
//@			}
//@		}
//@	}
//@	var theta = 0;
//@#endif //IncludeMap3d

//@#if not RemoveMinimap
//@#if NewMiniMap
CGame.MINI_MAP_STATE_OUT_LEVEL = 0;
CGame.MINI_MAP_STATE_NEW_LEVEL_OPEN = 1;
CGame.MINI_MAP_STATE_NEW_GAME = 2;
CGame.MINI_MAP_STATE_NEW_WORLD = 3;
CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO = 4;
CGame.MINI_MAP_STATE_IDLE = 5;
CGame.MINI_MAP_STATE_HERO_MOVE_TO = 6;
CGame.MINI_MAP_STATE_SWITCH_TO_LEVEL_ROOM = 7;
CGame.MINI_MAP_STATE_SWITCH_TO_WORLD_ROOM = 8;
CGame.MINI_MAP_STATE_ARE_YOU_SURE = 9;
CGame.MINI_MAP_STATE_ENTER_LEVEL = 10;
CGame.MINI_MAP_STATE_OVER = 11;

CGame.MINI_MAP_ALPHA_PAL = 7;
CGame.MINI_MAP_BOSS_ENABLE_PAL = 6;
CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
CGame._miniMapTick = 0;
CGame._miniMapLimit = null;
CGame._miniMapLimitWorldRoom = [ 0, 0, 20 * DEF.TILE_W, DEF.SCR_H ];
CGame._miniMapLimitLevelRoom = [ 22 * DEF.TILE_W, 0, 38 * DEF.TILE_W, DEF.SCR_H ];
//@#if not RemoveIceLevel        
//@	var CGame._miniMapRoomPoint = new int[] {
//@		DEF.TILE_W * 10, DEF.TILE_H * 7 + DEF.TILE_H_D2,
//@		DEF.TILE_W * 3, DEF.TILE_H * 9,
//@		DEF.TILE_W * 17, DEF.TILE_H * 9, 
//@		DEF.TILE_W * 5, DEF.TILE_H * 12, 
//@		DEF.TILE_W * 15, DEF.TILE_H * 12, 
//@		DEF.TILE_W * 10, DEF.TILE_H * 11, 
//@		
//@		DEF.TILE_W * 30, DEF.TILE_H * 13,
//@		DEF.TILE_W * 30, DEF.TILE_H * 7 + DEF.TILE_H_D2,
//@		DEF.TILE_W * 25, DEF.TILE_H * 9,
//@		DEF.TILE_W * 35, DEF.TILE_H * 9,
//@		DEF.TILE_W * 30, DEF.TILE_H * 10 + DEF.TILE_H_D2,														
//@	};
//@#else
	CGame._miniMapRoomPoint =[
		DEF.TILE_W * 5, DEF.TILE_H * 12, 
		DEF.TILE_W * 3, DEF.TILE_H * 9,
		DEF.TILE_W * 17, DEF.TILE_H * 9, 

		DEF.TILE_W * 15, DEF.TILE_H * 12, 
		DEF.TILE_W * 10, DEF.TILE_H * 7 + DEF.TILE_H_D2,
		
		DEF.TILE_W * 30, DEF.TILE_H * 13,
		DEF.TILE_W * 30, DEF.TILE_H * 7 + DEF.TILE_H_D2,
		DEF.TILE_W * 25, DEF.TILE_H * 9,
		DEF.TILE_W * 35, DEF.TILE_H * 9,
		DEF.TILE_W * 30, DEF.TILE_H * 10 + DEF.TILE_H_D2,														
	];
//@#endif        

CGame.MINI_MAP_WORLD_ROOM_POINTS_INDEX = 0;
//@#if not RemoveIceLevel	
//@	var CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX = 12;
//@	
//@	var CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX = 20;
//@	var CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX = 10;
//@#else
CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX = 10;
CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX = 18;
CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX = 8;
//@#endif	

CGame._miniMapCameraX = 0;
CGame._miniMapCameraY = 0;
CGame._miniMapHeroX = 0;
CGame._miniMapHeroY = 0;
CGame._miniMapHeroAnim = 0;
CGame._miniMapHeroFlags = 0;
CGame._miniMapHeroAtPoint = -1;
CGame._miniMapCursorX = 0;
CGame._miniMapCursorY = 0;
CGame._miniMapCursorAtPoint = -1;
CGame._miniMapNewLevelOpened = 1;
CGame._miniMapWorldIconAlpha = 0xFF;
CGame._miniMapWorldIconAlphaStep = 0x08;
CGame._previousLevelID = -1;
CGame.MINI_MAP_OFFSET_Y = 2 * DEF.TILE_H;
CGame.MINI_MAP_CURSOR_VELOCITY = 8 * DScreen.RATIO;
CGame.MINI_MAP_HERO_MOVE_VELOCITY = 8 * DScreen.RATIO;

CGame.MINI_MAP_WATCH_SPEAK_TICK = 15;
CGame.MINI_MAP_WATCH_DISAPPEAR_TICK = 20;
CGame.MINI_MAP_WATCH_OVER_TICK = 25;

CGame.MINI_MAP_DOOR_LOCKED = 0; 
CGame.MINI_MAP_DOOR_OPENED = 1; 
CGame.MINI_MAP_DOOR_UNLOCKED = 2;


CGame.CheckMiniMapLimit = function() {
	CGame._miniMapCameraX = Math.max(CGame._miniMapCameraX, CGame._miniMapLimit[DEF.BOX_LEFT]);
	CGame._miniMapCameraY = Math.max(CGame._miniMapCameraY, CGame._miniMapLimit[DEF.BOX_TOP]);

	CGame._miniMapCameraX = Math.min(CGame._miniMapCameraX, CGame._miniMapLimit[DEF.BOX_RIGHT] - DEF.VIEW_W);
	CGame._miniMapCameraY = Math.min(CGame._miniMapCameraY, CGame._miniMapLimit[DEF.BOX_BOTTOM] - DEF.VIEW_H);

	CGame._miniMapCursorX = Math.max(CGame._miniMapCursorX, CGame._miniMapLimit[DEF.BOX_LEFT]);
	CGame._miniMapCursorY = Math.max(CGame._miniMapCursorY, CGame._miniMapLimit[DEF.BOX_TOP]);

	CGame._miniMapCursorX = Math.min(CGame._miniMapCursorX, CGame._miniMapLimit[DEF.BOX_RIGHT]);
	CGame._miniMapCursorY = Math.min(CGame._miniMapCursorY, CGame._miniMapLimit[DEF.BOX_BOTTOM] - CGame.MINI_MAP_OFFSET_Y);
}
CGame.LevelId2PointId = function( level) {
	var point = (level) % DAI.LEVELS_NUM_PRE_WORLD;
	point = point * 2 + CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX + 2;
	return point;
}

CGame.IsUnlockedWorld = function( level) {
	if (level >= DAI.WORLD_ID_CASTLE * DAI.LEVELS_NUM_PRE_WORLD) {
		return true;
	}
	if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
		return true;
	}
	if (level >= DAI.WORLD_ID_CASTLE * DAI.LEVELS_NUM_PRE_WORLD) {
		return true;
	}
	if (level < 0) {
		return true;
	}
	if (level == 0) {
		return false;
	}
	return level % DAI.LEVELS_NUM_PRE_WORLD == 0;
}
CGame.GetLevelUnlocked = function() {
	for (var i = 0; i < CGame._levelInfo.length ; i++) {
		if (CGame._levelInfo[i] == 0) {
			return i - 1;
		}
	}
	return -1;
}
CGame._miniMapLoadStep = 0;
CGame.MINI_MAP_LOADING_STEP = 10;

CGame.GotoMiniMap = function() {
	CGame.StopSound(DSound_Channel.BGM);
	playsoud_cutscene_story = false;
	if( CGame._miniMapLoadStep < CGame.MINI_MAP_LOADING_STEP )
	{
		CGame.DrawSpecialEffect_Load_Unload_MiniMap(CGame._miniMapLoadStep);
		CGame.LoadMiniMap();
		CGame._miniMapLoadStep ++;
		return;
	}
	CGame._miniMapLoadStep = 0;
	GLLibPlayer.Tileset_SetCamera(0, CGame._miniMapCameraX, CGame._miniMapCameraY);
	CGame._levelUnlocked = CGame.GetLevelUnlocked();
	CGame._worldId = Math.floor((CGame._levelUnlocked - 1) / DAI.LEVELS_NUM_PRE_WORLD);
	CGame._worldId = CGame._worldId < 0 ? 0 : CGame._worldId; // WARNING : avoid _worldId < 0
	if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
		CGame._worldId = -1;
	}
	if (CGame.IsUnlockedWorld(CGame._levelUnlocked)) {
		CGame._miniMapLimit = CGame._miniMapLimitWorldRoom;
		var point = CGame._worldId << 1;
		point = Math.min(point, CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX);
		var offx = 0;
		if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
//@#if not RemoveIceLevel
//@				point = DAI.WORLD_ID_CASTLE << 1;
//@#else
			point = DAI.WORLD_ID_SPACE << 1;
			offx = -2*DEF.TILE_W;
//@#endif
		}
		CGame._miniMapHeroX = CGame._miniMapRoomPoint[point] + offx;
		CGame._miniMapHeroY = CGame._miniMapRoomPoint[point + 1];
		CGame._miniMapHeroAtPoint = point;
	} else {
		CGame._miniMapLimit = CGame._miniMapLimitLevelRoom;
		var point = CGame.LevelId2PointId(CGame._tempLevelId);
		CGame._miniMapHeroX = CGame._miniMapRoomPoint[point];
		CGame._miniMapHeroY = CGame._miniMapRoomPoint[point + 1];
		CGame._miniMapHeroAtPoint = point;
	}
	CGame._miniMapCursorX = CGame._miniMapHeroX;
	CGame._miniMapCursorY = CGame._miniMapHeroY - DEF.TILE_H;
	CGame._miniMapCameraX = CGame._miniMapCursorX - DEF.VIEW_W_D2;
	CGame._miniMapCameraY = CGame._miniMapCursorY - DEF.VIEW_H_D2;
	CGame._miniMapCursorAtPoint = -1;
	CGame._miniMapState = CGame.MINI_MAP_STATE_OUT_LEVEL;
	CGame._miniMapTick = 0;
	CGame.SetPause(DPauseType.FADE_IN, DPauseType.FADE_EFFECT_CIRCLE);
	s_game_state = STATE.MENU_MAP;
	CGame.loadingPhase = 0;
	CGame._miniMapHeroAnim = 0;
	CGame._miniMapHeroFlags = 0;
	CGame.PlaySoundBGM();
	CGame.bIsPaused = false;
//@#if DEFINEZ_TEXT_BUBBLE_POS		
//@		initCurrentBubbleTextPos(true);
//@#endif
}
CGame.prototype.SetVelocityByDest = function(velocity, dx, dy) {
	var angle = Math_Atan(dx, dy);
	CEntity._TempIntArray[DParamIndex.POSX] = /*GLLib.*/Math_FixedPoint_Multiply(velocity, /*GLLib.*/Math_Cos(angle));
	CEntity._TempIntArray[DParamIndex.POSY] = /*GLLib.*/Math_FixedPoint_Multiply(velocity, /*GLLib.*/Math_Sin(angle));
	if (!Math_SameSign(CEntity._TempIntArray[DParamIndex.POSX], dx) || Math.abs(CEntity._TempIntArray[DParamIndex.POSX]) > Math.abs(dx)) {
		CEntity._TempIntArray[DParamIndex.POSX] = dx;
	}
	if (!Math_SameSign(CEntity._TempIntArray[DParamIndex.POSY], dy) || Math.abs(CEntity._TempIntArray[DParamIndex.POSY]) > Math.abs(dy)) {
		CEntity._TempIntArray[DParamIndex.POSY] = dy;
	}
}

CGame.prototype.UpdateMiniMap = function() {	
	if (s_game_interruptNotify) {
		CGame.initIngameMenu(STATE.MENU_INGAME);
		return;
	}
	switch (CGame._miniMapState) {
	case CGame.MINI_MAP_STATE_OUT_LEVEL:
		_fade_circle_centerX = CGame._miniMapHeroX - CGame._miniMapCameraX;
		_fade_circle_centerY = CGame._miniMapHeroY - CGame._miniMapCameraY;
		this.PauseUpdate();
		if (_pauseType == DPauseType.NONE) {
			if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
				CGame._miniMapState = CGame.MINI_MAP_STATE_NEW_GAME;
			} else if (CGame._levelUnlocked >= 0) {
				CGame._miniMapState = CGame.MINI_MAP_STATE_NEW_LEVEL_OPEN;
			} else {
				CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
			}
		}
		break;
	case CGame.MINI_MAP_STATE_NEW_LEVEL_OPEN:
		var effectAFrames = CGame.spriteArray[DSpriteID.EFFECT].GetAFrames(DAnimID.EFFECT_RANDOM_MAGIC); 
		if (CGame._miniMapTick < effectAFrames && CGame._levelUnlocked >= 0) {
			CGame._miniMapTick++;
		} else {
			CGame._miniMapState = CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO;
			CGame._miniMapTick = 0;
		}
		break;
	case CGame.MINI_MAP_STATE_NEW_GAME:
		switch (CGame._miniMapTick) {
		case 0:
			CGame.StartTextBubble(-1, Math_IntToFixedPoint(CGame._miniMapHeroX), Math_IntToFixedPoint(CGame._miniMapHeroY + DEF.TILE_H * 2), TEXT.MENU_MINI_BOY_1);
			CGame._miniMapTick++;
			break;
		case 1:
			if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
				CGame._miniMapTick = 0;
				CGame._miniMapState = CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO;
			}
			break;
		}
		if (WasKeyReleased(GLKey.k_menuBack)) {
			CGame.CloseTextBubble();
			CGame._miniMapTick = 0;
			CGame._miniMapState = CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO;
		}
		break;
	case CGame.MINI_MAP_STATE_NEW_WORLD:
		if (CGame._miniMapTick == CGame.MINI_MAP_WATCH_SPEAK_TICK) {
			CGame.StartTextBubble(-1, Math_IntToFixedPoint(CGame._miniMapRoomPoint[(CGame._worldId + 1) << 1]), Math_IntToFixedPoint(CGame._miniMapRoomPoint[((CGame._worldId + 1) << 1) + 1] + DEF.TILE_H * 2), this.GetLevelWizardTextByWorldId(CGame._worldId));
			CGame._miniMapTick++;
		} else if (CGame._miniMapTick > CGame.MINI_MAP_WATCH_OVER_TICK) {
			CGame._miniMapState = CGame.MINI_MAP_STATE_HERO_MOVE_TO;
			CGame._miniMapTick = 0;
		} else if (CGame._miniMapTick > CGame.MINI_MAP_WATCH_SPEAK_TICK) {
			if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
				CGame._miniMapTick++;
			}
		} else {
			CGame._miniMapTick++;
		}
		if (WasKeyReleased(GLKey.k_menuBack)) {
			CGame.CloseTextBubble();
			CGame._miniMapTick = 0;
			CGame._miniMapState = CGame.MINI_MAP_STATE_HERO_MOVE_TO;
		}
		break;
	case CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO:
		var destX;
		var destY;
		var point;
		if (CGame._miniMapLimit == CGame._miniMapLimitLevelRoom && CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
			point = CGame.LevelId2PointId(0);
		} else if (CGame.IsUnlockedWorld(CGame._levelUnlocked)) {
			point = (CGame._worldId + 1) * 2;
			point = Math.min(point, CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX);
		} else {
			point = CGame.LevelId2PointId(CGame._levelUnlocked);
		}
		destX = CGame._miniMapRoomPoint[point];
		destY = CGame._miniMapRoomPoint[point + 1] - DEF.TILE_H;
		if (CGame._miniMapHeroAtPoint == point) {
			CGame._miniMapCursorX = destX;
			CGame._miniMapCursorY = destY;
			CGame._miniMapCursorAtPoint = point;
			CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
		} else {
			this.SetVelocityByDest(CGame.MINI_MAP_CURSOR_VELOCITY, destX - CGame._miniMapCursorX, destY - CGame._miniMapCursorY);
			CGame._miniMapCursorX += CEntity._TempIntArray[DParamIndex.POSX];
			CGame._miniMapCursorY += CEntity._TempIntArray[DParamIndex.POSY];				
			if (CGame._miniMapCursorX == destX && CGame._miniMapCursorY == destY) {
				CGame._miniMapCursorX = destX;
				CGame._miniMapCursorY = destY;
				CGame._miniMapState = CGame.MINI_MAP_STATE_HERO_MOVE_TO;
				CGame._miniMapCursorAtPoint = point;
				if (CGame._miniMapLimit == CGame._miniMapLimitWorldRoom && CGame.IsUnlockedWorld(CGame._levelUnlocked)) {
					CGame._miniMapState = CGame.MINI_MAP_STATE_NEW_WORLD;
				}
			}
		}			
		break;
	case CGame.MINI_MAP_STATE_IDLE:
		var vX = 0;
		var vY = 0;
		if (/*GLLib.*/IsKeyDown(GLKey.k_left) || /*GLLib.*/IsKeyDown(GLKey.k_num1) || /*GLLib.*/IsKeyDown(GLKey.k_num7)) {
			vX -= CGame.MINI_MAP_CURSOR_VELOCITY;
		}
		if (/*GLLib.*/IsKeyDown(GLKey.k_right) || /*GLLib.*/IsKeyDown(GLKey.k_num3) || /*GLLib.*/IsKeyDown(GLKey.k_num9)) {
			vX += CGame.MINI_MAP_CURSOR_VELOCITY;	
		}
		if (/*GLLib.*/IsKeyDown(GLKey.k_up) || /*GLLib.*/IsKeyDown(GLKey.k_num1) || /*GLLib.*/IsKeyDown(GLKey.k_num3)) {
			vY -= CGame.MINI_MAP_CURSOR_VELOCITY;
		}
		if (/*GLLib.*/IsKeyDown(GLKey.k_down) || /*GLLib.*/IsKeyDown(GLKey.k_num7) || /*GLLib.*/IsKeyDown(GLKey.k_num9)) {
			vY += CGame.MINI_MAP_CURSOR_VELOCITY;
		}
		CGame._miniMapCursorX += vX;
		CGame._miniMapCursorY += vY;
		CGame._miniMapCursorAtPoint = -1;
		var mapRoomNum = CGame._miniMapRoomPoint.length;
//@#if RemoveBeeKillerBoss
//@			if(CGame._worldId == DAI.WORLD_ID_CAKE) {
//@				mapRoomNum = CGame._miniMapRoomPoint.length - 2;
//@			}
//@#endif
//@#if RemoveUfoBoss
//@			if(CGame._worldId == DAI.WORLD_ID_SPACE) {
//@				mapRoomNum = CGame._miniMapRoomPoint.length - 2;
//@			}
//@#endif
		for (var i = 0; i < mapRoomNum; i += 2) {
			CEntity._tempBox[DEF.BOX_LEFT] = CGame._miniMapRoomPoint[i] - DEF.TILE_W * 2; 
			CEntity._tempBox[DEF.BOX_RIGHT] = CGame._miniMapRoomPoint[i] + DEF.TILE_W * 2;
			CEntity._tempBox[DEF.BOX_TOP] = CGame._miniMapRoomPoint[i + 1] - (DEF.TILE_H * 3); 
			CEntity._tempBox[DEF.BOX_BOTTOM] = CGame._miniMapRoomPoint[i + 1] + DEF.TILE_H;
			if (i == CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
				CEntity._tempBox[DEF.BOX_BOTTOM] += DEF.TILE_H * 2;
			}
			if (CEntity.InBox(CGame._miniMapCursorX, CGame._miniMapCursorY, CEntity._tempBox)) {
				CGame._miniMapCursorAtPoint = i;
			}
		}
		
		var isLocked = this.MiniMapGetDoorState(CGame._miniMapCursorAtPoint) == CGame.MINI_MAP_DOOR_LOCKED;
		if (CGame._miniMapCursorAtPoint >= 0 && !isLocked && /*GLLib.*/WasKeyPressed(GLKey.k_fire)) {
			if (CGame._miniMapHeroAtPoint == CGame._miniMapCursorAtPoint) {
				if (CGame._miniMapHeroAtPoint == CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
					CGame._miniMapState = CGame.MINI_MAP_STATE_SWITCH_TO_WORLD_ROOM;
					CGame.SetPause(DPauseType.FADE_OUT, DPauseType.FADE_EFFECT_BLACK);
				} else if (CGame._miniMapCursorAtPoint < CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX) {
					CGame._miniMapState = CGame.MINI_MAP_STATE_SWITCH_TO_LEVEL_ROOM;
					CGame.SetPause(DPauseType.FADE_OUT, DPauseType.FADE_EFFECT_BLACK);
				} else {
					CGame._miniMapState = CGame.MINI_MAP_STATE_ENTER_LEVEL;
					CGame.SetPause(DPauseType.FADE_OUT, DPauseType.FADE_EFFECT_CIRCLE);
				}
			} else {
				CGame._miniMapState = CGame.MINI_MAP_STATE_HERO_MOVE_TO;
			}
		}
		break;
	case CGame.MINI_MAP_STATE_HERO_MOVE_TO:
		destX = CGame._miniMapRoomPoint[CGame._miniMapCursorAtPoint];
		destY = CGame._miniMapRoomPoint[CGame._miniMapCursorAtPoint + 1];
		this.SetVelocityByDest(CGame.MINI_MAP_HERO_MOVE_VELOCITY, destX - CGame._miniMapHeroX, destY - CGame._miniMapHeroY);
		var vx = CEntity._TempIntArray[DParamIndex.POSX];
		var vy = CEntity._TempIntArray[DParamIndex.POSY];
		CGame._miniMapHeroX += vx;
		CGame._miniMapHeroY += vy;
		if (CGame._miniMapHeroX == destX && CGame._miniMapHeroY == destY) {
			CGame._miniMapHeroX = destX;
			CGame._miniMapHeroY = destY;
			CGame._miniMapHeroAnim = DAnimID.HERO_WAIT;
			CGame._miniMapHeroAtPoint = CGame._miniMapCursorAtPoint;
			CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
		} else {
			CGame._miniMapHeroAnim = DAnimID.HERO_WAIT;
			if (vx != 0 || vy != 0) {
				if (vx != 0) {
					CGame._miniMapHeroAnim = DAnimID.HERO_WALK; 
					if (vx > 0) {
						CGame._miniMapHeroFlags = 0;
					} else if (vx < 0) {
						CGame._miniMapHeroFlags = DFlags.FLIP_X;
					}
				} else if (vy < 0) {
					CGame._miniMapHeroAnim = DAnimID.HERO_IN_DOOR;
				} else {
					CGame._miniMapHeroAnim = DAnimID.HERO_OUT_DOOR;
				}
			}
		}
		break;
	case CGame.MINI_MAP_STATE_SWITCH_TO_LEVEL_ROOM:
		var worldId = CGame._miniMapCursorAtPoint >> 1;
		var heroInDoorDirection =  worldId;
//@#if RemoveIceLevel
		if(heroInDoorDirection == 0) heroInDoorDirection = 4;
		else if(heroInDoorDirection == 4) heroInDoorDirection = 0;
//@#endif
		switch (heroInDoorDirection) {
		case 0:
			CGame._miniMapHeroAnim = DAnimID.HERO_IN_DOOR;
			break;
		case 1:
			CGame._miniMapHeroAnim = DAnimID.HERO_WALK;
			CGame._miniMapHeroFlags |= DFlags.FLIP_X;
			break;
		case 2:
			CGame._miniMapHeroAnim = DAnimID.HERO_WALK;
			CGame._miniMapHeroFlags &= ~DFlags.FLIP_X;
			break;
		case 3:
		case 4:
			CGame._miniMapHeroAnim = DAnimID.HERO_OUT_DOOR;
			break;
		}
		this.PauseUpdate();
		if (CGame._miniMapLimit != CGame._miniMapLimitLevelRoom) {
			if (_pauseType == DPauseType.NONE) {
				CGame._miniMapHeroAnim = DAnimID.HERO_IN_DOOR;
				CGame._worldId = worldId;
				CGame._miniMapLimit = CGame._miniMapLimitLevelRoom;
				CGame._miniMapHeroAtPoint = CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX;
				CGame._miniMapCursorAtPoint = CGame._miniMapHeroAtPoint;
				CGame._miniMapHeroX = CGame._miniMapRoomPoint[CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX];
				CGame._miniMapHeroY = CGame._miniMapRoomPoint[CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX + 1] + 16 * DScreen.RATIO;
				CGame._miniMapCursorX = CGame._miniMapHeroX;
				CGame._miniMapCursorY = CGame._miniMapHeroY - DEF.TILE_H;	
				CGame.SetPause(DPauseType.FADE_IN, DPauseType.FADE_EFFECT_BLACK);
			}
		} else {
			CGame._miniMapHeroY -= 1;
			if (_pauseType == DPauseType.NONE) {
				if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
					CGame._miniMapState = CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO;
				} else {
					CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
				}
				CGame._miniMapHeroAnim = DAnimID.HERO_WAIT;
			}
		}
		break;
	case CGame.MINI_MAP_STATE_SWITCH_TO_WORLD_ROOM:
		CGame._miniMapHeroAnim = DAnimID.HERO_OUT_DOOR;
		this.PauseUpdate();
		if (CGame._miniMapLimit != CGame._miniMapLimitWorldRoom) {
			CGame._miniMapHeroY += 1;
			if (_pauseType == DPauseType.NONE) {
				CGame._miniMapHeroAtPoint = CGame._worldId << 1;
				CGame._miniMapCursorAtPoint = CGame._miniMapHeroAtPoint; 
				CGame._miniMapLimit = CGame._miniMapLimitWorldRoom;
				CGame._miniMapHeroX = CGame._miniMapRoomPoint[CGame._miniMapHeroAtPoint];
				CGame._miniMapHeroY = CGame._miniMapRoomPoint[CGame._miniMapHeroAtPoint + 1];
				CGame._miniMapCursorX = CGame._miniMapHeroX;
				CGame._miniMapCursorY = CGame._miniMapHeroY - DEF.TILE_H;
				CGame.SetPause(DPauseType.FADE_IN, DPauseType.FADE_EFFECT_BLACK);
			}
		} else {
			CGame._miniMapHeroAnim = DAnimID.HERO_WAIT;
			if (_pauseType == DPauseType.NONE) {
				CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
			}
		}
		break;
	case CGame.MINI_MAP_STATE_ENTER_LEVEL:
		var levelId = (CGame._miniMapCursorAtPoint - CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) >> 1;
		switch (levelId) {
		case 1:
			CGame._miniMapHeroAnim = DAnimID.HERO_IN_DOOR;
			break;
		case 2:
			CGame._miniMapHeroAnim = DAnimID.HERO_WALK;
			CGame._miniMapHeroFlags |= DFlags.FLIP_X;
			break;
		case 3:
			CGame._miniMapHeroAnim = DAnimID.HERO_WALK;
			CGame._miniMapHeroFlags &= ~DFlags.FLIP_X;
			break;
		}
		_fade_circle_centerX = CGame._miniMapHeroX - CGame._miniMapCameraX;
		_fade_circle_centerY = CGame._miniMapHeroY - CGame._miniMapCameraY;
		this.PauseUpdate();
		if (_pauseType == DPauseType.NONE) {
			CGame._miniMapState = CGame.MINI_MAP_STATE_OVER;
			CGame._gameProgress++;
			var curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
			this.UnloadMiniMap();
			CGame.initMenus();
			CGame._tempLevelId = curLevelId;
			CGame._worldId = Math.floor(curLevelId / DAI.LEVELS_NUM_PRE_WORLD);
			s_game_state = STATE.LOAD_UNLOAD;
			CGame.bIsPaused = false;
			CGame.RMS_Save();
		}
		break;
	}
	CGame._miniMapCameraX = CGame._miniMapCursorX - DEF.VIEW_W_D2;
	CGame._miniMapCameraY = CGame._miniMapCursorY - DEF.VIEW_H_D2;
	CGame.CheckMiniMapLimit();
	
	CGame._miniMapWorldIconAlpha += CGame._miniMapWorldIconAlphaStep;
	if (CGame._miniMapWorldIconAlpha < 0x3F) {
		CGame._miniMapWorldIconAlphaStep = -CGame._miniMapWorldIconAlphaStep;
		CGame._miniMapWorldIconAlpha = 0x3F;
	} else if (CGame._miniMapWorldIconAlpha > 0xFF) {
		CGame._miniMapWorldIconAlphaStep = -CGame._miniMapWorldIconAlphaStep;
		CGame._miniMapWorldIconAlpha = 0xFF;
	}
	if (CGame.spriteArray[DSpriteID.MAP_ACTOR] != null) {
		CGame.spriteArray[DSpriteID.MAP_ACTOR].ModifyPaletteAlpha(CGame.MINI_MAP_ALPHA_PAL, CGame._miniMapWorldIconAlpha);
	}
}

CGame.prototype.DrawMiniMapScene = function( background, dx, dy) {
	for (var i = 0; i < CGame._entityRowDataCount; i++) {
		var params = CGame._entitiesRowData[i];
		if (params[DParamIndex.CLASS_ID] == DClassID.MINI_MAP_ACTOR) {
			var isBackgroundActor = params[DParamIndex.MINI_MAP_ACTOR_Z_ORDER] == DValueList.MINI_MAP_ACTOR_ORDER_BACKGROUND;
			var isForegroundActor = params[DParamIndex.MINI_MAP_ACTOR_Z_ORDER] == DValueList.MINI_MAP_ACTOR_ORDER_FOREGROUND;
			var inOrder = background ? isBackgroundActor : isForegroundActor;
			if (inOrder) {
				var state = this.MiniMapGetDoorState(params[DParamIndex.MINI_MAP_ACTOR_POINTID] << 1);
				var show = params[DParamIndex.MINI_MAP_ACTOR_POINTID] < 0
							|| state == params[DParamIndex.MINI_MAP_ACTOR_TYPE]
							|| params[DParamIndex.ANIMID] >= DAnimID.MAP_ACTOR_BOSS_1;
				var showSwirl = false;
				if (CGame._levelUnlocked >= 0 && state == CGame.MINI_MAP_DOOR_UNLOCKED) {
					if (CGame._miniMapState < CGame.MINI_MAP_STATE_NEW_LEVEL_OPEN && CGame._gameProgress != GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
						show = params[DParamIndex.MINI_MAP_ACTOR_TYPE] == DValueList.MINI_MAP_ACTOR_TYPE_CLOSED;
					} else if (params[DParamIndex.MINI_MAP_ACTOR_POINTID] < CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX >> 1) {
						show = params[DParamIndex.MINI_MAP_ACTOR_TYPE] == DValueList.MINI_MAP_ACTOR_TYPE_OPENED;
					} else if (params[DParamIndex.MINI_MAP_ACTOR_POINTID] == CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX >> 1) {
						show = true;
					} else if (params[DParamIndex.MINI_MAP_ACTOR_TYPE] == DValueList.MINI_MAP_ACTOR_TYPE_CLOSED){
						showSwirl = true;
					}
				}
				if (show) {
					if (params[DParamIndex.ANIMID] >= DAnimID.MAP_ACTOR_ICON_LABYRINTH && params[DParamIndex.ANIMID] <= DAnimID.MAP_ACTOR_ICON_SPACE) {
						CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(CGame.MINI_MAP_ALPHA_PAL);
					} else if (params[DParamIndex.ANIMID] >= DAnimID.MAP_ACTOR_DOOR_LEFT_UP_PASS && params[DParamIndex.ANIMID] <= DAnimID.MAP_ACTOR_DOOR_RIGHT_UP_PASS) {
						CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(this.GetLevelPaletteIdByWorldId(CGame._worldId));
					} else {
						CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(0);
					}
					var anim = params[DParamIndex.ANIMID];
					if (params[DParamIndex.ANIMID] >= DAnimID.MAP_ACTOR_BOSS_1) {
						anim = Math.min(this.GetLevelMapActorBossByWorldId(CGame._worldId), DAnimID.MAP_ACTOR_BOSS_5);
						CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(this.GetLevelPaletteIdByWorldId(CGame._worldId));
						if (state != CGame.MINI_MAP_DOOR_LOCKED) {
							CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(CGame.MINI_MAP_BOSS_ENABLE_PAL);
						}
					}
					var drawMapActor = true;
					var hasBoss = true;
//@#if RemoveBeeKillerBoss
//@						if(anim == DAnimID.MAP_ACTOR_BOSS_3) {
//@							drawMapActor = false;
//@							hasBoss = false;
//@						}
//@#endif
//@#if RemoveUfoBoss
//@						if(anim == DAnimID.MAP_ACTOR_BOSS_5) {
//@							drawMapActor = false;
//@							hasBoss = false;
//@						}
//@#endif
					if(drawMapActor) {
						CGame.DrawAnimation(DSpriteID.MAP_ACTOR, anim, dx + params[DParamIndex.POSX] - CGame._miniMapCameraX, dy + params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS]);
					}
					if (params[DParamIndex.ANIMID] == DAnimID.MAP_ACTOR_DOOR_LEFT_UP_PASS
							|| params[DParamIndex.ANIMID] == DAnimID.MAP_ACTOR_DOOR_RIGHT_UP_PASS
							|| params[DParamIndex.ANIMID] == DAnimID.MAP_ACTOR_DOOR_UP_PASS) {
						CGame.DrawAnimation(DSpriteID.EFFECT, DAnimID.EFFECT_EFFECT_FEATHER, dx + params[DParamIndex.POSX] - CGame._miniMapCameraX, dy + params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS]);
					}
					var isBossPoint = params[DParamIndex.MINI_MAP_ACTOR_POINTID] == (CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX >> 1)
								|| params[DParamIndex.MINI_MAP_ACTOR_POINTID] == (CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX >> 1);
					if (state != CGame.MINI_MAP_DOOR_LOCKED) {
						if (hasBoss && isBossPoint && params[DParamIndex.ANIMID] != DAnimID.MAP_ACTOR_WORLD_DOT) {
							showSwirl = true;
						}
					}
				}
//@#if not removeSwirl
				if (showSwirl
//@#if not SupportNokiaAPI				
						&&GLLibConfig.useSoftwareDoubleBuffer
//@#endif							
				) {
					var aframe = s_game_currentFrameNB % CGame.blendSpriteArray[DATA.EFFECT_SPAWN].GetAFrames(DEffectAnimID.SPAWN_OBJ_SPAWN);
					var anim; 
					var offset = 10 + DEF.TILE_H * 2;
					offset += CGame.spriteArray[DSpriteID.MAP_ACTOR].GetFrameHeight(CGame.spriteArray[DSpriteID.MAP_ACTOR].GetAnimFrame(params[DParamIndex.ANIMID], 0)) / 2;
					if (params[DParamIndex.MINI_MAP_ACTOR_POINTID] == CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX >> 1) {
						offset += -10;
						anim = DEffectAnimID.SPAWN_HOLE_CLOCKWISE;
					} else if (params[DParamIndex.MINI_MAP_ACTOR_POINTID] == CGame.MINI_MAP_BOSS_WORLD_ROOM_INDEX >> 1) {
						offset -= -12;
						anim = DEffectAnimID.SPAWN_HOLE_CLOCKWISE;
					} else {
						offset -= 35;
						anim = DEffectAnimID.SPAWN_OBJ_SPAWN;
					}
					offset -= CGame.MINI_MAP_OFFSET_Y;
					CGame.blendSpriteArray[DATA.EFFECT_SPAWN].PaintAFrame(g, anim, aframe, dx + params[DParamIndex.POSX] - CGame._miniMapCameraX, dy + params[DParamIndex.POSY] - CGame._miniMapCameraY + offset, 0);
				}
//@#endif
			}
		}
	}
	CGame.spriteArray[DSpriteID.MAP_ACTOR].SetCurrentPalette(0);
}
//@#if WIDTH_320
//@	var TWICE_OFFSETX;
//@	static void drawMapTwice(boolean refreshTwice)
//@	{
//@		  int h = GLLibPlayer.Tileset_GetLayerHeight(0);
//@		   int w = GLLibPlayer.Tileset_GetLayerWidth(0);
//@		   int destanceX = 0;
//@		   int destanceY = 0;
//@		   int destX = 0;
//@		   int destY = 0;
//@		   int cx = CGame._miniMapCameraX;
//@		   int cy = CGame._miniMapCameraY;
//@		   int mapW = GLLibPlayer.Tileset_GetLayerWidth(0);
//@		   int mapH = GLLibPlayer.Tileset_GetLayerHeight(0);
//@		   destanceX = DEF.VIEW_W+DEF.TILE_W;
//@		   destanceY = DEF.VIEW_H;
//@		   destX = cx;
//@		   destY = cy;
//@		   if(!refreshTwice)
//@		   {
//@		       if(cx >= destanceX)
//@		       {
//@		            destX = cx - destanceX;
//@		       }
//@		       else
//@		       {
//@		           destX = cx +destanceX;
//@		           if(destX +destanceX > mapW)
//@		           {
//@		               destX = mapW - destanceX;
//@		               if(cy >= destanceY)
//@		               {
//@		                   destY = cy - destanceY;
//@		               }
//@		               else
//@		               {
//@		                   destY = cy +destanceY;
//@		                   if(destY + destanceY > mapH)
//@		                   {
//@		                       destY = mapH - destanceY;
//@		                       drawMapTwice(true);
//@		                   }
//@		               }
//@		           }
//@		       }
//@		   }
//@		   else
//@		   {
//@		       destX = 0;
//@		   }
//@		   if(CGame._miniMapCameraX<0)
//@		   {
//@			   GLLibPlayer.Tileset_SetCamera(0,destX, destY);
//@		       GLLibPlayer.Tileset_Draw(/*GLLib.*/g,-TWICE_OFFSETX, 2 * DEF.TILE_H, 0);
//@		       GLLibPlayer.Tileset_SetCamera(0,cx, cy);
//@		       GLLibPlayer.Tileset_Draw(/*GLLib.*/g,-TWICE_OFFSETX, 2 * DEF.TILE_H, 0);
//@			   
//@		   }else{
//@		       GLLibPlayer.Tileset_SetCamera(0,destX, destY);
//@		       GLLibPlayer.Tileset_Draw(/*GLLib.*/g,TWICE_OFFSETX, 2 * DEF.TILE_H, 0);
//@		       GLLibPlayer.Tileset_SetCamera(0,cx, cy);
//@		       GLLibPlayer.Tileset_Draw(/*GLLib.*/g,TWICE_OFFSETX, 2 * DEF.TILE_H, 0);
//@		   }
//@	}
//@#endif	
CGame.prototype.DrawMiniMap = function() {
	g.setColor(0);
	g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
	g.fillRect(0, 0, DEF.SCR_W, DEF.SCR_H);		
	var offsetX = 0;
	var miniMapWidth = CGame._miniMapLimit[DEF.BOX_RIGHT] - CGame._miniMapLimit[DEF.BOX_LEFT];
	if (DEF.SCR_W > miniMapWidth) {
		offsetX = -Math.floor((DEF.SCR_W - miniMapWidth) / 2); 
	}		
	if (CGame._miniMapState == CGame.MINI_MAP_STATE_OVER) {
		return;
	}
	if (CGame._miniMapLimit == CGame._miniMapLimitLevelRoom) {
		CGame.spriteArray[DSpriteID.TILESET_BASE + DATA.MINI_MAP_TILESET].SetCurrentPalette(this.GetLevelPaletteIdByWorldId(CGame._worldId));
	} else {
		CGame.spriteArray[DSpriteID.TILESET_BASE + DATA.MINI_MAP_TILESET].SetCurrentPalette(0);
	}
	GLLibPlayer.Tileset_SetCamera(0, CGame._miniMapCameraX, CGame._miniMapCameraY);
	CGame._miniMapCameraY -= 2 * DEF.TILE_H;
//@#if WIDTH_320
//@		TWICE_OFFSETX = offsetX;	
//@		if (CGame._miniMapCameraX < 0) {
//@			drawMapTwice(false);
//@		} else {
//@			drawMapTwice(false);	
//@			}		
//@#else
	if (CGame._miniMapCameraX < 0) {
		GLLibPlayer.Tileset_Draw(g, -offsetX, 2 * DEF.TILE_H, 0);
	} else {
		GLLibPlayer.Tileset_Draw(g, offsetX, 2 * DEF.TILE_H, 0);	
	}	
	g.setColor(0);
	g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
	g.fillRect(0, 0, DEF.SCR_W, 2 * DEF.TILE_H +1);
//@#endif
	var showMinimapInterface = !CGame.bIsPaused;
	if (CGame._miniMapState == CGame.MINI_MAP_STATE_NEW_WORLD && CGame._miniMapTick < CGame.MINI_MAP_WATCH_OVER_TICK) {
		var witchX;
		var witchY;
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@			witchX = CGame._miniMapRoomPoint[(CGame._worldId + 1) * 2] - 40;
//@#else
		witchX = CGame._miniMapRoomPoint[(CGame._worldId + 1) * 2];
//@#endif
		witchY = CGame._miniMapRoomPoint[(CGame._worldId + 1) * 2 + 1];
		var heroFirst = witchY > CGame._miniMapHeroY;
		var min = Math.min(CGame._miniMapHeroY, witchY);
		var max = Math.max(CGame._miniMapHeroY, witchY);
		this.DrawMiniMapScene(true, offsetX, 0);
		if (heroFirst) {
			CGame.DrawAnimation(DSpriteID.HERO, CGame._miniMapHeroAnim, offsetX + CGame._miniMapHeroX - CGame._miniMapCameraX, CGame._miniMapHeroY - CGame._miniMapCameraY, CGame._miniMapHeroFlags);			
		} else {
			this.DrawMiniMapWitch(witchX, witchY);
		}
		if (!heroFirst) {
			CGame.DrawAnimation(DSpriteID.HERO, CGame._miniMapHeroAnim, offsetX + CGame._miniMapHeroX - CGame._miniMapCameraX, CGame._miniMapHeroY - CGame._miniMapCameraY, CGame._miniMapHeroFlags);			
		} else {
			this.DrawMiniMapWitch(witchX, witchY);
		}
		
		this.DrawMiniMapScene(false, offsetX, 0);				
	} else {
		this.DrawMiniMapScene(true, offsetX, 0);
		CGame.DrawAnimation(DSpriteID.HERO, CGame._miniMapHeroAnim, offsetX + CGame._miniMapHeroX - CGame._miniMapCameraX, CGame._miniMapHeroY - CGame._miniMapCameraY, CGame._miniMapHeroFlags);
		this.DrawMiniMapScene(false, offsetX, 0);
	}
	if (offsetX < 0) {
		g.setColor(0);
		g.fillRect(0, 0, -offsetX, DEF.SCR_H);
		g.fillRect(-offsetX + miniMapWidth, 0, Math.floor((DEF.SCR_W - miniMapWidth) / 2), DEF.SCR_H);
	}

	if (CGame._textBubbleState != CGame.TEXT_BUBBLE_OVER) {
		showMinimapInterface = false;
		this.DrawTextBubble();
//@#if DEFINEZ_TEXT_BUBBLE_POS
//@			if (CGame._textBubbleState == CGame.TEXT_BUBBLE_OVER) {
//@				UpdateBubbleTextIndex();
//@			}
//@#endif
	}

	if (CGame._miniMapState == CGame.MINI_MAP_STATE_NEW_LEVEL_OPEN) {
		var effectAFrames = CGame.spriteArray[DSpriteID.EFFECT].GetAFrames(DAnimID.EFFECT_RANDOM_MAGIC); 
		var x;
		var y;
		if (CGame.IsUnlockedWorld(CGame._levelUnlocked)) {
			x = CGame._miniMapRoomPoint[(CGame._worldId + 1) * 2];
			y = CGame._miniMapRoomPoint[(CGame._worldId + 1) * 2 + 1];
		} else {
			var point = CGame.LevelId2PointId(CGame._levelUnlocked);
			x = CGame._miniMapRoomPoint[point];
			y = CGame._miniMapRoomPoint[point + 1];				
		}
		if (CGame._miniMapTick < effectAFrames && CGame._levelUnlocked >= 0) {
			CGame.spriteArray[DSpriteID.EFFECT].PaintAFrame(g, DAnimID.EFFECT_RANDOM_MAGIC, CGame._miniMapTick, offsetX + x - CGame._miniMapCameraX, y - CGame._miniMapCameraY, 0);
		}
		var firstLevel = CGame._levelUnlocked == 0 && CGame._levelInfo[1] == 0;
		if (firstLevel) {			
			CGame.txtDrawSpecialEffectPopUp(0, Text_GetString(TEXT.MENU_STAGE_UNLOCKED), offsetX + x - CGame._miniMapCameraX, y - CGame._miniMapCameraY - 50 * DScreen.RATIO, 10, 1, 26, GRPH.HCENTER_TOP);
		}
	}
	var cursorAnim = DAnimID.MAP_ACTOR_HAND;
	var curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
	if (CGame._miniMapCursorAtPoint >= 0) {
		cursorAnim = DAnimID.MAP_ACTOR_HAND_SELECTED;
		var text = TEXT.MENU_LOCKED;
		if (showMinimapInterface) {
			if (this.MiniMapGetDoorState(CGame._miniMapCursorAtPoint) != CGame.MINI_MAP_DOOR_LOCKED) {
				if (CGame._miniMapCursorAtPoint == CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
					text = TEXT.MENU_SELECT_WORLD;
				} else {
						curLevelId = CGame.MiniMapGetLevelByPoint(CGame._miniMapCursorAtPoint);
					if (CGame._miniMapCursorAtPoint > CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
						text = this.GetLevelTextByLevelId(curLevelId);
						var stopPosX = DGUI.INTERFACE_STAR_POS_X_MINIMAP;
						var stopPosY = DGUI.INTERFACE_STAR_BOTTOM_OFFSET_Y_MINIMAP;
						this.DrawLevelStars(curLevelId, stopPosX, stopPosY);
					} else {
//@#if not RemoveIceLevel							
//@							text = TEXT.MENU_LABYRINTH_WORLD + (CGame._miniMapCursorAtPoint >> 1);
//@#else
						//temp modify for world name
						text = TEXT.MENU_LABYRINTH_WORLD + (CGame._miniMapCursorAtPoint >= 6?(CGame._miniMapCursorAtPoint >> 1)+1:(CGame._miniMapCursorAtPoint >> 1));
//@#endif							
					}
				}				
			}
			if (CGame._previousLevelID != curLevelId) {
				CGame._actionSpeed = 0;
				CGame._stopAdd = false;
				CGame._stopMove = false;
				CGame._moveSpeed = 0;
				CGame._currentPosY = 0;
				CGame._firstEnterIntoThisFunction = true;		
				CGame._previousLevelID = curLevelId;
			}
			var topTitlePosY = 0;
			if (text > TEXT.MENU_GHOST_TOWN && text != TEXT.MENU_LOCKED || text >= TEXT.MENU_LEVEL1 && text <= TEXT.MENU_LEVEL24) {
				//txtDrawSpecialEffectCongregate_NEW(0, Text_GetString(TEXT.MENU_LV1_1+(curLevelId)), DEF.VIEW_W_D2, -20, 0);
				CGame.txtDraw(0, Text_GetString(this.GetLevelMenuTextByLevelId(curLevelId)), DEF.VIEW_W_D2,	DGUI.CURLEVELID_Y, 1);
				topTitlePosY = 25 * DScreen.RATIO;
			} else {
				topTitlePosY = 14 * DScreen.RATIO;
			}
			var maxLengthPerLine = DEF.VIEW_W - 20;
			//txtDarwSpecialEffecFlowIntoTheScreen(Text_GetString(text), fontSpr, DEF.SCR_W_D2, topTitlePosY, _directDisplay, maxLengthPerLine, 150, VCENTER);
			var align = 1;
			var startLine = 0;
			var lineCount = 10;
			var lineInterval = 5;
			CGame.DrawMultiLineText ( g, Text_GetString(text), DEF.SCR_W_D2, topTitlePosY, 
					align, 2, maxLengthPerLine, startLine, lineCount, lineInterval); 
		}
	}
	
	if (showMinimapInterface) {
		//draw the life
		CGame._interface.PaintFrame(	g, DAnimID.INTERFACE_FRAME_PORTRAIT_MINIMAP, 
								DGUI.INTERFACE_HEADICON_POS_MINIMAP_X, 
								DEF.VIEW_H-DGUI.INTERFACE_BOTTOM_HEIGHT_MINIMAP_HEAD + CGame.MINI_MAP_OFFSET_Y, 0);
		
		CGame._interface.PaintFrame(	g, DAnimID.INTERFACE_FRAME_X, 
								DGUI.INTERFACE_FORK_POS_MINIMAP_X+0, 
								DEF.VIEW_H-DGUI.INTERFACE_BOTTOM_HEIGHT_FORK_OFFSET_Y_MINIMAP + CGame.MINI_MAP_OFFSET_Y, 0);
		
		CGame.DrawInterfaceNumber(	CGame._playerInfo[DAI.HPI_LIVES], 
								DGUI.INTERFACE_FORK_POS_MINIMAP_X + DGUI.INTERFACE_NUM_MARGIN_BEHINDFORK_MINIMAP_X, 
								DEF.VIEW_H - DGUI.INTERFACE_BOTTOM_HEIGHT_MINIMAP_NUM + CGame.MINI_MAP_OFFSET_Y, 2, 0);

		if ((CGame._miniMapCursorAtPoint > CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) && (CGame._miniMapCursorAtPoint != CGame.MINI_MAP_BOSS_LEVEL_ROOM_INDEX)) {
			//draw the score
			CGame.txtDraw(0, Text_GetString(TEXT.MENU_SCORE), 
					DEF.VIEW_W - 5 * DScreen.RATIO, 
					DEF.VIEW_H - DGUI.INTERFACE_SCORE_OFFSET_Y_MINIMAP + CGame.MINI_MAP_OFFSET_Y, 
					TOP | RIGHT);
			//
			if (curLevelId >= 0) {
				CGame.txtDraw(0, String(CGame._levelTotalScore[curLevelId]), 
						DEF.VIEW_W - 5 * DScreen.RATIO, 
						DEF.VIEW_H - DGUI.INTERFACE_SCORE_NUM_OFFSET_Y_MINIMAP + CGame.MINI_MAP_OFFSET_Y, 
						TOP | RIGHT);
			}
		}
	}

	if (CGame._miniMapState >= CGame.MINI_MAP_STATE_CURSOR_MOVE_AUTO) {
		CGame.DrawAnimation(DSpriteID.MAP_ACTOR, cursorAnim, offsetX + CGame._miniMapCursorX - CGame._miniMapCameraX, CGame._miniMapCursorY - CGame._miniMapCameraY, 0);
	}
//@#if not UseCommandBar		
	if (CGame._textBubbleState != CGame.TEXT_BUBBLE_OVER) {
		if (!CGame.bIsPaused) {
			fontSprBig.SetCurrentPalette(0);
			fontSprBig.DrawString(g, Text_GetString(TEXT.MENU_SK_SKIP), DEF.VIEW_W, DEF.VIEW_H, GRPH.RIGHT_BOTTOM);
		}
	}
	if (!CGame.bIsPaused) {
		CGame._interface.PaintAFrame(	g,
				DAnimID.INTERFACE_IGM,
				s_game_currentFrameNB % CGame.spriteArray[DSpriteID.INTERFACE].GetAFrames(DAnimID.INTERFACE_IGM),
				DGUI.INTERFACE_IGM_OFFSET_X, DEF.VIEW_H - DGUI.INTERFACE_LEFTSOFTKEY_OFFSET_Y, 0);
	}
//@#else
//@		if (!CGame.bIsPaused) {
//@		this.setSoftKeys(TEXT.INIT_SK_MENU, (CGame._textBubbleState != CGame.TEXT_BUBBLE_OVER?TEXT.MENU_SK_SKIP:SOFTKEY_NONE));
//@		this.drawSoftKeys();
//@		}
//@#endif		
	_fade_circle_centerX += offsetX;
	this.DrawFadeEffect();
	_fade_circle_centerX -= offsetX;
	CGame._miniMapCameraY += CGame.MINI_MAP_OFFSET_Y;

}

CGame.prototype.DrawMiniMapWitch = function( x, y) {
	var anim = DAnimID.BOSS_WATCH_IDLE_GROUND;
	var aframe = 0;
	var idleFrames = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrames(DAnimID.BOSS_WATCH_IDLE_GROUND);
	var idleTime = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrameTime(DAnimID.BOSS_WATCH_IDLE_GROUND, 0);
	var appearFrames = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrames(DAnimID.BOSS_WATCH_IDLE_GROUND);
	var appearTime = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrameTime(DAnimID.BOSS_WATCH_IDLE_GROUND, 0);
	var disappearFrames = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrames(DAnimID.BOSS_WATCH_IDLE_GROUND);
	var disappearTime = CGame.spriteArray[DSpriteID.BOSS_WATCH].GetAFrameTime(DAnimID.BOSS_WATCH_IDLE_GROUND, 0);
	var tick = CGame._miniMapTick; 
	if (CGame._miniMapTick < appearFrames * appearTime) {
		anim = DAnimID.BOSS_WATCH_APPEAR;
		aframe = CGame._miniMapTick / appearTime % appearFrames; 
	} else {
		tick -= appearFrames * appearTime;
		anim = DAnimID.BOSS_WATCH_IDLE_GROUND;
		aframe = tick / idleTime % idleFrames;
	}
	
	if (CGame._miniMapTick >= CGame.MINI_MAP_WATCH_DISAPPEAR_TICK) {
		tick = CGame._miniMapTick - CGame.MINI_MAP_WATCH_DISAPPEAR_TICK;
		anim = DAnimID.BOSS_WATCH_DISAPPEAR;
		aframe = tick / disappearTime % disappearFrames;
	}
	var flags = 0;
	if (x - CGame._miniMapHeroX > 0) {
		flags |= DFlags.FLIP_X;
	}
	if (CGame._miniMapHeroX - x > 0) {
		CGame._miniMapHeroFlags |= DFlags.FLIP_X;
	}
	
	var drawWitchX = x - CGame._miniMapCameraX;
//@#if RemoveIceLevel
	if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
		drawWitchX = x - CGame._miniMapCameraX + DEF.TILE_H * 2;
	}
//@#endif
	if (CGame._gameProgress == GAME_PROGRESS_FIRST_MINI_MAP_EVENT) {
		var girlAnim = DAnimID.GIRL_IMPRISON_MAGIC;
		if (anim == DAnimID.BOSS_WATCH_APPEAR) {
			girlAnim = DAnimID.GIRL_APPEAR;
		} else if (anim == DAnimID.BOSS_WATCH_DISAPPEAR) {
			girlAnim = DAnimID.GIRL_DISAPPEAR;
		}
		CGame.spriteArray[DSpriteID.GIRL].PaintAFrame(g, girlAnim, aframe, drawWitchX + DEF.TILE_H * 2, y - CGame._miniMapCameraY, flags);
	}
	CGame.spriteArray[DSpriteID.BOSS_WATCH].PaintAFrame(g, anim, aframe, drawWitchX, y - CGame._miniMapCameraY, flags);
}

CGame.MiniMapGetLevelByPoint = function( pointID) {
	if (pointID < 0) {
		return -1;
	}
	if (pointID < CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
		var levelId = (pointID >> 1) * DAI.LEVELS_NUM_PRE_WORLD;
//@#if RemoveBeeKillerBoss
//@			if((pointID >> 1) >= 3) {
//@				levelId -= 1;
//@			}
//@#endif
//@#if RemoveUfoBoss
//@			if((pointID >> 1) >= 4) {
//@				levelId -= 1;
//@			}
//@#endif
		return levelId;
	}
	var curLevelId = ((pointID - (CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX + 1)) >> 1);
	var levelId = curLevelId + CGame._worldId * DAI.LEVELS_NUM_PRE_WORLD;
//@#if RemoveBeeKillerBoss
//@		if(CGame._worldId >= 3) {
//@			levelId -= 1;
//@		}
//@#endif
//@#if RemoveUfoBoss
//@		if(CGame._worldId >= 4) {
//@			levelId -= 1;
//@		}
//@#endif
	return levelId;
}

CGame.prototype.MiniMapGetDoorState = function( pointID) {
	if (pointID == CGame.MINI_MAP_LEVEL_ROOM_POINTS_INDEX) {
		return CGame.MINI_MAP_DOOR_OPENED;
	} else {
		var curLevelId = CGame.MiniMapGetLevelByPoint(pointID);
		if (curLevelId < 0) {
			return CGame.MINI_MAP_DOOR_LOCKED;
		}
		if (CGame._levelInfo[curLevelId] == 1) {
			if (CGame._levelInfo[curLevelId + 1] == 0) {
				return CGame.MINI_MAP_DOOR_UNLOCKED;
			} else {
				return CGame.MINI_MAP_DOOR_OPENED;
			}
		}
	}	
	return CGame.MINI_MAP_DOOR_LOCKED;
}
//@#else
//@	Object _miniMap;
//@	var MINI_MAP_STATE_LOADING = 0;
//@	var MINI_MAP_STATE_FLAG_RISING = 1;
//@	var CGame.MINI_MAP_STATE_IDLE = 5;
//@	var MINI_MAP_STATE_WALK = 6;
//@	var MINI_MAP_STATE_ENTER = 7;
//@	
//@	int CGame._miniMapState = MINI_MAP_STATE_LOADING;
//@	int _miniMapHeroCurTrace = -1;
//@	int _miniMapHeroPosX = 0;
//@	int _miniMapHeroPosY = 0;
//@	int CGame._miniMapCameraX = 0;
//@	int CGame._miniMapCameraY = 0;
//@	GLLibPlayer _miniMapHeroAnimationPlayer; 
//@	
//@	var _goldCoinSpin;// added by gao teng fei
//@	var _levelID_for_loadUnload=0;
//@	var _mappingIndexForThief;
//@	var CGame._previousLevelID = -1;
//@	//var levelID = -1;
//@	
//@	void DrawMiniMap() {
//@		if (CGame._miniMapState == MINI_MAP_STATE_LOADING) {
//@			LoadMiniMap();
//@		}
//@		if (CGame._miniMapState < CGame.MINI_MAP_STATE_IDLE) {
//@			CGame._miniMapState++;
//@		}
//@		if (CEntity._hero != null) {
//@			CGame._miniMapCameraX = Math_FixedPointToInt(CEntity._hero._posX) - DEF.SCR_W_D2;
//@			CGame._miniMapCameraX = Math.max(CGame._miniMapCameraX, 0);
//@			CGame._miniMapCameraX = Math.min(CGame._miniMapCameraX, CGame._mapTileCountWidth * DEF.TILE_W - DEF.SCR_W);
//@		} else {
//@			CGame._miniMapCameraX = 0;
//@			CGame._miniMapCameraY = 0;
//@		}
//@		GLLibPlayer.Tileset_SetCamera(0, CGame._miniMapCameraX, CGame._miniMapCameraY);
//@		GLLibPlayer.Tileset_Draw(g, 0);
//@		ASprite spr = CGame.spriteArray[DSpriteID.MAP_ACTOR];
//@		int aframeHeroWait = (s_game_currentFrameNB / 2) % CGame.spriteArray[DSpriteID.HERO].GetAFrames(DAnimID.HERO_WAIT);
//@		int aframeFlagWait = (s_game_currentFrameNB / 2) % CGame.spriteArray[DSpriteID.MAP_ACTOR].GetAFrames(DAnimID.MAP_ACTOR_FLAG_IDLE);
//@		int aframeFlagRising = s_game_currentFrameNB % CGame.spriteArray[DSpriteID.MAP_ACTOR].GetAFrames(DAnimID.MAP_ACTOR_FLAG_RISING);
//@		int aframeHeroWalk = s_game_currentFrameNB % CGame.spriteArray[DSpriteID.HERO].GetAFrames(DAnimID.HERO_WALK);
//@		int aframeDotFlash = s_game_currentFrameNB % CGame.spriteArray[DSpriteID.MAP_ACTOR].GetAFrames(DAnimID.MAP_ACTOR_PLACE_DOT_FLASH);
//@		int level = CGame._levelId;
//@		int curId = -1;
//@		int nextId = -1;
//@		boolean showNode = true;
//@		for (int i = 0; i < CGame._entityRowDataCount; i++) {
//@			short[] params = CGame._entitiesRowData[i];
//@			//added by gao tengfei to find the mapping index for thief's bag
//@			if( params[DParamIndex.CLASS_ID] == DClassID.MOBS_WHITE ){
//@				_mappingIndexForThief = params[DParamIndex.MOBS_WHITE_ACTIONINTERVAL];
//@			}
//@			if (params[DParamIndex.CLASS_ID] == DClassID.WORLD_CHOOSER) {
//@				int anim = params[DParamIndex.WORLD_CHOOSER_ANIMID];
//@				int aframe = 0;
//@				if ((params[DParamIndex.WORLD_CHOOSER_PARAM] > 0) && (params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT)) {
//@					short[] tempParam = CEntity.GetRowDataByID(params[DParamIndex.WORLD_CHOOSER_WAIT_LINK]);
//@					showNode = (CGame._levelInfo[tempParam[DParamIndex.WORLD_CHOOSER_PARAM]+1] == 1);
//@				} else if (params[DParamIndex.WORLD_CHOOSER_WAIT_LINK] >=0 && params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PATH_DOT) {
//@					short[] tempParam = CEntity.GetRowDataByID(params[DParamIndex.WORLD_CHOOSER_WAIT_LINK]);
//@					if (tempParam[DParamIndex.WORLD_CHOOSER_PARAM] >= 0)
//@						showNode = (CGame._levelInfo[tempParam[DParamIndex.WORLD_CHOOSER_PARAM]+1] == 1);
//@				}
//@				
//@				if (params[DParamIndex.ID] == nextId) {
//@					if (params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT) {
//@						anim++;
//@						aframe = aframeDotFlash;
//@					} else {
//@						nextId = params[DParamIndex.WORLD_CHOOSER_NEXT_TRACE];
//@					}
//@				
//@				}
//@				if (showNode)
//@					spr.PaintAFrame(g, anim, aframe, params[DParamIndex.POSX] - CGame._miniMapCameraX, params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS] & DFlags.SPRITE_FLAG_MASK);
//@
//@				if (params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT) {
//@					if (params[DParamIndex.WORLD_CHOOSER_PARAM] == level) {
//@						if (CGame._miniMapState < CGame.MINI_MAP_STATE_IDLE) {
//@							spr.PaintAFrame(g, DAnimID.MAP_ACTOR_FLAG_RISING, aframeFlagRising, params[DParamIndex.POSX] - CGame._miniMapCameraX, params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS] & DFlags.SPRITE_FLAG_MASK);
//@//						} else {
//@//							spr.PaintAFrame(g, DAnimID.MAP_ACTOR_FLAG_IDLE, aframeFlagWait, params[DParamIndex.POSX] - CGame._miniMapCameraX, params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS] & DFlags.SPRITE_FLAG_MASK);
//@						}
//@						curId = params[DParamIndex.ID];
//@						nextId = params[DParamIndex.WORLD_CHOOSER_NEXT_TRACE];
//@					}
//@
//@					if (CGame._levelInfo[params[DParamIndex.WORLD_CHOOSER_PARAM]+1] == 1)
//@						spr.PaintAFrame(g, DAnimID.MAP_ACTOR_FLAG_IDLE, aframeFlagWait, params[DParamIndex.POSX] - CGame._miniMapCameraX, params[DParamIndex.POSY] - CGame._miniMapCameraY, params[DParamIndex.FLAGS] & DFlags.SPRITE_FLAG_MASK);
//@				}
//@			} else if (params[DParamIndex.CLASS_ID] == DClassID.HERO) {
//@				if (CEntity._hero == null) {
//@					CEntity._hero = new CEntity();
//@					CEntity._hero.Set(params);
//@					CEntity._hero.SetAnim(DAnimID.HERO_WAIT, CEntity.SETANIM_FORCE);
//@				}
//@			}
//@		}
//@		if (CEntity._hero._curTrace <= 0) {
//@			CEntity._hero.InitTrace(curId);
//@			CEntity._hero._relateEntity = CEntity.GetEntityByID(curId, true);
//@		}
//@		if (IsKeyDown(GLKey.k_right) && (CGame._levelInfo[CEntity._hero._relateEntity._params[DParamIndex.WORLD_CHOOSER_PARAM]+1] == 1)) {
//@			CEntity._hero.SetFlipX(false);
//@			CGame._miniMapState = MINI_MAP_STATE_WALK;
//@		} else if (IsKeyDown(GLKey.k_left)) {
//@			CEntity._hero.SetFlipX(true);
//@			CGame._miniMapState = MINI_MAP_STATE_WALK;
//@		}
//@			
//@		if (CGame._miniMapState == MINI_MAP_STATE_WALK) {
//@			int curTrace = CEntity._hero._curTrace;
//@			boolean over = CEntity._hero.IsFlipX() ? CEntity._hero.MoveToPreviousTrace(false) : CEntity._hero.MoveToNextTrace(false);
//@			short[] params = null;
//@			if (over) {
//@				if (!CEntity._hero.IsFlipX()) {
//@					curTrace = CEntity._hero._curTrace;
//@				}
//@				params = CEntity.GetRowDataByID(curTrace);
//@				if (params != null && (params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT))
//@					CEntity._hero._relateEntity = CEntity.GetEntityByID(curTrace, true);
//@				
//@				if (params == null || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT) {
//@					CGame._miniMapState = CGame.MINI_MAP_STATE_IDLE;
//@				}
//@			} else {				
//@				if (CEntity._hero._animationPlayer.GetAnim() != DAnimID.HERO_WALK) {
//@					CEntity._hero.SetAnim(DAnimID.HERO_WALK, CEntity.SETANIM_FORCE);
//@				}
//@			}
//@		}
//@		if (CGame._miniMapState == CGame.MINI_MAP_STATE_IDLE) {
//@			CEntity._hero._vX = 0;
//@			CEntity._hero._vY = 0;
//@			if (CEntity._hero._animationPlayer.GetAnim() != DAnimID.HERO_WAIT) {
//@				CEntity._hero.SetAnim(DAnimID.HERO_WAIT, CEntity.SETANIM_FORCE);
//@			}
//@			int levelID = -1; 
//@			//int previousLevelID = -levelID; //ADDED BY gao teng fei
//@			short[] params = CEntity.GetRowDataByID(CEntity._hero._curTrace);
//@			if (CEntity._hero.IsFlipX()) {
//@				if (params != null) {
//@					params = CEntity.GetRowDataByID(params[DParamIndex.TRACE_NEXT_TRACE]);
//@				}
//@			} 
//@			if (params == null || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_PLACE_DOT || params[DParamIndex.WORLD_CHOOSER_ANIMID] == DAnimID.MAP_ACTOR_BOSS_DOT) {
//@				if (params[DParamIndex.WORLD_CHOOSER_PARAM] >= 0) {
//@					levelID = params[DParamIndex.WORLD_CHOOSER_PARAM];
//@				}
//@			}
//@			if( CGame._previousLevelID != levelID ){
//@				CGame._actionSpeed = 0;
//@				CGame._stopAdd = false;
//@				CGame._stopMove = false;
//@				CGame._moveSpeed = 0;
//@				CGame._firstEnterIntoThisFunction = true;
//@				CGame._previousLevelID = levelID; //record the previous leveID
//@			}
//@			if (levelID >= 0) {
//@				//CGame.txtDraw(0, Text_GetString(TEXT.MENU_LEVEL1 + levelID), DEF.SCR_W_D2, 40, GRPH.HCENTER_TOP);
//@				try {
//@					txtDrawSpecialEffectCongregate(0, Text_GetString(TEXT.MENU_LEVEL1 + levelID), DEF.SCR_W_D2, 40, GRPH.HCENTER_TOP);
//@				} catch (Exception e) {
//@					// TODO Auto-generated catch block
//@					e.printStackTrace();
//@				}
//@				
//@				//draw the stars
//@				DrawLevelStars(levelID);
//@				//
//@				
//@				if (IsKeyDown(GLKey.k_fire)) {
//@					CGame._levelId = levelID;
//@					CGame._tempLevelId = CGame._levelId;
//@					CGame._worldId = CGame._levelId / 5;
//@					_tempWorldId = CGame._worldId;
//@					s_game_state = STATE.LOAD_UNLOAD;
//@					UnloadMiniMap();
//@					CGame._firstEnterIntoThisFunction = true;
//@					CGame._stopMove = false;
//@					CGame._moveSpeed = 0;
//@					CGame._specialEffectStep = EFFECT_FLOWING_INTO_SCREEN;
//@					CGame.RMS_Save();
//@				}
//@			}
//@		}
//@		if (CEntity._hero != null) {
//@			CEntity._hero._frameVX = CEntity.GetVelocity(CEntity._hero._vX); 
//@			CEntity._hero._frameVY = CEntity.GetVelocity(CEntity._hero._vY); 
//@			CEntity._hero.UpdatePosition();
//@			CEntity._hero.UpdateAnimation();
//@			CEntity._camX = Math_IntToFixedPoint(CGame._miniMapCameraX);
//@			CEntity._camY = Math_IntToFixedPoint(CGame._miniMapCameraY);
//@			CEntity._hero.Draw();
//@		}
//@
//@		//draw the left soft key
//@		CGame._interface.PaintFrame(	g,
//@								DAnimID.INTERFACE_FRAME_22,
//@								DGUI.INTERFACE_MARGIN_HORIZONTAL, DEF.VIEW_H - DGUI.INTERFACE_LEFTSOFTKEY_OFFSET_Y, 0);
//@		
//@	
//@		
//@		//CGame._interface.PaintAFrame(arg0, arg1, arg2, arg3, arg4, arg5)
//@		//draw the head 
//@		CGame._interface.PaintFrame(	g, DAnimID.INTERFACE_FRAME_PORTRAIT_MINIMAP, 
//@								DGUI.INTERFACE_HEADICON_POS_MINIMAP_X, DEF.VIEW_H-DGUI.INTERFACE_BOTTOM_HEIGHT_MINIMAP_HEAD, 0);
//@		
//@		CGame._interface.PaintFrame(	g, DAnimID.INTERFACE_FRAME_X, 
//@								DGUI.INTERFACE_FORK_POS_MINIMAP_X+0, 
//@								DEF.VIEW_H-DGUI.INTERFACE_BOTTOM_HEIGHT_FORK_OFFSET_Y_MINIMAP, 0);
//@		
//@		CGame.DrawInterfaceNumber(	CEntity._HeroParams[DAI.HPI_LIVES], 
//@								DGUI.INTERFACE_FORK_POS_MINIMAP_X + DGUI.INTERFACE_NUM_MARGIN_BEHINDFORK_MINIMAP_X, 
//@								DEF.VIEW_H - DGUI.INTERFACE_BOTTOM_HEIGHT_MINIMAP_NUM, 2, 0);
//@		
//@		//draw the gold icon
//@		CGame.spriteArray[DSpriteID.BONUS].PaintFrame(	g, DAnimID.BONUS_FRAME_GOLDEN_COIN1+(_goldCoinSpin++)%7, 
//@													DGUI.INTERFACE_GOLDCOIN_POS_X_MINIMAP, 
//@													DEF.VIEW_H - DGUI.INTERFACE_GOLDCOIN_OFFSET_Y_MINIMAP, 0);
//@
//@		CGame._interface.PaintFrame(	g, DAnimID.INTERFACE_FRAME_X, 
//@								DGUI.INTERFACE_GOLDCOIN_X_MINIMAP, 
//@								DEF.VIEW_H-DGUI.INTERFACE_BOTTOM_HEIGHT_FORK_OFFSET_Y_MINIMAP, 0);
//@//		CEntity._HeroParams[DAI.HPI_GOLDCOIN_COUNT] = 99;
//@		CGame.DrawInterfaceNumber(	CEntity._HeroParams[DAI.HPI_GOLDCOIN_COUNT], 
//@								DGUI.INTERFACE_GOLDCOIN_X_MINIMAP + DGUI.INTERFACE_NUM_MARGIN_BEHINDFORK_MINIMAP_X, 
//@								DEF.VIEW_H - DGUI.INTERFACE_BOTTOM_HEIGHT_MINIMAP_NUM, 2, 0);
//@	}
//@#endif
CGame._starsCurrentPos_X = 0;
CGame._moveSpeed = 0;
CGame._stopMove = false;
CGame.prototype.DrawLevelStars = function( levelID, stopPosX, stopPosyOffset) {
	var startPos = [-200 * DScreen.RATIO,-90 * DScreen.RATIO,-10 * DScreen.RATIO];
		if(levelID < 0 || (levelID+1)%4 == 0 || levelID == DAI.LEVEL_ID_CASTLE || levelID >= DAI.LEVEL_ID_CASTLE_FINAL_BOSS)
		return;
	var strtInfoOff = levelID * DAI.STAR_INFO_SIZE;
	var i, j;
	for( i = CGame._levelStarInfo[strtInfoOff], j = 0; i < DAI.MAX_STAR_NUM; i++, j++ ) {
//@#if WIDTH_320
//@			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed*2;
//@#else
		CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed;
//@#endif
		if (CGame._starsCurrentPos_X >= stopPosX + 45*j* DScreen.RATIO) {
			CGame._starsCurrentPos_X = stopPosX + 45*j* DScreen.RATIO;
		}
		CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(	g, DAnimID.BONUS_STAR, 
													s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_STAR), 
													CGame._starsCurrentPos_X, 
													DEF.VIEW_H - stopPosyOffset, 0);
	}
	
	CGame.spriteArray[DSpriteID.BONUS].SetCurrentPalette(1);
	for(i = 0; i < CGame._levelStarInfo[strtInfoOff]; i++, j++){
//@#if WIDTH_320
//@			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed*2;
//@#else
		CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed;
//@#endif
		if (CGame._starsCurrentPos_X >= stopPosX + 45*j* DScreen.RATIO) {
			CGame._starsCurrentPos_X =  stopPosX + 45*j* DScreen.RATIO;
			if (i == 0) {
				CGame._stopMove = true;
			}
		}
		CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(	g, DAnimID.BONUS_STAR_1, 
													s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_STAR_1), 
													CGame._starsCurrentPos_X, 
													DEF.VIEW_H - stopPosyOffset, 0);
	}
	if (!CGame._stopMove) {
		CGame._moveSpeed+=32;
	}
	CGame.spriteArray[DSpriteID.BONUS].SetCurrentPalette(0);
}

CGame.DrawLevelStars = function(level, drawStars, drawScore) { // int - boolean - boolean
	if (level == -1) {
		level = CGame._tempLevelId;
	}

	if(drawStars) {
		var stopPosX = DGUI.INTERFACE_STAR_POS_X_MINIMAP;
		var stopPosY = DGUI.INTERFACE_STAR_BOTTOM_OFFSET_Y_MINIMAP;
		var startPos = [-200,-90,-10];
		var strtInfoOff = level * DAI.STAR_INFO_SIZE;
		var i, j;
		for( i = CGame._levelStarInfo[strtInfoOff], j = 0; i < DAI.MAX_STAR_NUM; i++, j++ ) {
//@#if WIDTH_320
//@			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed*2;
//@#else
			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed;
//@#endif
			if (CGame._starsCurrentPos_X >= stopPosX + 45*j) {
				CGame._starsCurrentPos_X = stopPosX + 45*j;
			}
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(	g, DAnimID.BONUS_STAR, 
														s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_STAR), 
														CGame._starsCurrentPos_X, 
														DEF.VIEW_H - stopPosY, 0);
		}
		
		CGame.spriteArray[DSpriteID.BONUS].SetCurrentPalette(1);
		for( i=0; i < CGame._levelStarInfo[strtInfoOff]; i++, j++){
//@#if WIDTH_320
//@			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed*2;
//@#else
			CGame._starsCurrentPos_X = startPos[i]+CGame._moveSpeed;
//@#endif
			if (CGame._starsCurrentPos_X >= stopPosX + 45*j) {
				CGame._starsCurrentPos_X =  stopPosX + 45*j;
				if (i == 0) {
					CGame._stopMove = true;
				}
			}
			CGame.spriteArray[DSpriteID.BONUS].PaintAFrame(	g, DAnimID.BONUS_STAR_1, 
														s_game_currentFrameNB % CGame.spriteArray[DSpriteID.BONUS].GetAFrames(DAnimID.BONUS_STAR_1), 
														CGame._starsCurrentPos_X, 
														DEF.VIEW_H - stopPosY, 0);
		}
		if (!CGame._stopMove) {
			CGame._moveSpeed+=32;
		}
		CGame.spriteArray[DSpriteID.BONUS].SetCurrentPalette(0);
	}

	if (drawScore) {
		//draw the score
		CGame.txtDraw(0, Text_GetString(TEXT.MENU_SCORE), 
				DGUI.INTERFACE_GOLDCOIN_POS_X_MINIMAP+6, 
				DEF.VIEW_H - DGUI.INTERFACE_SCORE_OFFSET_Y_MINIMAP + CGame.MINI_MAP_OFFSET_Y, 
				GRPH.HCENTER_TOP);
		//
		if (CGame._tempLevelId >= 0) {
			CGame.txtDraw(0, String(CGame._levelTotalScore[level]), 
					DGUI.INTERFACE_GOLDCOIN_POS_X_MINIMAP+6, 
					DEF.VIEW_H - DGUI.INTERFACE_SCORE_NUM_OFFSET_Y_MINIMAP + CGame.MINI_MAP_OFFSET_Y, 
					GRPH.HCENTER_TOP);
		}
	}
}

//@#if not RemoveFireworks
/*
 *  functions ahout the firework
 */
CGame._fireworks_timer = 0;
CGame._timer = 0;
CGame._fireworks = null;  

CGame.RenderFireworks = function( g)
{
	var i;
	if (CGame._fireworks == null)
	{
		CGame._fireworks = LowAPI.Gen_Array([FIREWORKS.MAX_NO_FIREWORKS], null);//new CFirework[FIREWORKS.MAX_NO_FIREWORKS];
		for (i = 0; i < FIREWORKS.MAX_NO_FIREWORKS; i++) {
			CGame._fireworks[i] = new CFirework(i % 4);
		}
	}

	var e = (CFirework.Rnd(FIREWORKS.MAX_ENERGY * 3) >> 2) + (FIREWORKS.MAX_ENERGY >> 2) + 1;
	var l = (CFirework.Rnd(FIREWORKS.PATCH_LENGHT) >> 1) + (FIREWORKS.PATCH_LENGHT >> 1) + 1;

	CGame._fireworks_timer++;
	for (i = 0; i < FIREWORKS.MAX_NO_FIREWORKS; i++)
	{
		if (CGame._fireworks[i]._sleep && CGame._fireworks_timer > 8)
		{
			CGame._fireworks[i].Init(e, l, CFirework.Rnd(3) == 0);
			CGame._fireworks_timer = 0;
		}
		CGame._fireworks[i].Update();
	}
	//_objFireWork.UpdateSpriteAnim();
   // _objFireWork.UpdateAnimation();
//        if (!_objFireWork.IsAnimOver()) {		
////        	_objFireWork.SetAnim(CFirework.Rnd(12));	
//        	_objFireWork.SetAnim(CFirework.Rnd(12), CEntity.SETANIM_FORCE);
//        }

	for (i = 0; i < FIREWORKS.MAX_NO_FIREWORKS; i++)
	{
		CGame._fireworks[i].Paint(g);
	}
}

//draw the animation of the fireworks
CGame.PaintFireworkSprite = function( g)
{
	_fireworkSprite.PaintAFrame(g, DAnimID.FIRE_WORK_1+CFirework.Rnd(6), 
			s_game_currentFrameNB % _fireworkSprite.GetAFrames(DAnimID.FIRE_WORK_1), 
			CFirework._posX, CFirework._posY, 0);
}
//@#endif

CGame.prototype.UnloadMiniMap = function() {
	// try {
		CGame.LoadUnload(DLoadState.UNLOAD_SPRITE);
	// } catch ( e) {
		// e.printStackTrace();
	// }
	CEntity.RemoveAll();
	CGame.ReleaseLevel(false);
}
CGame.LoadMiniMap = function() {
	if(CGame._miniMapLoadStep == 1){
		CGame._entitiesRowData = LowAPI.Gen_Array([4000], null);//new short[4000][];
		CGame._entityRowDataCount = 0;
		CGame._sprites_load_mask = DSpriteID.DEFAULT_SPRITES_LOAD_MASK | (1 << DSpriteID.BOSS_WATCH) | (1 << DSpriteID.GIRL);

		Pack_Open(DATA.PACK_MINI_MAP);
		if (DEF.dbgEnable) Dbg("loading MINI_MAP_TILESET ------------------------------");
		CGame.spriteLoad(DATA.MINI_MAP_TILESET + DSpriteID.TILESET_BASE, DATA.MINI_MAP_TILESET, true/* false */, true);
		GLLibPlayer.Tileset_Init(GLLibConfig.screenWidth, GLLibConfig.screenHeight, DEF.TILE_W, DEF.TILE_H);
	} else if( CGame._miniMapLoadStep == 2 ) {
		var mapsize;
		var mapdata = null;
		var mapflip = null;
		var tileRepeat = GLLibPlayer.WRAP_CLAMP;
		var dataOffset = DATA.MINI_MAP_MAP_SIZE;
		mapsize = Pack_ReadData(dataOffset++);
		mapdata = Pack_ReadData(dataOffset++);
		mapflip = Pack_ReadData(dataOffset++);
		GLLibPlayer.Tileset_LoadLayer(0,
				mapsize,
				mapdata,
				mapflip,
				CGame.spriteArray[DATA.MINI_MAP_TILESET + DSpriteID.TILESET_BASE],
				false,
				/*GLLib.*/TOP, // set origin on top left
				tileRepeat, tileRepeat);
		GLLibPlayer.Tileset_SetCamera(0, 0, 0);

		CGame._mapTileCountWidth = Mem_GetShort(mapsize, 0);
		CGame._mapTileCountHeight = Mem_GetShort(mapsize, 2);
	} else if(CGame._miniMapLoadStep == 4) {
		CGame.LoadLevelData(DATA.MINI_MAP_DESIGN);
		Pack_Close();
	} else if(CGame._miniMapLoadStep == 5){
		// try {
			CGame.LoadUnload(DLoadState.LOAD_SPRITE);
		// } catch (e) {
			// Dbg("LoadUnload(DLoadState.LOAD_SPRITE) error  : " + e.message);//e.printStackTrace();
		// }
	} else if(CGame._miniMapLoadStep == 6){
		// try {
			CGame.blendSpriteArray = LowAPI.Gen_Array([DATA.EFFECT_MAX], null);//new CBlendSprite[DATA.EFFECT_MAX];
			Pack_Open(DATA.PACK_EFFECT);
			// CGame.blendSpriteArray[DATA.EFFECT_SPAWN] = new CBlendSprite();
			// CGame.blendSpriteArray[DATA.EFFECT_SPAWN].Load(Pack_ReadData(DATA.EFFECT_SPAWN), 0);
			if (DEF.dbgEnable) Dbg("loading effect ------------------------------- LoadMiniMap");
			CGame.blendSpriteArray[DATA.EFFECT_SPAWN] = CGame.LoadSprite4(DATA.EFFECT_SPAWN, -1, true, false);

			CGame.blendSpriteArray[DATA.EFFECT_SPAWN]._blend = CBlendSprite.BLEND_DISPLACEMENT;
			CGame.blendSpriteArray[DATA.EFFECT_SPAWN].ModifyPalette(1, 0x5A1758);
			CGame.blendSpriteArray[DATA.EFFECT_SPAWN].ModifyPalette(2, 0x080598);
			CGame.ApplyModifyPalette(CGame.blendSpriteArray[DATA.EFFECT_SPAWN], [1,2]);
			for (var i = 0; i < CGame.spriteArray.length; i++) {
				if (CGame.spriteArray[i] != null) {
					CGame.spriteArray[i].SetPool(1);
				}
			}
		// } catch ( e) {
			// e.printStackTrace();
		// }
	} else if(CGame._miniMapLoadStep == 7){
		// try {
/*//@	#if CacheSpriteForOptimize
		for (var i = 0; i < DATA.SPRITE_MAX/2; i++) {
			if ((CGame._sprites_load_mask & (1 << i)) != 0) {
				if( i == DATA.SPRITE_HERO )
				{
					CGame.spriteArray[i].BuildCacheImages(0, 0, -1, -1);
				}
				else if (CGame.spriteArray[i] == null){
					Dbg("LoadMiniMap 7------------------ null sprite : " + i);
				} else {
					Dbg("LoadMiniMap 7------------------ sprite : " + i);
					for( var j = 0 ; j < CGame.spriteArray[i]._palettes ; j ++)
					CGame.spriteArray[i].BuildCacheImages(j, 0, -1, -1);
					CGame.spriteArray[i].FreeCacheData();
				}
			}
		}
//@    #endif*/
		// } catch ( e) {
			// e.printStackTrace();
		// }
	} else if(CGame._miniMapLoadStep == 8){
		// try {
/*//@	#if CacheSpriteForOptimize
		for (var i = Math.floor(DATA.SPRITE_MAX/2); i < DATA.SPRITE_MAX; i++) {
			if ((CGame._sprites_load_mask & (1 << i)) != 0) {
				if( i == DATA.SPRITE_HERO )
				{
					CGame.spriteArray[i].BuildCacheImages(0, 0, -1, -1);
				}
				else if (CGame.spriteArray[i] == null){
					Dbg("LoadMiniMap 8------------------ null sprite : " + i);
				} else {
					Dbg("LoadMiniMap 8------------------ sprite : " + i);
					for( var j = 0 ; j < CGame.spriteArray[i]._palettes ; j ++)
					CGame.spriteArray[i].BuildCacheImages(j, 0, -1, -1);
					CGame.spriteArray[i].FreeCacheData();
				}
			}
		}
//@    #endif*/
		// } catch ( e) {
			// e.printStackTrace();
		// }
	}
}
//@#endif
//@#if UseCommandBar
//@	private static String leftString, rightString;
//@	private static Command leftCommand, rightCommand;
//@    private static void displayCommandBar(String left, String right)
//@    {
//@        try
//@        {
//@            if (left == null || right == null )
//@            {
//@                return;
//@            }
//@            CGame ge = GloftCAOF._gameInstance;
//@            
//@            if (  leftString == null || rightString == null
//@            		|| (left.compareTo(leftString))  != 0
//@            		|| (right.compareTo(rightString) != 0) )
//@            {
//@                if (leftCommand != null)
//@                {
//@                	ge.removeCommand(leftCommand);
//@                    leftCommand = null;
//@                }
//@                if (rightCommand != null)
//@                {
//@                	ge.removeCommand(rightCommand);
//@                    rightCommand = null;
//@                }
//@
//@                leftString = left;
//@                rightString = right;
//@                if(left.length == 0 && right.length != 0)
//@                {
//@                	left = " ";
//@                }
//@                rightCommand = new Command(right, Command.BACK, 1); 
//@                leftCommand  = new Command(left,  Command.OK, 2);
//@                ge.addCommand(rightCommand);
//@                ge.addCommand(leftCommand);
//@            }
//@        }
//@        catch (Exception ex) { }
//@    }
//@
//@	public void commandAction(Command c, Displayable d)
//@    {
//@	    if (c == leftCommand)
//@	    {
//@//	    	Dbg("...........GAME_KEY_SOFTKEY_LEFT..........");
//@	    	if (GLLibConfig.softkeyOKOnLeft){	    		
//@	    		this.keyPressed(GLLibConfig.keycodeLeftSoftkey);
//@	    		this.keyReleased(GLLibConfig.keycodeLeftSoftkey);
//@	    	} else {	    	
//@	    		this.keyPressed(GLLibConfig.keycodeRightSoftkey);
//@	    		this.keyReleased(GLLibConfig.keycodeRightSoftkey);
//@	    	}
//@	    }
//@        else if (c == rightCommand)
//@        {
//@//        	Dbg("...........GAME_KEY_SOFTKEY_RIGHT..........");
//@	    	if (GLLibConfig.softkeyOKOnLeft){	    		
//@	    		this.keyPressed(GLLibConfig.keycodeRightSoftkey);
//@	    		this.keyReleased(GLLibConfig.keycodeRightSoftkey);
//@	    	} else {
//@	    		this.keyPressed(GLLibConfig.keycodeLeftSoftkey);
//@	    		this.keyReleased(GLLibConfig.keycodeLeftSoftkey);
//@	    	}
//@        }
//@        else if (c.getCommandType() == Command.EXIT)
//@        {
//@        	
//@        }
//@    }
//@	
//@#endif	
//@#if FixedScreenSize
//Override /*GLLib.*/sizeChanged(int, int)
CGame.prototype.sizeChanged = function( w, h)
{
}
//@#endif
//@#if SupportLandspaceMode
//@	var s_last_game_state = -1;
//@	void sizeChanged(int w, int h)
//@	{
//@		super.sizeChanged(w, h);
//@		if (w > h)
//@		{
//@			if (s_game_state == STATE.LANDSPACE)
//@				return;
//@			if (s_game_state == STATE.GAMEPLAY_UPDATE || s_game_state == STATE.MENU_MAP) {
//@				CGame.initIngameMenu(STATE.MENU_INGAME);
//@			}
//@			if( s_game_state < 0 )
//@			{
//@				Init();
//@			}
//@			s_last_game_state = s_game_state;
//@			s_game_state = STATE.LANDSPACE;
//@		}
//@		else
//@		{
//@			if (s_last_game_state >= 0)
//@				s_game_state = s_last_game_state;
//@		}
//@	}
//@#endif	
//@#if Use_Motion_Sensor
//@#include "MotionSensor.h"
//@#endif

//--------------------------------------------------------------------- 
// function exports_methods(){}
//--------------------------------------------------------------------- 
	LowAPI.extendObject(exports, {
                                    "CGame" : CGame,
									//"WasKeyPressed" : cGame.WasKeyPressed,
									//"this.keyPressed" : cGame.this.keyPressed,
									//"this.keyReleased" : cGame.this.keyReleased,
                                    
    },true);
	
})(window);


//-----------------------------------------------------------------------------------------------------------------------------------------
//LOADING STATES
DLoadState = {};
{
	DLoadState.LOAD_TEXT = 1;
	DLoadState.UNLOAD_TEXT 								= -DLoadState.LOAD_TEXT;

	DLoadState.LOAD_TILESET		 						= DLoadState.LOAD_TEXT + 1;
	DLoadState.UNLOAD_TILESET 							= -DLoadState.LOAD_TILESET;

	DLoadState.LOAD_ENTITY		 						= DLoadState.LOAD_TILESET + 1;
	DLoadState.UNLOAD_ENTITY 							= -DLoadState.LOAD_ENTITY;

	DLoadState.LOAD_SEGMENT		 						= DLoadState.LOAD_ENTITY + 1;
	DLoadState.UNLOAD_SEGMENT 							= -DLoadState.LOAD_SEGMENT;


	DLoadState.LOAD_SPRITE 								= DLoadState.LOAD_SEGMENT + 1;
	DLoadState.UNLOAD_SPRITE								= -DLoadState.LOAD_SPRITE;

	DLoadState.LOAD_EFFECT 								= DLoadState.LOAD_SPRITE + 1;
	DLoadState.UNLOAD_EFFECT								= -DLoadState.LOAD_EFFECT;

	//---------------------------------------------------------------------------------------------------------------------------------
	//load 3d
	DLoadState.LOAD_TEXTURE		 						= DLoadState.LOAD_EFFECT + 1;
	DLoadState.UNLOAD_TEXTURE 							= -DLoadState.LOAD_TEXTURE;

	DLoadState.LOAD_MESH		 							= DLoadState.LOAD_TEXTURE + 1;
	DLoadState.UNLOAD_MESH  							    = -DLoadState.LOAD_MESH;

	DLoadState.LOAD_3D_ANIMATION		 					= DLoadState.LOAD_MESH + 1;
	DLoadState.UNLOAD_3D_ANIMATION 						= -DLoadState.LOAD_3D_ANIMATION;

	DLoadState.LOAD_OVER 								= DLoadState.LOAD_3D_ANIMATION+1; // last loading stage
	DLoadState.UNLOAD_OVER 								= 0; // last unloading stage

	DLoadState.LOAD_SOUND 								= DLoadState.LOAD_OVER + 1;
	DLoadState.UNLOAD_SOUND 								= -DLoadState.LOAD_SOUND;

	DLoadState.LOAD_STARTSOUND 							= DLoadState.LOAD_SOUND + 1;
	DLoadState.UNLOAD_STARTSOUND 						= -DLoadState.LOAD_STARTSOUND;
};

DPauseType = {};
{
	DPauseType.NONE 								= 0;
	DPauseType.FADE_IN 							= 1;
	DPauseType.FADE_OUT 							= 2;

	DPauseType.FADE_EFFECT_BLACK					= 0;
	DPauseType.FADE_EFFECT_CIRCLE					= 1;
	DPauseType.FADE_EFFECT_SCANLINE				= 2;
};

//-----------------------------------------------------------------------------------------------------------------------------------------
//SOUNDS
DSound_Channel = {};
{
	DSound_Channel.BGM		= 0;
//@#if sigleChannel
//@	var SFX		= 0;
//@#else
	DSound_Channel.SFX		= DSound_Channel.BGM + 1;
//@#endif
	//--DSound_Channel.-----------------------------------------------------
	DSound_Channel.TOTAL		= DSound_Channel.SFX + 1;
};
